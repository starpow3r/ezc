#include "interface.h"

TOOLBAR toolbar1;

enum { ID_NEW, ID_OPEN, ID_SAVE, ID_CUT, ID_COPY,
  ID_PASTE, ID_SELECT_ALL, ID_DELETE, ID_COLOR,
  ID_ALPHA, ID_IMAGE, ID_EYE, ID_RUN, ID_ANIMAL,
  ID_SETTINGS, ID_HELP };

text icon_names[]={ "new", "open", "save", "cut", "copy",
  "paste", "selects", "x", "color", "alpha", "image",
  "eye", "run", "tiger", "gear", "help" };

text icon_notes[]={ "Create New File",
  "Open Existing File", "Save File", "Cut to Clipboard",
  "Copy to Clipboard", "Paste from Clipboard",
  "Select All", "Delete", "Color", "Alpha", "Image",
  "Eye", "Execute", "Animal", "Settings", "Help" };

event_create
  create_screen(os_w, os_h);
  set_screen_color(WHITE);
  set_title("Toolbar");
  int x=1, y=font.h+(font.h/2)+4;
  BOX box;
  set_box(&box, x, y, screen_w-2, 70);
  if (!create_toolbar(&toolbar1, &box,
    number_of(icon_names), icon_names, icon_notes))
    return 0;
  set_icon_folder("../../media/icon/48");
  if (!load_toolbar(&toolbar1))
    return 0;
  move_caption(5, screen_h-44);
ende

event_draw
  BOX box;
  set_box(&box, 0, 30, screen_w, 72);
  draw_shade(&box, BLACK, 0x202020, WHITE);
  draw_toolbar(&toolbar1);
ende

event_input
  int choice=toolbar1.select;
  if (event_mouse) {
    if (event_mouse_down) {
      if (choice!=-1) {
        if (choice==ID_NEW)
          ;
        else if (choice==ID_OPEN)
          ;
        else if (choice==ID_SAVE)
          ;
        else if (choice==ID_DELETE)
          exit();
      }
    }
    redraw();
  }
ende