// CREATE AND DRAW CUSTOM MENUS MANUALLY -
// BY DRAWING BOXES, TEXT AND IMAGES

#include "interface.h"

#define N_MAIN_MENUS 4

text main_menu_names[]={ "File", "Edit", "Image", "Mask" };

int menu_select=-1, item_select=-1, item_click=-1;

// for each menu: number of items, box, item texts,
// icon images, filenames and ids

#define N_FILE_MENUS 7

BOX file_menu_box;
text file_menu_names[N_FILE_MENUS]={ "Recent >", "New",
  "Open", "Save", "Save As", "Close", "Exit" };
IMAGE file_icon_images[N_FILE_MENUS];
text file_icon_names[N_FILE_MENUS]={ "history", "new",
  "open", "file", "file", "x", "exit" };

enum { FILE_MENU=1000,
  FILE_RECENT, FILE_NEW, FILE_OPEN, FILE_SAVE,
  FILE_SAVE_AS, FILE_CLOSE, FILE_EXIT };

#define N_EDIT_MENUS 7

BOX edit_menu_box;
text edit_menu_names[N_EDIT_MENUS]={ "Undo", "Redo", "Cut",
  "Copy", "Paste", "Delete", "Settings" };
IMAGE edit_icon_images[N_EDIT_MENUS];
text edit_icon_names[N_EDIT_MENUS]={ "undo", "redo", "cut",
  "copy", "paste", "delete", "gear" };

enum { EDIT_MENU=2000,
  EDIT_UNDO, EDIT_REDO, EDIT_CUT, EDIT_COPY,
  EDIT_PASTE, EDIT_DELETE, EDIT_SETTINGS };

#define N_IMAGE_MENUS 6

BOX image_menu_box;
text image_menu_names[N_IMAGE_MENUS]={ "Adjust", "Size",
  "Rotate >", "Flip >", "Key", "Convert" };
IMAGE image_icon_images[N_IMAGE_MENUS];
text image_icon_names[N_IMAGE_MENUS]={ "alpha", "image",
  "rotate", "flip_h", "key", "colors" };

enum { IMAGE_MENU=3000,
  IMAGE_ADJUST, IMAGE_SIZE, IMAGE_ROTATE,
  IMAGE_FLIP, IMAGE_KEY, IMAGE_CONVERT };

#define N_MASK_MENUS 8

BOX mask_menu_box;
text mask_menu_names[N_MASK_MENUS]={ "Undo", "Redo",
  "Select >", "Remove", "Clear", "Invert",
  "Crop", "Outline" };
IMAGE mask_icon_images[N_MASK_MENUS];
text mask_icon_names[N_MASK_MENUS]={ "undo", "redo",
  "select", "close", "delete", "select", "select", "box" };

enum { MASK_MENU=4000,
  MASK_UNDO, MASK_REDO, MASK_SELECT, MASK_REMOVE,
  MASK_CLEAR, MASK_INVERT, MASK_CROP, MASK_OUTLINE };

int load_menus(), draw_menus(), input_menus();

event_create
  create_screen(700, 400);
  set_screen_color(WHITE);
  set_title("Custom Menu");
  if (!load_menus())
    return 0;
ende

event_draw
  set_font_color(WHITE);
  draw_menus();
  outline_screen(BLACK);
ende

event_input
  input_menus();
  if (event_mouse_down) {
    // convert index (1000+) to id (0+)
    int menu=(menu_select+1)*1000,
      item=menu+item_select+1;
    if (menu==FILE_MENU) {
      if (item==FILE_EXIT or item==FILE_CLOSE)
        exit();
    }
  }
ende

int load_menus() {
  int i;
  char t[256];
  text folder="../../media/icon/24";

  #define load_my_menu(NAME, name) \
    for (i=0; i<N_##NAME##_MENUS; i++) { \
      print(t, "%s/%s", folder, name##_icon_names[i]); \
      if (!load_image_t(&name##_icon_images[i], t)) \
        return 0; \
    }

  load_my_menu(FILE, file);
  load_my_menu(EDIT, edit);
  load_my_menu(IMAGE, image);
  load_my_menu(MASK, mask);

  menu_select=item_select=item_click=-1;
  return 1;
}

int draw_menus() {
  int i, x, y, h=32,
    menu, item, menu_id, item_id;
  BOX box, *p;
  char t[256];
  draw_vista(0, 32, screen_w-1, 34, BLACK);
  draw_text("File   Edit   Image   Mask", 16, 40);
  menu=menu_select, item=item_select;

  #define draw_my_menu(NAME, name) \
    p=&name##_menu_box; \
    set_box(p, x, y, 156, 8+(h*N_##NAME##_MENUS)); \
    draw_shade(p, BLACK, DARK_GRAY, WHITE); \
    for (i=0; i<N_##NAME##_MENUS; i++) { \
      t[0]=0; \
      if (menu==((NAME##_MENU/1000)-1) and item==i) { \
        set_box(&box, p->x+4, p->y+(i*h)+3, p->w-8, h); \
        draw_shade(&box, ROYAL_BLUE, BLUE, WHITE); \
        draw_caption(name##_menu_names[item], \
          4, screen_h-44); \
        print(t, "Menu: %s > %s", main_menu_names[menu], \
          name##_menu_names[item]); \
      } \
      draw_image_at(&name##_icon_images[i], x+7, y+7+(i*h)); \
      draw_text(name##_menu_names[i], \
        x+40, y+8+(i*h)); \
      if (t[0]) { \
        if (text_ends(t, ">")) \
          t[text_n(t)-2]=0; \
        draw_caption(t, 4, screen_h-85); \
      } \
    }

  x=4, y=68;
  draw_my_menu(FILE, file);
  x+=160, y=p->y;
  draw_my_menu(EDIT, edit);
  x+=160, y=p->y;
  draw_my_menu(IMAGE, image);
  x+=160, y=p->y;
  draw_my_menu(MASK, mask);

  // note: index=((id/1000)-1), id=((index+1)*1000)

  if (item!=-1) {
    menu_id=(menu+1)*1000, item_id=(menu_id+1)+item;
    print(t, "Select: Menu=%d/#%d, Item=%d/#%d",
      menu, menu_id, item, item_id);
    draw_caption(t, 4, screen_h-44);
  }
  return 1;
}

int input_menus() {
  int i;
  BOX box, *p;
  menu_select=item_select=item_click=-1;

  #define input_my_menu(NAME, name) \
    p=&name##_menu_box; \
    if (select_box(p)) { \
      menu_select=((NAME##_MENU/1000)-1); \
      for (i=0; i<N_##NAME##_MENUS; i++) { \
        set_box(&box, p->x+4, p->y+(i*32)+3, \
          p->w-12, 33); \
        if (select_box(&box)) { \
          item_select=i; \
          if (mouse_1) \
            item_click=i; \
          redraw(); \
          return 1; \
        } \
      } \
    }

  if (event_mouse) {    
    input_my_menu(FILE, file);
    input_my_menu(EDIT, edit);
    input_my_menu(IMAGE, image);
    input_my_menu(MASK, mask);
  }
  return 1;
}