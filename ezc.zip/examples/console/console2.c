// EXAMPLE CUSTOM CONSOLE

#include "console.h"

void test_bit_stream();

int main_c() {
  test_bit_stream();
  return 0;
}

// TEST BIT STREAM FUNCTIONS

text message=
  "Test Bit Stream Functions in FILE.H. " \
  "Read and write\r\nindividual bits to/from " \
  "memory/file.";

// 00000000b, 11111111b, 11110000b, 00001111b,
// 10101010b, 01010101b, 11001100b, 00110011b,
// 11100011b, 00011100b, 10001000b, 01110111b

byte my_stream[12]={
  0x00, 0xFF, 0xF0, 0x0F,
  0xAA, 0x55, 0xCC, 0x33,
  0xE3, 0x1C, 0x88, 0x77
};

void test_bit_stream() {
  uint i, n, x, bit;
  char t[256];

  puts_c(message);
  putr_c();

  // set existing stream, open, read individual bits
  // from it. size = 12 numbers, 8 bits each

  set_stream_read(my_stream, 12);

  for (n=0, x=0; n<12; n++) {
    for (i=0; i<8; i++) {
      bit=read_bit();
      print_c("%c", '0'+bit);
    }
    print_c("b, ");
    if (++x==4)
      putr_c(), x=0;
  }
  putr_c();

  // create stream for write: 10101010b, 11110000b.
  // size = 2 bytes, 16 bits. aligned perfectly

  create_stream(2);

  write_bit(1), write_bit(0), write_bit(1), write_bit(0),
  write_bit(1), write_bit(0), write_bit(1), write_bit(0);

  write_bit(1), write_bit(1), write_bit(1), write_bit(1),
  write_bit(0), write_bit(0), write_bit(0), write_bit(0);
  
  write_last_byte();

  // optional: write_last_byte. it does nothing in
  // this example because size=16 is aligned by 8.
  // needed after writes if not aligned.

  // 1-8 write_bits writes 1 byte, 9-16 writes
  // 2 bytes, 17-24 write_bits writes 3 bytes,
  // and 25-32 writes 4 bytes

  // byte *stream is a pointer to beginning,
  // and stream_p is the current offset/end.
  // location/size = stream_p - stream

  print_c("%bb, %bb", stream[0], stream[1]);
  putr_c();

  // deallocate stream that was created,
  // and erase existing stream

  destroy_stream();
  memory_zero(my_stream, 12);

  // set existing stream for write, then
  // write multiple bits to it (4*8=32).
  // read/write_bits accepts size in bits.

  set_stream_write(my_stream);

  byte my_bits[4]={ 0xAA, 0xF0, 0xCF, 0xCC };

  write_bits(my_bits, 32);
  write_last_byte();

  // write_last_byte is not necessary for this,
  // 32 is aligned by 8, but as a general rule
  // of thumb, it should always appear after
  // write_bit/s in case size is not aligned
  // by 8, or if it's a random file size

  print_c("%bb, %bb, %bb, %bb",
    my_stream[0], my_stream[1],
    my_stream[2], my_stream[3]);
  putr_c();
}

/* note: destroy_stream should be used sometime
after create_stream when finished with it.

most examples do not deallocate/free memory,
or only as needed at runtime, because all
operating systems do this automatically
when the program ends */