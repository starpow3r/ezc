// EXAMPLE CUSTOM CONSOLE (main_c/printf_c)

#include "console.h"

void test_print();

int main_c() {
  print_c("Custom Console. Written in portable C.\n\n");
  test_print();
  puts_c("");
  puts_c("Press any key to exit");
  return 0;
}

void test_print() {
  print_c("Test print(\"%%s\", ...) formats:\n\n");
  print_c("Text: %s, %t\n", "Example", "Filename");
  print_c("Characters: %c, %c, %c, %c\n",
    'A', 'B', 'C', '@');
  print_c("Decimal: %d, %d, %d, %d\n",
    7, 123, -4567, 12345678);
  print_c("Unsigned: %u, %u\n", 0, (1<<32)-1);
  print_c("Hexadecimal: %xh, %Xh, %hh, %hh\n",
    0x7F, 0xBADFACE, t2h("CAFEBABE"), t2h("FEEDBABE"));
  print_c("Binary: %bb, %bb, %bb, %bb\n",
    0xAA, 0xF0, t2b("11001100"), t2b("11110011"));
  print_c("Text aligned (8): \"%08s\"\n", "ABCD");
  print_c("Decimal aligned (4): %04d, %04d\n", 1, 123);
  print_c("Hexadecimal aligned (8): %08hh\n", 0x77);
  print_c("Binary aligned (16): %016bb\n", 0xFF);
}