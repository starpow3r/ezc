// EASY CUSTOM CONSOLE TEMPLATE. VISUAL
// ALTERNATIVE TO STANDARD "COMMAND WINDOW"
// (CMD.EXE). PORTABLE, CUSTOMIZABLE

#define USE_STREAM
#include "interface.h"

#define CONSOLE_FONT "code/24"

text console=0, console_p=0;
uint console_size=0;
char console_line[256];

text console_font_name=CONSOLE_FONT;
FONT console_font;

int create_console(uint n);
void destroy_console();
void draw_console();

// console functions. easy to edit and upgrade

int create_console(uint size) {
  console_p=0, console_size=0;
  if (!allocate(text, console, size))
    return 0;
  console[0]=0, console_p=console,
  console_size=size;
  if (!load_font(&console_font, console_font_name)) {
    bug("Error loading: %s", console_font_name);
    return 0;
  }
  return 1;
}

void destroy_console() {
  destroy(console);
  console_p=0, console_size=0;
}

void draw_console() {
  set_font_c(&console_font, WHITE);
  draw_text(console, 12, 44);
}

// custom versions of puts/printf

#define puts_c(t) \
  console_p=text_attach(console_p, t), \
  console_p=text_attach(console_p, "\r\n")

#define print_c(p...) \
  print(console_line, p), \
  console_p=text_attach(console_p, console_line)

#define printf_c(p...) \
  sprintf(console_line, p), \
  console_p=text_attach(console_p, console_line)

#define putr_c() \
  console_p=text_attach(console_p, "\r\n")

// define your own events, or use predefined template

#ifndef USE_EVENTS

extern int main_c();

event_create
  create_screen(os_w, os_h);
  set_title("Custom Console");
  if (!create_console(4*KB))
    return 0;
  main_c();
ende

event_draw
  draw_console();
ende

#ifndef USE_INPUT
event_input
  if (key)
    exit();
ende
#endif

#endif