// TEST TEXT.H FUNCTIONS

#include "console.h"

text yes="True", no="False";

void test_print(), test_copy(), test_compare(),
  test_count(), test_replace(), test_convert(),
  test_extract();

int main_c() {
  print_c("Test TEXT.H Functions:\n\n");
  test_copy();
  test_compare();
  test_count();
  test_replace();
  test_convert();
  test_extract();
  getch();
  return 0;
}

void test_copy() {
  char t[32];
  print_c("Copy: ");
  text_copy(t, "abc");
  text_attach(t, "defg");
  print_c("%s,", t);
  text_reverse(t);
  text_upper(t);
  print_c("%s,", t);
  text_lower(t);
  print_c("%s\n", t);
}

void test_compare() {
  char a[32], b[32];
  print_c("Compare: ");
  text_copy(a, "abc");
  text_copy(b, "abcd");
  print_c(text_equal(a, b) ? yes:no);
  print_c(", ");
  text_copy(a, "FILE.TXT");
  text_copy(b, "LE.TX");
  print_c(text_search(a, b) ? yes:no);
  print_c("\n");
  return 0;
}

void test_count() {
  int n;
  print_c("Count: ");
  n=text_count("abc.abc.abc", "abc"); // 3
  print_c("%d,", n);
  n=text_count_lines(".\n.\n.\n.\n."); // 5
  print_c("%d,", n);
  n=text_count_c("*a*b*c*x*y*z*", '*'); // 7
  print_c("%d\n", n);
}

void test_replace() {
  char t[256]="123.abc.abc.abc.xyz.xyz.xyz";
  text what="abc", with="EXAMPLE",
    what2="xyz", with2="PROGRAM";
  print_c("Replace: t=\"%s\"\n" \
    "replace(t, \"%s\", \"%s\"), " \
    "replace(t, \"%s\", \"%s\")\n",
    t, what, with, what2, with2);
  text_replace(t, what, with);
  text_replace(t, what2, with2);
  print_c("Result: %s\n\n", t);
}

void test_convert() {
  char t[256];
  print_c("Convert T2N: ");
  print_c("%d,", t2i("-1"));
  print_c("%d,", t2i("2147483647"));
  print_c("%d,", t2i("-2147483648"));
  print_c("%u\n", t2u("4294967295"));
  print_c("%X,", t2h("ABCDEF12"));
  print_c("%X,", t2h("FFFFFFFF"));
  print_c("%d", t2b("10101010"));
  print_c("\n");
  print_c("Convert N2T: ");
  u2t(123456789, t);
  print_c("%s,", t);
  i2t(-123456789, t);
  print_c("%s,", t);
  h2t(0xABCDEF12, t);
  print_c("%s,", t);
  b2t(170, t);
  print_c("%s\n", t);
  print_c("Convert F2T: %.1f, %.2f, %.3f, %.5f, %.2f",
    0.7, 0.25, 1.234, 2.34567, 3.14);
  print_c("\n\n");
}

void test_extract() {
  char t[256];
  text name="C:/MY/FILE.EXT";
  print_c("Test FILE.H > extract\n\n");
  print_c("Filename: %s\n", name);
  extract_drive(t, name);
  print_c("Drive: %s\n", t);
  extract_directory(t, name);
  print_c("Directory: %s\n", t);
  extract_folder(t, name);
  print_c("Folder: %s\n", t);
  extract_file(t, name);
  print_c("File: %s\n", t);
  extract_name(t, name);
  print_c("Name: %s\n", t);
  extract_ext(t, name);
  print_c("Extension: %s ", t);
  print_c("\n\n", t);
}