#define ON_CREATE
#define ON_DRAW
#define ON_INPUT

#include "../../include/ez.h"