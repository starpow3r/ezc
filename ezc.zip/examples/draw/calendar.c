// CALENDAR

#include "interface.h"

TIME now;
int this_month, this_day, this_weekday, this_year;

void draw_calendar(int month, int day, int year,
  int cx, int cy, int bw, int bh);

int day_code(int year);
int days_in_month(int month, int year);
int day_index(int month, int day, int year);

event_create
  create_screen(456, 400);
  set_screen_color(BLACK);
  set_title("Calendar");
  get_date(&now);
  this_month=now.month, this_day=now.day,
  this_weekday=now.weekday, this_year=now.year;
ende

event_draw
  draw_calendar(this_month, this_day, this_year,
    4, 72, 64, 40);
  outline_screen(BLUE);
ende

event_input
  if (event_key) {
    if (key==K_LEFT and --this_month<0)
      this_month=0;
    else if (key==K_RIGHT and ++this_month>=12)
      this_month=11;
    else if (key==K_UP)
      this_year++;
    else if (key==K_DOWN)
      this_year--;
    redraw();
  }
ende

int day_code(int year) {
  int n=year-1;
  return ((year+(n/4)-(n/100)+(n/400))%7);
}

int days_in_month(int month, int year) {
  int days[]={ 31, 28, 31, 30, 31,
    30, 31, 31, 30, 31, 30, 31 };
  if (month!=1)
    return days[month];
  if (is_leap_year(year))
    return 29;
  return 28;
}

int day_index(int month, int day, int year) {
  int ns[]={ 0, 3, 2, 5, 0, 3,
    5, 1, 4, 6, 2, 4 };
  if (month<2)
    year--;
  return (year+(year/4)-(year/100)
    +(year/400)+ns[month]+day)%7;
}

void draw_calendar(int month, int day, int year,
  int cx, int cy, int bw, int bh) {
  int i, n, x, y, w=7, h=6, start,
    da, n_days=0, next_month_day=0;
  text p;
  char t[64];
  BOX box;
  color c, fc;
  TIME time;
  get_time(&time);
  set_box(&box, 0, 33, screen_w, 40);
  print(t, "%s %d, %d",
    month_names[month], day, year);
  draw_text_a(t, &box, CENTER);
  for (x=0; x<7; x++) {
    set_box(&box, cx+(x*bw), cy, bw, bh);
    draw_box(&box, ROYAL_BLUE, WHITE);
    set_font_color(WHITE);
    text_copy_n(t, day_names[x], 3);
    draw_text_a(t, &box, CENTER);
  }
  cy+=42, start=day_index(month, 1, year);
  da=1, n_days=days_in_month(month, year);
  for (i=0, y=0; y<h; y++) {
    for (x=0; x<w; x++, i++) {
      t[0]=0;
      c=BLACK, fc=WHITE;
      if (i>=start) {
        c=BLUE, fc=WHITE;
        if (i<(start+n_days)) {
          if (da==now.day and month==now.month
            and year==now.year) // today
            c=WHITE, fc=BLACK;
          n2t(da++, t);
        }
        else {
          c=PURPLE, fc=WHITE; // next month
          if (!next_month_day)
            next_month_day=1;
          else
            next_month_day++;
          n2t(next_month_day, t);
        }
      }
      set_box(&box, cx+(x*bw), cy+(y*bh), bw, bh);
      draw_box(&box, c, fc);
      set_font_color(fc);
      draw_text_a(t, &box, CENTER);
    }
  }
}