#include "visual.h"

text title="Interface Alignment";

event_create
  create_screen(1280, 720);
  set_screen_color(BLACK);
  set_title(title);
ende

event_draw
  int h;
  BOX box, red_panel, green_panel, blue_panel;
  set_font_color(WHITE);
  h=font.h+inset_h;
  set_box(&red_panel, 0, h, screen_w, h+font.h);
  draw_shade(&red_panel, BLACK, RED, RED);
  set_box(&green_panel, 0, red_panel.y+red_panel.h,
    font.w*12, screen_h-(red_panel.y+red_panel.h));
  draw_shade(&green_panel, BLACK, GREEN, GREEN);
  set_box(&blue_panel, green_panel.w, red_panel.y+
    red_panel.h, screen_w-green_panel.w,
    screen_h-red_panel.h-h);
  draw_shade(&blue_panel, BLACK, BLUE, BLUE);
  set_box(&box, red_panel.x, red_panel.y,
    red_panel.w/2, red_panel.h);
  draw_outline(&box, WHITE);
  draw_text_a("R.West", &box, CENTER);
  move_box_r(&box);
  draw_outline(&box, WHITE);
  draw_text_a("R.East", &box, CENTER);
  set_box(&box, green_panel.x, green_panel.y,
    green_panel.w, green_panel.h/3);
  draw_outline(&box, WHITE);
  draw_text_a("G.North", &box, CENTER);  
  move_box_d(&box);
  draw_outline(&box, WHITE);
  draw_text_a("G.Center", &box, CENTER); 
  move_box_d(&box);
  draw_outline(&box, WHITE);
  draw_text_a("G.South", &box, CENTER);
  set_box(&box, green_panel.w, red_panel.y+red_panel.h,
    screen_w-green_panel.w, red_panel.h);
  draw_outline(&box, WHITE);
  draw_text_a("B.North", &box, CENTER);  
  set_box(&box, blue_panel.x, blue_panel.y+red_panel.h,
    blue_panel.w/3, screen_h-(red_panel.h*3)-h);
  draw_outline(&box, WHITE);
  draw_text_a("B.West", &box, CENTER);
  move_box_r(&box);
  draw_outline(&box, WHITE);
  draw_text_a("B.Center", &box, CENTER);
  move_box_r(&box);
  draw_outline(&box, WHITE);
  draw_text_a("B.East", &box, CENTER);
  set_box(&box, blue_panel.x, screen_h-red_panel.h,
    blue_panel.w/2, red_panel.h);
  draw_outline(&box, WHITE);
  draw_text_a("B.South.West", &box, CENTER);
  move_box_r(&box);
  draw_outline(&box, WHITE);
  draw_text_a("B.South.East", &box, CENTER);
ende