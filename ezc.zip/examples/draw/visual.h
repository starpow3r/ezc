// visual.h

// #include "ez.h"       - int main(...)
// #include "visual.h"   - create, draw
// #include "graphics.h" - create, draw, timer
// #include "game.h"     - all previous + input
// #include "program.h"  - all + exit
// #include "console.h"  - int Main(...) // custom

#define ON_CREATE
#define ON_DRAW

#include "ez.h"