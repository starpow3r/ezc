#include "visual.h"

void create_palette_8(), create_palette_12(),
  draw_palette_8(), draw_palette_12();

color palette[4096];

event_create
  create_screen(os_w, os_h);
  set_title("Palette: 256 Colors");
  create_palette_12();
ende

event_draw
  draw_palette_12();
ende

// gradient from colors a to b

void set_gradient(int start, int n, color a, color b) {
  int i, j, k, an;
  BOX box;
  char t[256];
  color c;
  if (start+n>255)
    return;
  c=a, j=0, k=(255/n), an=k;
  for (i=0; i<n; i++, j++) {
    if (i==n-1) {
      palette[start+i]=b;
      return;
    }
    palette[start+i]=c;
    c=mix(a, b, an);
    an+=k;
  }
}

// shade from lightest to darkest

void set_shade(int start, int n, color c) {
  int i, j, a;
  BOX box;
  char t[256];
  color s=c;
  n=n/2, a=255/n;
  for (i=0, j=start; i<n; i++, j++) {
    s=mix(WHITE, c, a*(i+1));
    palette[j]=s;
  }
  for (i=0; i<n-1; i++, j++) {
    s=mix(c, BLACK, a*(i+1));
    palette[j]=s;
  }
  palette[j]=mix(c, BLACK, 222);
}

void set_shade_12(int start, int n, color c) {
  int i, j, a;
  BOX box;
  color s=c;
  n=n/2, a=255/n; // 255/n;
  for (i=0, j=start; i<n; i++, j++) {
    s=mix(WHITE, c, a*i);
    palette[j]=s;
  }
  for (i=0; i<n; i++, j++) {
    s=mix(c, BLACK, a*i);
    palette[j]=s;
  }
  // palette[j]=mix(c, BLACK, 222);
}

void create_palette_8() {
  uint i, n, v;
  color c=BLACK;
  n=16, v=0x101010;
  for (i=0; i<n; i++) {
    palette[i]=c;
    c+=v;
    if (c+v>0xFFFFFF)
      c=0xFFFFFF;
  }
  i=16;
  set_shade(i, 8, RED);
  set_shade(i+=16, 8, mix(RED, MAGENTA, 144));
  set_shade(i+=16, 8, mix(PINK, MAGENTA, 128));
  set_shade(i+=16, 8, MAGENTA);
  set_shade(i+=16, 8, mix(BLUE, MAGENTA, 192));
  set_shade(i+=16, 8, mix(BLUE, MAGENTA, 144));
  set_shade(i+=16, 8, mix(BLUE, MAGENTA, 96));
  set_shade(i+=16, 8, mix(BLUE, MAGENTA, 64));
  set_shade(i+=16, 8, mix(BLUE, MAGENTA, 32));
  set_shade(i+=16, 8, BLUE);
  set_shade(i+=16, 8, mix(BLUE, CYAN, 96));
  set_shade(i+=16, 8, mix(BLUE, CYAN, 144));
  set_shade(i+=16, 8, mix(BLUE, CYAN, 208));
  set_shade(i+=16, 8, CYAN);
  set_shade(i+=16, 8, mix(WHITE, CYAN, 128));
  i=24;
  set_shade(i, 8, mix(CYAN, GREEN, 96));
  set_shade(i+=16, 8, mix(CYAN, GREEN, 144));
  set_shade(i+=16, 8, GREEN);
  set_shade(i+=16, 8, mix(GREEN, YELLOW, 96));
  set_shade(i+=16, 8, mix(GREEN, YELLOW, 144));
  set_shade(i+=16, 8, mix(GREEN, YELLOW, 208));
  set_shade(i+=16, 8, mix(YELLOW, FLESH, 128));
  set_shade(i+=16, 8, YELLOW);
  set_shade(i+=16, 8, mix(YELLOW, RED, 32));
  set_shade(i+=16, 8, mix(ORANGE, BROWN, 128));
  set_shade(i+=16, 8, mix(RED, BROWN, 128));
  set_shade(i+=16, 8, mix(RED, BROWN, 128));
  set_shade(i+=16, 8, c=mix(FLESH, RED, 64));
  set_shade(i+=16, 8, c=mix(c, RED, 64));
  // set_shade(i+=16, 8, mix(FLESH, ROSE_RED, 64));
  // set_shade(i+=16, 8, mix(FLESH, RED, 128));
  //set_shade(i+=16, 8, mix(FLESH, BROWN, 128));
  
//  set_shade(i+=16, 8, mix(FLESH, GREEN, 64));
//  set_shade(i+=16, 8, mix(FLESH, BLUE, 64));
}

// color colors[]={ RED, };

color hues[12];

// RED, RED+YELLOW, YELLOW, YELLOW+GREEN,
// GREEN, GREEN+CYAN, CYAN, CYAN+BLUE,
// BLUE, BLUE+MAGENTA, MAGENTA, MAGENTA+RED

void create_palette_12() {
  uint i, n, v, a;
  color c=BLACK;
  n=64, v=0x040404;
  for (i=0; i<n; i++) {
    palette[i]=c;
    c+=v;
    if (c+v>0xFFFFFF)
      c=0xFFFFFF;
  }
  i=n;
  // set_shade_12(i, n, RED);

  int j=0, k=255/8;
  for (v=j+8, a=k; j<v; j++)
    set_shade_12(i+=n, n, mix(RED, YELLOW, a)), a+=k;
  for (v=j+8, a=k; j<v; j++)
    set_shade_12(i+=n, n, mix(YELLOW, GREEN, a)), a+=k;
  for (v=j+8, a=k; j<v; j++)
    set_shade_12(i+=n, n, mix(GREEN, CYAN, a)), a+=k;
  for (v=j+8, a=k; j<v; j++)
    set_shade_12(i+=n, n, mix(CYAN, BLUE, a)), a+=k;
  for (v=j+8, a=k; j<v; j++)
    set_shade_12(i+=n, n, mix(BLUE, MAGENTA, a)), a+=k;
  for (v=j+8, a=k; j<v; j++)
    set_shade_12(i+=n, n, mix(MAGENTA, RED, a)), a+=k;

  return;

  set_shade_12(i+=n, n, mix(RED, YELLOW, 32));
  set_shade_12(i+=n, n, mix(RED, YELLOW, 64));
  set_shade_12(i+=n, n, mix(RED, YELLOW, 128));
  set_shade_12(i+=n, n, mix(RED, YELLOW, 160));
  set_shade_12(i+=n, n, mix(RED, YELLOW, 192));
  set_shade_12(i+=n, n, mix(RED, YELLOW, 224));
  set_shade_12(i+=n, n, YELLOW);
  set_shade_12(i+=n, n, GREEN);
  set_shade_12(i+=n, n, CYAN);
  set_shade_12(i+=n, n, BLUE);
  set_shade_12(i+=n, n, MAGENTA);

  // set_shade_12(i+=n, n, mix(RED, MAGENTA, 144));
}

void palette_fade(uint s, uint e, color a, color b) {
  color c;
  for (c=0; s<e; s++, c++)
    palette[s]=mix(a, b, c*(255/(e-s)));
}

void draw_palette_8() {
  int px=8, py=40,
    x, y, bw=64, bh=48;
  color c;
  BOX box;
  for (y=0, c=0; y<16; y++) {
    for (x=0; x<16; x++, c++) {
      set_box(&box, px+(x*bw), py+(y*bh), bw, bh);
      draw_solid(&box, palette[c]);
    }
  }
}

void draw_palette_12() {
  int px, py, x, y,
    bw=(screen_w-4)/64,
    bh=(screen_h-40)/64;
  px=(screen_w/2)-((bw*64)/2);
  py=(screen_h/2)-((bh*64)/2);
  color c;
  BOX box;
  for (y=0, c=0; y<64; y++) {
    for (x=0; x<64; x++, c++) {
      set_box(&box, px+(x*bw), py+(y*bh), bw, bh);
      draw_solid(&box, palette[c]);
      // draw_box(&box, palette[c], WHITE);
    }
  }
}

// HSL8: HHH.SS.LLL

// HSL12: HHHH.SSSS.LLLL=0-15. HUE...

// HSL16. 0.HHHHH.SSSSS.LLLLL
// 1.NNNNNNN - repeat 7 BIT

  // create_default_palette_8();

  // palette_fade(0, 16, BLACK, BLUE);
  // palette_fade(0, 16, BLACK, 0x777777);
  // palette_fade(16, 32, 0x888888, WHITE);

  /*
  for (i=0; i<16; i++) {
    c=i*15, c=rgb(c, c, c);
    palette[i]=c;
  }
  a=0, b=RED, n=i+16;
  for (c=0; i<n; i++, c++) {
    palette[i]=mix(a, b, c*15);
  }
  a=0, b=BLUE, n=i+16;
  for (c=0; i<n; i++, c++) {
    palette[i]=mix(a, b, c*15);
  }
  */

/*
  graphics_n_colors=16;
  graphics_colors[0]=RED;
  graphics_colors[1]=ORANGE;
  graphics_colors[2]=ORANGE;
  graphics_colors[3]=YELLOW;
  graphics_colors[4]=YELLOW;
  graphics_colors[5]=GREEN;
  graphics_colors[6]=GREEN;
  graphics_colors[7]=BLUE;
  graphics_colors[8]=BLUE;
  graphics_colors[9]=mix50(BLUE, MAGENTA);
  graphics_colors[10]=mix50(BLUE, MAGENTA);
  graphics_colors[11]=PINK;
  graphics_colors[12]=PINK;
  graphics_colors[13]=MAGENTA;
  graphics_colors[14]=MAGENTA;
  graphics_colors[15]=RED;

  BOX box;
  set_box(&box, 8, 44, 256, 256);
  draw_hue_light(&box);
*/

  // draw_rainbow(&box);

  // draw_palette_12();