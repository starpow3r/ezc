// CREATE A SMALL EXAMPLE IMAGE MANUALLY FROM
// AN ARRAY OF PIXELS/COLORS, THEN SET IMAGE
// PIXELS, AND DRAW IT ENLARGED BY 4000%

#include "visual.h"

IMAGE image1;

// small face image: 8x8x32 

#define B 0
#define W 0xFFFFFF
#define Y 0xFFFF00

color face[] = {
  W,W,B,B,B,B,W,W, // head outline
  W,B,Y,Y,Y,Y,B,W,
  B,Y,B,Y,Y,B,Y,B, // 2 eyes
  B,Y,B,Y,Y,B,Y,B,
  B,Y,Y,Y,Y,Y,Y,B,
  B,Y,B,B,B,B,Y,B, // mouth
  W,B,Y,Y,Y,Y,B,W,
  W,W,B,B,B,B,W,W  // chin
};

event_create
  create_screen(328, 360);
  set_title("Create Image");
  create_image(&image1, 8, 8);
  set_image_pixels(&image1, face);
ende

event_draw
  move_image(&image1, 4, 36);
  draw_image_size_p(&image1, 4000);
ende