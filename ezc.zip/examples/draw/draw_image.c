#include "visual.h"

IMAGE image;

event_create
  create_screen(512, 512+36);
  set_title("Draw Image");
  load_image(&image, "tiger");
ende

event_draw
  draw_image_at(&image, 0, 34);
ende