#include "visual.h"

IMAGE image;

event_create
  create_screen(512*3, 512+36);
  set_title("Draw Image in Grayscale/Colorscale");
  load_image(&image, "tiger");
  convert_image_grayscale(&image);
ende

event_draw
  draw_image_at(&image, 0, 34);
  draw_image_cs(&image, 512, 34, DARK_RED, PASTEL_PINK);
  draw_image_cs(&image, 1024, 34, ROYAL_BLUE, BABY_BLUE);
ende