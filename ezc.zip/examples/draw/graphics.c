#include "visual.h"

event_create
  create_screen(1280, 720);
  set_title("Graphics Demonstration: Gradients");
ende

event_draw
  int x=0, y=32, w=(screen_w/2), h=((screen_h-y)/2);
  draw_gradient('v', 'a', x, y, w, h, RED, BLUE);
  draw_gradient('v', 'a', w, y, w, h, NICE_BLUE, BABY_BLUE);
  draw_gradient('v', 'a', x, y+h, w, h, RED_ROSE, YELLOW);
  draw_gradient('v', 'a', w, y+h, w, h, LIME_GREEN, SKY_BLUE);
  draw_bevel(x+(w/2), y+(h/2), w, h, ROYAL_BLUE, BABY_BLUE, 0, 0);
ende