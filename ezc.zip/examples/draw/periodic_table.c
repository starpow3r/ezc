#include "interface.h"
#include "../../include/science/element.h"

FONT big_font, name_font, medium_font, small_font;

int table_x=8, table_y=48, bw=96, bh=96;
int buttons_x=220, buttons_y=48;
int chemical_selected=-1;

object {
  int i, block, x, y;
  color c1, c2, font_c, line_c;
} chemical_t;

void draw_periodic_table();
int get_chemical_theme(chemical_t *theme, int i);

event_create
  create_screen(1812, 960);
  set_screen_color(BLACK);
  set_title("Periodic Table of Chemical Elements");
  if (!load_font(&big_font, "romana/32b"))
    return 0;
  if (!load_font(&name_font, "romana/24b"))
    return 0;
  if (!load_font(&medium_font, "romana/20b"))
    return 0;
  if (!load_font(&small_font, "note/12"))
    return 0;
ende

event_draw
  draw_periodic_table();
ende

event_input
  if (event_mouse_move)
    redraw();
ende

int get_chemical_theme(chemical_t *theme, int i) {
  int x=0, y=0, id=i+1;
  color c1, c2, fc, lc, block=0;
  if (i>N_CHEMICALS)
    return 0;
  block='x', fc=BLACK, c1=SUN_YELLOW, c2=YELLOW;
  if (is_chemical(i, block_s))
    block=CS_BLOCK_S, fc=WHITE, c1=DARK_GREEN, c2=GREEN;
  else if (is_chemical(i, block_d))
    block=CS_BLOCK_D, fc=WHITE, c1=ROYAL_BLUE, c2=BLUE;
  else if (is_chemical(i, block_p))
    block=CS_BLOCK_P, fc=WHITE, c1=DARK_RED, c2=RED;
  else if (is_chemical(i, block_f) or (id>=57 and id<=71)
    or (id>=89 and id<=103))
    block=CS_BLOCK_F, fc=WHITE, c1=PURPLE, c2=LILAC;

  CHEMICAL *p=&periodic_table[i];
  if (p->group) {
    x=table_x+(p->group-1)*(bw+4);
    y=table_y+(p->period-1)*(bh+4);
  }
  if (id>=57 and id<=71) {
    x=table_x+(id-57)*(bw+4)+((bh+4)*2);
    y=table_y+(p->period-1)*(bh+4)+((bh+4)*2);
  }
  if (id>=89 and id<=103) {
    x=table_x+(id-89)*(bw+4)+((bh+4)*2);
    y=table_y+(p->period-1)*(bh+4)+((bh+4)*2);
  }  
  theme->block=block, theme->c1=c1, theme->c2=c2;
  theme->font_c=fc, theme->line_c=WHITE;
  theme->x=x, theme->y=y;
  return 1;
}

void draw_periodic_table() {
  int i, x, y, w=18, h=6, id, block, selected, choice;
  char t[128], symbol[4];
  color fc=WHITE, c1=ROYAL_BLUE, c2=BABY_BLUE;
  BOX box={ 0, 0, 0, 0 }, frame={ 0, 0, 0, 0 };
  choice=-1;
  move_box(&box, buttons_x, buttons_y);
  for (i=CM_NON_METALS; i<=CM_HALLOGENS; i++) {
    c1=ROYAL_BLUE, c2=BLUE;
    print(t, chemical_material_names[i]);
    make_text_box(t, &box);
    box.h=34, box.w+=8;
    if (select_box(&box))
      choice=i;
    if (i==choice)
      c1=NICE_BLUE, c2=BABY_BLUE;
    draw_bevel_b(&box, c1, c2, 0, 4);
    draw_text_in(t, &box, CENTER, 0, 2);
    box.y+=box.h+8;
  }
  box.x=buttons_x+210; box.y=buttons_y;
  for (i=CM_NOBLE_GASES; i<=CM_PRECIOUS_METALS; i++) {
    c1=ROYAL_BLUE, c2=BLUE;
    print(t, chemical_material_names[i]);
    make_text_box(t, &box);
    box.h=34, box.w+=8;
    if (select_box(&box))
      choice=i;
    if (i==choice)
      c1=NICE_BLUE, c2=BABY_BLUE;
    draw_bevel_b(&box, c1, c2, 0, 4);
    draw_text_in(t, &box, CENTER, 0, 2);
    box.y+=box.h+8;
  }

  CHEMICAL *p;
  selected=chemical_selected=-1;
  for (i=0; i<N_CHEMICALS; i++) {
    p=&periodic_table[i];
    id=i+1;
    chemical_t theme;
    get_chemical_theme(&theme, i);
    fc=theme.font_c, c1=theme.c1, c2=theme.c2;
    x=theme.x, y=theme.y;
    BOX box={ x, y, bw, bh };
    if (select_box(&box))
      chemical_selected=i;
    if (i==chemical_selected)
      fc=BLACK, c1=mix50(c1, c2), c1=WHITE;
    else {
      if (choice!=-1)
        fc=WHITE, c1=BLACK, c2=0x404040;
      selected=0;
      if (choice==CM_NON_METALS and
        is_chemical(i, non_metals))
        selected=1;
      else if (choice==CM_ALKALI_METALS and
        is_chemical(i, alkali_metals))
        selected=1;
      else if (choice==CM_ALKALINE_METALS and
        is_chemical(i, alkaline_metals))
        selected=1;
      else if (choice==CM_TRANSITION_METALS and
        is_chemical(i, transition_metals))
        selected=1;
      else if (choice==CM_POST_TRANSITION_METALS and
        is_chemical(i, post_transition_metals))
        selected=1;
      else if (choice==CM_METALLOIDS and
        is_chemical(i, metalloids))
        selected=1;
      else if (choice==CM_HALLOGENS and
        is_chemical(i, hallogens))
        selected=1;
      else if (choice==CM_NOBLE_GASES and
        is_chemical(i, noble_gases))
        selected=1;
      else if (choice==CM_PRECIOUS_METALS and
        is_chemical(i, precious_metals))
        selected=1;

      if (selected)
        fc=WHITE, c1=ROYAL_BLUE, c2=BLUE;
    }
    draw_bevel_b(&box, c1, c2, 0, 8);
    draw_outline(&box, WHITE);
    set_font_c(&big_font, fc);
    text_copy(symbol, p->symbol);
    draw_text_in(symbol, &box, CENTER, 0, -2);
    set_font_c(&small_font, fc);
    text_copy(t, p->name);
    text_limit(t, 10);
    draw_text_in(t, &box, ALIGN_N, 0, 2);
    n2t(id, t);
    set_font_c(&medium_font, fc);
    draw_text_in(t, &box, ALIGN_N, 0, 54);
  }
  set_box(&frame, 716, 43, 484, 295);
  draw_bevel_b(&frame, BLACK, 0x404040, 0, 4);
  
  uint ci;
  if (chemical_selected!=-1) {
    ci=chemical_selected;
    p=&periodic_table[ci];
    box=frame, box.h=48;
    align_in(&box, &frame, ALIGN_N, 0, 8);
    print(t, "#%d. Name: %s (%s)", ci+1, p->name, p->symbol);
    set_font_c(&name_font, WHITE);
    text_limit(t, 28);
    draw_text_a(t, &box, CENTER);
    box.y+=40;
    print(t, "Abundance: %s", p->earth_abundance);
    set_font_c(&medium_font, WHITE);
    draw_text_a(t, &box, CENTER);
    box.y+=32;
    print(t, "Atomic Weight: %s", p->atomic_weight);
    draw_text_a(t, &box, CENTER);
    box.y+=32;
    print(t, "Density: %s", p->density);
    draw_text_a(t, &box, CENTER);
    box.y+=32;
    print(t, "Melting Point: %s", p->melting_point);
    draw_text_a(t, &box, CENTER);
    box.y+=32;
    print(t, "Boiling Point: %s", p->boiling_point);
    draw_text_a(t, &box, CENTER);
    box.y+=32;
    print(t, "Heat Capacity: %s", p->specific_heat_capacity);
    draw_text_a(t, &box, CENTER);
    box.y+=32;
    print(t, "Electronegativity: %s", p->electronegativity);
    draw_text_a(t, &box, CENTER);
    
    set_box(&box, 510, 144, 192, 192);
    draw_bevel_b(&box, BLACK, 0x404040, 0, 12);
    set_font_c(&name_font, WHITE);
    text_copy(t, p->name);
    text_limit(t, 9);
    draw_text_in(t, &box, ALIGN_N, 0, 28);
    set_font_c(&big_font, WHITE);
    draw_text_in(p->symbol, &box, CENTER, 0, 12);
  }
}