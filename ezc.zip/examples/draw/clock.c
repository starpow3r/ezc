// CLOCK. SEE INCLUDE/TIME.H

#define ON_TIMER
#include "visual.h"

FONT time_font;

event_create
  create_screen(500, 160);
  set_screen_color(BLACK);
  set_title("Clock");
  set_timer(1000);
  if (!load_font(&time_font, "romana/64b"))
    bug("Error loading font");
ende

event_draw
  char t[128];
  BOX box;
  TIME now;
  get_time(&now);
  print(t, "%s %s %d, %d. %.2d:%.2d:%.2d %s",
    day_names[now.weekday], month_names[now.month],
    now.day, now.year, now.hour, now.minute, now.second,
    now.xm ? "pm":"am");
  set_font_c(&main_font, WHITE);
  draw_text(t, 70, 44);
  print(t, "%.2d:%.2d:%.2d",
    now.hour, now.minute, now.second);
  set_font_c(&time_font, WHITE);
  draw_text(t, 120, 70);
  outline_screen(BLUE);
ende

event_timer
  redraw();
ende