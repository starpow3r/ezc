// ICON; a transparent image with type,
// state, and optional outline

object {
  uint id, type, state;
  byte used, line_w, cx, cy;
  IMAGE image;
  BOX box;
  color line_color;
  byte line_n;
} ICON;

enum { ICON_NONE=0, ICON_ACTIVE=1, ICON_ENABLED=1,
  ICON_DISABLED=2, ICON_PUSHED=4, ICON_CHECKED=8 };

int load_icon(ICON *icon, text name) {
  char t[128];
  if (!icon)
    return 0;
  icon->state=ICON_NONE,
  icon->box.x=0, icon->box.y=0,
  icon->image.x=0, icon->image.y=0;
  text_copy(t, name);
  remove_ext(t);
  if (icon_folder[0]) {
    /*if (main_path[0])
      print(t, "%s/%s/%s", main_path,
        icon_folder, name);
    else*/
      print(t, "%s/%s", icon_folder, name);
  }
  if (!load_image_t(&icon->image, t))
    return 0;
  icon->state=ICON_ACTIVE;
  icon_memory+=(icon->image.w*icon->image.h*4);
  icon_memory_n++;
  icon_file_size+=image_file_size;
  return 1;
}

void draw_icon(ICON *icon) {
  draw_image_enabled(&icon->image,
    !(icon->state&ICON_DISABLED));
}

void draw_icon_at(ICON *icon, int x, int y) {
  move_image(&icon->image, x, y);
  draw_icon(icon);
}

void move_icon(ICON *icon, int x, int y)
  { move_image(&icon->image, x, y); }

void get_icon_box(ICON *icon, BOX *box)
  { get_image_box(&icon->image, box); }

void set_icon_box(ICON *icon, BOX *box)
  { set_image_box(&icon->image, box); }