// load .BMP 8/24BIT

#define load_image(image, name) load_bmp(image, name)

int load_bmp(IMAGE *image, text name) {
  int i, n, a, o, x, y, c;
  uint w, h, pw, wb, r, g, b,
    bpp, size, offset;
  byte *file=0, *q=0;
  uint *p=0, *palette=0;
  void *fp=0;
  char f[256], t[256];
  text_copy(f, name);
  change_ext(f, "bmp");
  text_copy(t, f);
  if (image_folder[0])
    print(t, "%s/%s", image_folder, f);
  reslash(t);
  if (not file_exists(t)) {
    char cd[256];
    get_directory(cd);
    print(t, "%s/../../%s", cd, f);
    reslash(t);
  }
  if (!(file=load_file(t))) {
    log("Error loading: %s", t);
    show_log();
    goto load_bmp_error;
  }
  fp=file+18, w=(word) *fp;
  fp=file+22, h=(word) *fp;
  fp=file+28, bpp=(int) *fp;
  image->w=w, image->h=h;
  image->x=(screen_w/2)-(w/2);
  image->y=(screen_h/2)-(h/2);
  image->file_type='b';

  if (bpp!=8 and bpp!=24)
    goto load_bmp_error;
  n=w*h, size=n*4;

  if (!allocate(uint *, image->p, size))
    goto load_bmp_error;
  p=image->p;
  image_memory+=size;
  image->file_size=file_size;

  if (bpp==24) {
    image_file_size=size;
    pw=3, offset=0x36;
  }
  else if (bpp==8) {
    image_file_size=n;
    pw=1;
    offset=0x436;
    if (!allocate(uint *, palette, 1024))
      goto load_bmp_error;
    for (i=0; i<256; i++) {
      q=file+0x36+(i*4);
      r=q[2], g=q[1], b=q[0];
      palette[i]=((r<<16)|(g<<8)|b);
    }
  }
  a=(3-((w*pw)+3))&3;
  wb=(w*pw)+a;
  for (y=h; y>0; y--) {
    o=offset+((y-1)*wb);
    for (x=0; x<w; x++) {
      q=file+o+(x*pw);
      if (bpp==8)
        c=palette[*q];
      else if (bpp==24) {
        b=*q++, g=*q++, r=*q;
        c=(r<<16|g<<8|b);
      }
      *p++=c;
    }
  }
  destroy(file);
  destroy(palette);
  return 1;
  load_bmp_error:
  destroy(image->p);
  destroy(file);
  destroy(palette);
  return 0;
}

// load .bmp, then set transparency by
// first pixel color in upper left corner

int load_image_t(IMAGE *image, text name) {
  if (!load_image(image, name))
    return 0;
  image->key=1;
  return 1;
}

// save .BMP

int save_bmp(uint *image, text name,
  int w, int h, int bpp) {
  byte *p, *s, *line, *pixels;
  int x, y, align, n, line_w, wb, size;
  if (!create_file(name))
    return 0;
  align=(3-((w*3)+3))&3;
  wb=(w*3)+align, size=wb*h;
  if (!allocate(byte *, pixels, size)) {
    close_file();
    return 0;
  }
  line_w=w*4;
  if (!allocate(byte *, line, line_w)) {
    close_file();
    destroy(pixels);
    return 0;
  }
  p=pixels, s=(byte *) image;
  s+=((w*4)*(h-1));
  for (y=0; y<h; y++) {
    memory_copy(line, s, line_w);
    convert_pixels_32_24(line, w);
    memory_copy(p, line, wb);
    p+=w*3;
    memory_zero(p, align);
    p+=align, s-=line_w;
  }
  write_1('B'), write_1('M');
  write_4(0), write_4(0), write_4(54);
  write_4(40), write_4(w), write_4(h);
  write_2(1), write_2(24);
  write_4(0), write_4(0);
  write_4(0), write_4(0);
  write_4(0), write_4(0);
  write_file(pixels, size);
  close_file();
  destroy(pixels);
  destroy(line);
  return 1;
}