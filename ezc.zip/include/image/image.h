/* EZC LIBRARY. BY STARPOWER/MYSTERI/OUS.
    __  ___         __          _
  /  |/  /_ _____ / /____ ____(_)
 / /|_/ / // (_-<  __/ -_) __/ /
/_/  /_/\_, /___/\__/\__/_/ /_/
       /___/ (C) 2016+, KID-7/77 */

///////////////////// IMAGE //////////////////////

object {            // 32 bytes: id=ID_IMAGE
  byte id, type,    // tag: 4 bytes
    format, alpha,  // transparent, alpha
    key, file_type; // 'b'/'i'
  int x, y,         // location, size
    w, h, nc;       // transparent. first color
  uint *p,          // pixels, palette
    *palette,
    file_size;
} IMAGE;

int create_image(IMAGE *image, int w, int h);
int set_image_pixels(IMAGE *image, color *pixels);
void draw_image(IMAGE *image);

void get_image_box(IMAGE *image, BOX *box);
void set_image_box(IMAGE *image, BOX *box);

// types: rgb12=X4.R4.G4.B4, rgb15=R5.G5.B5, rgb16=R5.G6.B5,
// argb16=A4.R4.G4.B4, rgb32=X8.R8.G8.B8, argb32=A8.R8.G8.B8
// (a=alpha), palette8=A8, palette4=A4.B4 (2),
// palette2=A2.B2.C2.D2 (4), palette1=A1.B1.C1.D1.E1.F1.G1.H1 (8),
// raster8=A8, raster4=A4.B4 (2), raster3=X2.A3.B3 (2),
// raster2=A2.B2.C2.D2 (4), raster1=A1.B1.C1.D1.E1.F1.G1.H1 (8)

enum {
  IMAGE_DEFAULT=0, IMAGE_RGB12, IMAGE_RGB15,
  IMAGE_RGB16, IMAGE_ARGB16, IMAGE_RGB24,
  IMAGE_RGB32, IMAGE_ARGB32, IMAGE_RASTER1,
  IMAGE_RASTER2, IMAGE_RASTER3, IMAGE_RASTER4,
  IMAGE_RASTER8, IMAGE_PALETTE1, IMAGE_PALETTE2,
  IMAGE_PALETTE4, IMAGE_PALETTE8, IMAGE_PALETTE10
};

int convert_image_32_type(IMAGE *image, int type);
int convert_image_type_32(IMAGE *image, int type);

//////////////////////////////////////////////////

void clear_image(IMAGE *image, color c) {
  for (int i=0; i<image->w*image->h; i++)
    image->p[i]=c;
}
  
int create_image(IMAGE *image, int w, int h) {
  image->w=w, image->h=h;
  if (!allocate(uint *, image->p, w*h*4))
    return 0;
  clear_image(image, WHITE);
  return 1;
}

void destroy_image(IMAGE *image) {
  if (image->p)
    destroy(image->p);
  memory_zero(image, sizeof(IMAGE));
}

int set_image_pixels(IMAGE *image, color *pixels) {
  memory_copy(image->p, pixels, image->w*image->h*4);
  return 1;
}

int copy_image(IMAGE *a, IMAGE *b) {
  memory_copy(a, b, sizeof(IMAGE));
  a->p=0;
  if (!create_image(a, b->w, b->h))
    return 0;
  set_image_pixels(a, b->p);
  return 1;
}

int set_clipboard_image(IMAGE *image) {
  return set_clipboard_bitmap(image->p, image->w, image->h);
}

void move_image(IMAGE *image, int x, int y) {
  image->x=x, image->y=y;
}

void get_image_box(IMAGE *image, BOX *box) {
  box->x=image->x, box->y=image->y;
  box->w=image->w, box->h=image->h;
}

void set_image_box(IMAGE *image, BOX *box) {
  image->x=box->x, image->y=box->y;
  image->w=box->w, image->h=box->h;
}

int select_image(IMAGE *image) {
  return select_it(image->x, image->y,
    image->w, image->h);
}

IMAGE backup_screen;

int set_screen_image(IMAGE *image) {
  IMAGE *ip=&backup_screen;
  ip->p=screen_p, ip->w=screen_w, ip->h=screen_h;
  screen_p=image->p, screen_w=image->w, screen_h=image->h;
  return 1;
}

void end_screen() {
  IMAGE *ip=&backup_screen;
  screen_p=ip->p, screen_w=ip->w, screen_h=ip->h;
}

/* // draw image algorithm:

  for (y=iy; y<iy+h; y++)
    for (x=ix; x<ix+w; x++, p++)
      draw_pixel(x, y, *p);
*/

void draw_image_t(IMAGE *image) {
  int x, y,
    ix=image->x, iy=image->y,
    w=image->w, h=image->h;
  color *p=(color *) image->p, c=*p;
  for (y=iy; y<iy+h; y++)
    for (x=ix; x<ix+w; x++, p++)
      if (*p!=c)
        draw_pixel(x, y, *p);
}

// standard draw image. not optimized

void draw_image(IMAGE *image) {
  int x, y,
    ix=image->x, iy=image->y,
    w=image->w, h=image->h;
  if (!image->p)
    return 0;
  if (image->key) {
    draw_image_t(image);
    return;
  }
  /*
  draw_bitmap(image->p, image->x, image->y,
    image->w, image->h, 0, 0, 0);
  */
  uint *p=(uint *) image->p;
  for (y=iy; y<iy+h; y++)
    for (x=ix; x<ix+w; x++, p++)
      draw_pixel(x, y, *p);
}

void draw_image_at(IMAGE *image, int x, int y) {
  move_image(image, x, y);
  draw_image(image);
}

void draw_image_b(IMAGE *image, BOX *box) {
  draw_image_at(image, box->x, box->y);
}

// draw grayscale image in color/scale

void draw_image_gc(IMAGE *image,
  int ax, int ay, color cs, byte n) {
  move_image(image, ax, ay);
  int x, y,
    ix=image->x, iy=image->y,
    w=image->w, h=image->h;
  color c, shade;
  if (!image->p)
    return 0;
  uint *p=(uint *) image->p;
  for (y=iy; y<iy+h; y++) {
    for (x=ix; x<ix+w; x++, p++) {
      c=*p;
      if (image->key and c==image->p[0])
        continue;
      shade=grayscale_color(c)&0xFF;
      c=mix(BLACK, cs, shade);
      draw_pixel(x, y, c);
    }
  }
}

// colorscale with realistic white highlights. from
// black to color to white instead of black to color

void draw_image_cs(IMAGE *image,
  int ax, int ay, color bc, color cs) {
  move_image(image, ax, ay);
  int x, y,
    ix=image->x, iy=image->y,
    w=image->w, h=image->h;
  color c, shade;
  if (!image->p)
    return 0;
  uint *p=(uint *) image->p;
  for (y=iy; y<iy+h; y++) {
    for (x=ix; x<ix+w; x++, p++) {
      c=*p;
      if (image->key and c==image->p[0])
        continue;
      shade=grayscale_color(c)&0xFF;
      c=mix(bc, cs, shade);
      draw_pixel(x, y, c);
    }
  }
}

void draw_image_gs(IMAGE *image) {
  int x, y,
    ix=image->x, iy=image->y,
    w=image->w, h=image->h;
  color c;
  if (!image->p)
    return 0;
  uint *p=(uint *) image->p;
  for (y=iy; y<iy+h; y++) {
    for (x=ix; x<ix+w; x++, p++) {
      c=*p;
      if (image->key and c==image->p[0])
        continue;
      c=grayscale_color(c)&0xFF;
      c=rgb(c, c, c);
      draw_pixel(x, y, c);
    }
  }
}

// draw disabled icon. darker

void draw_image_disabled(IMAGE *image) {
  int x, y,
    ix=image->x, iy=image->y,
    w=image->w, h=image->h;
  color *p=(color *) image->p, key=*p, c;
  for (y=iy; y<iy+h; y++)
    for (x=ix; x<ix+w; x++, p++) {
      c=*p;
      if (c==key)
        continue;
      // c=grayscale_color(c); // optional
      c=darken_color(c, 144);
      draw_pixel(x, y, c);
    }
}

void draw_image_enabled(IMAGE *image, int enabled) {
  if (enabled)
    draw_image(image);
  else
    draw_image_disabled(image);
}

// draw image at different size. zoom feature.
// for accuracy, multiply w/h by 64k (<<16)
// then divide. this doesn't edit pixels like
// flip/rotate .2-do: image view size:
// image.vw/.vh. if not 0 and not same as w/h,
// draw at another size. also .vp = view percentage.
// if not 0 and not 100

int draw_image_size(IMAGE *image, int w, int h) {
  int x=image->x, y=image->y,
    iw=image->w, ih=image->h,
    rx, ry, ix, iy; // scale=64*KB
  color *p=(color *) image->p;
  if (w==iw and h==ih) {
    draw_image(image);
    return 1;
  }
  // ratio=(size*scale)/new_size
  rx=(iw<<16)/w, ry=(ih<<16)/h;
  for (y=0; y<h; y++) {
    for (x=0; x<w; x++) {
      // location=(n*ratio)/scale
      ix=(x*rx)>>16, iy=(y*ry)>>16;
      // screen_p[(y*w)+x]=p[(iy*iw)+ix];
      draw_pixel(image->x+x, image->y+y,
        p[(iy*iw)+ix]);
    }
  }
  return 1;
}

int get_image_zoom_w(IMAGE *image, int p) {
  return (image->w/((float) 100/p));
}

int get_image_zoom_h(IMAGE *image, int p) {
  return (image->h/((float) 100/p));
}

void get_image_zoom(IMAGE *image, BOX *box, int p) {
  box->x=image->x, box->y=image->y;
  box->w=get_image_zoom_w(image, p);
  box->h=get_image_zoom_h(image, p);
}

// by percentage. integer

int draw_image_size_p(IMAGE *image, int p) {
  if (p==100) {
    draw_image(image);
    return 1;
  }
  int w=get_image_zoom_w(image, p),
    h=get_image_zoom_h(image, p);
  draw_image_size(image, w, h);
  return 1;
}

void align_image(IMAGE *image, BOX *box, int a) {
  BOX b;
  get_image_box(image, &b);
  align_box(&b, box, a);
  move_image(image, b.x, b.y);
}

void draw_image_outline(IMAGE *image, color c) {
  draw_image(image);
  BOX box;
  get_image_box(image, &box);
  draw_outline(&box, c);
}

// draw image enlarged by 200%/400%/800%

void draw_image_x2(IMAGE *image) {
  int x, y,
    ix=image->x, iy=image->y,
    w=image->w, h=image->h;
  color *p=(color *) image->p,
    key=*p;
  for (y=iy; y<iy+(h*2); y+=2)
    for (x=ix; x<ix+(w*2); x+=2, p++) {
      if (image->key and *p==key)
        continue;
      draw_pixel(x, y, *p);
      draw_pixel(x+1, y, *p);
      draw_pixel(x, y+1, *p);
      draw_pixel(x+1, y+1, *p);
    }
}

void draw_image_x4(IMAGE *image) {
  int x, y,
    ix=image->x, iy=image->y,
    w=image->w, h=image->h;
  color *p=(color *) image->p,
    key=*p;
  for (y=iy; y<iy+(h*4); y+=4)
    for (x=ix; x<ix+(w*4); x+=4, p++) {
      if (image->key and *p==key)
        continue;
      draw_pixel(x, y, *p);
      draw_pixel(x+1, y, *p);
      draw_pixel(x+2, y, *p);
      draw_pixel(x+3, y, *p);
      draw_pixel(x, y+1, *p);
      draw_pixel(x+1, y+1, *p);
      draw_pixel(x+2, y+1, *p);
      draw_pixel(x+3, y+1, *p);
      draw_pixel(x, y+2, *p);
      draw_pixel(x+1, y+2, *p);
      draw_pixel(x+2, y+2, *p);
      draw_pixel(x+3, y+2, *p);
      draw_pixel(x, y+3, *p);
      draw_pixel(x+1, y+3, *p);
      draw_pixel(x+2, y+3, *p);
      draw_pixel(x+3, y+3, *p);
    }
}

void draw_image_x8(IMAGE *image) {
  int x, y, z, q,
    ix=image->x, iy=image->y,
    w=image->w, h=image->h;
  color *p=(color *) image->p,
    key=*p;
  for (y=iy; y<iy+(h*8); y+=8) {
    for (x=ix; x<ix+(w*8); x+=8, p++) {
      if (image->key and *p==key)
        continue;
      for (z=0; z<8; z++)
        for (q=0; q<8; q++)
        draw_pixel(x+z, y+q, *p);
    }
  }
}

// draw image at 50%/25%, divided by 2/4

void draw_image_d2(IMAGE *image) {
  int x, y,
    *p=(int *) image->p,
    ix=image->x, iy=image->y,
    w=image->w, h=image->h;
  for (y=iy; y<iy+(h/2); y++) {
    for (x=ix; x<ix+(w/2); x++, p+=2)
      draw_pixel(x, y, *p);
    p+=w;
  }
}

void draw_image_d4(IMAGE *image) {
  int x, y,
    *p=(int *) image->p,
    ix=image->x, iy=image->y,
    w=image->w, h=image->h;
  for (y=iy; y<iy+(h/4); y++) {
    for (x=ix; x<ix+(w/4); x++, p+=4)
      draw_pixel(x, y, *p);
    p+=w*3;
  }
}

// for document.h

int image_view=100, image_view_n=10,
  image_view_minimum=10, image_view_maximum=125,
  image_view_maximum_h=0;
BOX zoom_box, image_document_box;

void center_image_zoom(IMAGE *image) {
  get_image_zoom(image, &zoom_box, image_view);
  align_box(&zoom_box, &image_document_box, CENTER);
  move_image(image, zoom_box.x, zoom_box.y);
}

void zoom_image_in(IMAGE *image) {
  if (image_view<=image_view_maximum-image_view_n)
    image_view+=image_view_n;
  else
    image_view=image_view_maximum;
  center_image_zoom(image);
}

void zoom_image_out(IMAGE *image) {
  if (image_view>image_view_n)
    image_view-=image_view_n;
  else
    image_view=image_view_n;
  if (image_view<image_view_minimum)
    image_view=image_view_minimum;
  center_image_zoom(image);
}

// flip 'h'orizontal or 'v'ertical

int flip_image(IMAGE *image, int way) {
  int x, y, w=image->w, h=image->h;
  color *p=0, *s=image->p;
  if (!allocate(color *, p, w*h*4))
    return 0;
  if (way=='h') {
    for (y=0; y<h; y++)
      for (x=0; x<w; x++)
        p[x+(y*w)]=s[(w-x-1)+(y*w)];
  }
  else if (way=='v') {
    for (y=0; y<h; y++)
      memory_copy(&p[y*w], &s[(h-y-1)*w], w*4);  
  }
  destroy(s);
  image->p=p;
  return 1;
}

// rotate left or right, '<' or '>'

int rotate_image(IMAGE *image, int way) {
  int x, y, w=image->w, h=image->h, co, ro;
  color *p=0, *s=image->p;
  if (!allocate(color *, p, w*h*4))
    return 0;
  if (way=='<') {
    for (y=co=0; y<h; y++, co++)
      for (x=0, ro=w-1; x<w; x++, ro--)
        p[(ro*h)+co]=s[(y*w)+x];
  }
  else if (way=='>') {
    for (y=0, co=h-1; y<h; y++, co--)
      for (x=0; x<w; x++)
        p[(x*h)+co]=s[(y*w)+x];
  }
  image->w=h, image->h=w; // reverse
  // image->x+=w/2, image->y+=h/2; // center
  destroy(s);
  image->p=p;
  return 1;
}

// is blank scanline in image? return 1 if
// all pixels=key. 0 otherwise

int is_blank_line(color *p, color key, int w) {
  for (int i=0; i<w; i++, p++)
    if (*p!=key)
      return 0;
  return 1;
}

int is_blank_line_v(color *p, color key, int w, int h) {
  for (int i=0; i<h; i++, p+=w)
    if (*p!=key)
      return 0;
  return 1;
}

int is_visible_line(color *p, color key, int w) {
  for (int i=0; i<w; i++, p++)
    if (*p!=key)
      return 1;
  return 0;
}

int is_visible_line_v(color *p, color key, int w, int h) {
  for (int i=0; i<h; i++, p+=w)
    if (*p!=key)
      return 1;
  return 0;
}
int is_visible_h(color *p, int w) {
  uint i, c;
  for (i=0; i<w; i++, c=*p++)
    if ((c&0xF)<=0xF)
      return 0;
  return 1;
}

int is_visible_v(color *p, int w, int h) {
  uint i, c;
  for (i=0; i<h; i++, c=*p, p+=w)
    if ((c&0xF)<=0xF)
      return 0;
  return 1;
}

void draw_image_texture(IMAGE *image,
  int x, int y, int w, int h) {
  int i, j;
  for (j=0; j<h; j++)
    for (i=0; i<w; i++)
      draw_image_at(image,
        x+(i*image->w), y+(j*image->h));
}

void draw_image_shade(IMAGE *image,
  IMAGE *shade, int alpha) {
  int x, y, c;
  uint *p=(uint *) image->p,
    *q=(uint *) shade->p;
  int ix=image->x, iy=image->y,
    w=image->w, h=image->h;
  for (y=iy; y<iy+h; y++)
    for (x=ix; x<ix+w; x++, p++, q++) {
      c=mix(*q, *p, *q&0xFF);//alpha);
      draw_pixel(x, y, c);
    }
}

void draw_image_mix(IMAGE *image,
  int c, int alpha) {
  int x, y, c2;
  uint *p=(uint *) image->p;
  int ix=image->x, iy=image->y,
    w=image->w, h=image->h;
  for (y=iy; y<iy+h; y++)
    for (x=ix; x<ix+w; x++, p++) {
      c2=mix(c, *p, alpha);
      draw_pixel(x, y, c2);
    }
}

void draw_image_mix_t(IMAGE *image, color c, int alpha) {
  int x, y, c2;
  uint *p=(uint *) image->p;
  int ix=image->x, iy=image->y,
    w=image->w, h=image->h;
  for (y=iy; y<iy+h; y++)
    for (x=ix; x<ix+w; x++, p++) {
      if (*p!=*image->p) {
        c2=mix(c, *p, alpha);
        draw_pixel(x, y, c2);
      }
    }
}

// convert pixels from 32 to 24

void convert_pixels_32_24(byte *p, uint n) {
  uint i;
  byte *q=p;
  for (i=0; i<n; i++, q+=4)
    *p++=*(q+0), *p++=*(q+1), *p++=*(q+2);
}

// is color in palette? return index or -1

int find_color(uint *palette, uint c, int n) {
  int i;
  for (i=0; i<n; i++)
    if (palette[i]==c)
      return i;
  return -1;
}

int unique_color(uint *palette, uint c, int n) {
  return find_color(palette, c, n)==-1;
}

// create 1-12BIT palette from image

int palette_n_colors=0;

uint create_image_palette(IMAGE *image) {
  int i, n, c, nc=0;
  if (!image->palette)
    if (!allocate(uint *, image->palette, 4096*4))
      return 0;
  color *palette=image->palette;
  memory_zero(palette, 4096*4);
  n=image->w*image->h;
  for (i=0; i<n and i<4095; i++) {
    c=image->p[i];
    if (unique_color(palette, c, nc)) {
      palette[nc++]=c;
      if (nc>=4094)
        break;
    }
  }
  image->nc=nc, palette_n_colors=nc;
  return nc;
}

// get # bits required for color index
// (edit: use "bsr; bit scan reverse")

int color_bits(uint *palette, uint c, int n) {
  int i=find_color(palette, c, n);
  if (i==-1) return 0;
  if (i<=1) return 1;
  if (i<=3) return 2;
  if (i<=7) return 3;
  if (i<=15) return 4;
  if (i<=31) return 5;
  if (i<=63) return 6;
  if (i<=127) return 7;
  if (i<=255) return 8;
  if (i<=1023) return 10;
  return 12;
}

uint get_repeat_n(uint *pixels, int max) {
  uint n, *p=pixels, c=*p;
  if (p[0]!=p[1])
    return 0;
  p++;
  for (n=1; p[1]==c and n<=max; n++, p++);
  return n;
}

// IMAGE CONVERSIONS:

// image palettes for draw_image_1/2/3/4/8/10/12
// which is 2/4/8/16/256/1024/4096 colors.
// grayscale by default

color image_palette_1[2]={ BLACK, WHITE };

color image_palette_2[4]={ BLACK, 0x444444,
  0xCCCCCC, WHITE };

color image_palette_3[8]={
  BLACK, 0x252525, 0x4A4A4A, 0x6F6F6F,
  0x949494, 0xB9B9B9, 0xDEDEDE, WHITE };

color image_palette_4[16]={
  BLACK, 0x111111, 0x222222, 0x333333,
  0x444444, 0x555555, 0x666666, 0x777777,
  0x888888, 0x999999, 0xAAAAAA, 0xBBBBBB,
  0xCCCCCC, 0xDDDDDD, 0xEEEEEE, WHITE };

color *image_palette_8=0, *image_palette_10=0,
  *image_palette_12=0;

// convert image from RGB 32 to 1 BPP monochrome

void convert_image_1(IMAGE *image) {
  int i=0, x, bit=7,
    w=image->w, h=image->h, n=w*h;
  color *s=(color *)
    image->p, c;
  byte *p=(byte *) s, by=0;
  for (x=0; x<n; x++) {
    c=s[x];
    if ((grayscale_color(c)&0xFF)>=0x80)
      by|=(1<<bit); // set
    else
      by&=~(1<<bit); // zero
    if (--bit<0) // next byte
      bit=7, p[i++]=by, by=0;
  }
  if (bit<7) // last byte
    p[i]=by;
}

// draw image 1 BPP monochrome

void draw_image_1(IMAGE *image) {
  int i=0, x, y, bit=7,
    ix=image->x, iy=image->y,
    w=image->w, h=image->h,
    right=ix+w, bottom=iy+h;
  byte *p=(byte *) image->p;
  color c,
    *palette=image_palette_1;
  for (y=iy; y<bottom; y++) {
    for (x=ix; x<right; x++) {
      c=p[i]&(1<<bit);
      if (!c)
        c=palette[0];
      else
        c=palette[1];
      draw_pixel(x, y, c);
      if (--bit<0) // next byte
        bit=7, i++;
    }
  }
}

// convert image from RGB 32 to 2 BPP grayscale

void convert_image_2(IMAGE *image) {
  int i=0, x, j=0, bit=6,
    w=image->w, h=image->h, n=w*h;
  color *s=(color *)
    image->p, c;
  byte *p=(byte *) s, by=0;
  for (x=0; x<n; x++) {
    c=grayscale_color(s[x])&0xFF;
    if (c<0x44) // BLACK
      j=0;
    else if (c<0x88) // DARK GRAY
      j=1;
    else if (c<0xCC) // LIGHT GRAY
      j=2;
    else // WHITE
      j=3;
    by|=(j<<bit); // 76543210
    bit-=2;
    if (bit<0) // next byte
      bit=6, p[i++]=by, by=0;
  }
  if (bit<6) // last byte
    p[i]=by;
}

// draw image with 2 BPP palette

void draw_image_2(IMAGE *image) {
  int i=0, x, y, bit=6,
    ix=image->x, iy=image->y,
    w=image->w, h=image->h,
    right=ix+w, bottom=iy+h;
  byte *p=(byte *) image->p;
  color c,
    *palette=image_palette_2;
  for (y=iy; y<bottom; y++) {
    for (x=ix; x<right; x++) {
      c=(p[i]>>bit)&3;
      draw_pixel(x, y, palette[c]);
      bit-=2;
      if (bit<0)
        bit=6, i++;
    }
  }
}

// convert image from RGB 32 to 4 BPP grayscale

void convert_image_4(IMAGE *image) {
  int i=0, x,
    w=image->w, h=image->h, n=w*h;
  color *s=(color *)
    image->p, c;
  byte *p=(byte *) s, by=0;
  for (x=0; x<n; x++) {
    c=(grayscale_color(s[x])&0xFF)/16;
    if (!(x&1))
      by|=(c<<4);
    else {
      by|=c, p[i++]=by, by=0;
    }
  }
  if (x&1)
    p[i]=by;
}

// draw image with 4 BPP palette

void draw_image_4(IMAGE *image) {
  int i=0, x, y,
    ix=image->x, iy=image->y,
    w=image->w, h=image->h,
    right=ix+w, bottom=iy+h;
  byte *p=(byte *) image->p;
  color c,
    *palette=image_palette_4;
  for (y=iy; y<bottom; y++) {
    for (x=ix; x<right; x++) {
      c=p[i];
      if (x&1)
        c>>4, i++;
      draw_pixel(x, y, palette[c&0xF]);
    }
  }
}

// convert image from RGB 32 to grayscale

void convert_image_grayscale(IMAGE *image) {
  uint i, n=image->w*image->h;
  color *p=(color *) image->p;
  for (i=0; i<n; i++)
    p[i]=grayscale_color(p[i]);
}