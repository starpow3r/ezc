//////////////////// CAPTION /////////////////////

uint caption_show=1, caption_graphics=G_SHADE+G_OUTLINE+G_SHADOW;
color caption_font_color=WHITE, caption_line_color=WHITE,
  caption_color=ROYAL_BLUE, caption_fade_color=BLACK,
  caption_shadow_color=LILAC;
uint caption_x=0, caption_y=0, caption_w=0, caption_ix=0,
  caption_line_w=1, caption_shadow_alpha=0,
  caption_shadow_x=-3, caption_shadow_y=3, caption_right=0;

void set_caption_colors(color c1, color c2, color lc, color fc) {
  caption_fade_color=c1, caption_color=c2;
  caption_line_color=lc, caption_font_color=fc;
}

void reset_caption_colors() {
  set_caption_colors(BLACK, 0x404040, WHITE, WHITE);
}

void set_caption_graphics(uint g) { caption_graphics=g; }
void set_caption_w(int w) { caption_w=w; }
void set_caption_ix(int ix) { caption_ix=ix; }
void move_caption(int x, int y) { caption_x=x, caption_y=y; }

void draw_caption(text t, int x, int y) {
  BOX box;
  if (!caption_show)
    return;
  if (!t or !*t)
    return;
  if (!x and caption_x)
    x=caption_x;
  if (!y and caption_y)
    y=caption_y;
  if (x==-1 or y==-1)
    return;
  if (caption_right)
    x=caption_right;
  make_text_box_at(t, &box, x, y);
  if (caption_right)
    x-=box.w, box.x-=box.w;
  x+=caption_ix;
  if (caption_w)
    box.w=caption_w;
  uint g=caption_graphics;
  if (g&G_SOLID)
    draw_solid(&box, caption_color);
  else if (g&(G_FADE|G_SHADE|G_CHROME)) {
    color a=caption_fade_color, b=caption_color;
    if (g&G_FADE)
      draw_fade_d(&box, 'v', a, b);
    else if (g&G_SHADE)
      draw_shade_d(&box, 'v', a, b);
    else if (g&G_CHROME)
      draw_chrome2(&box, a, b);
  }
  if (g&G_OUTLINE)
    draw_outline(&box, caption_line_color);
  set_font_color(caption_font_color);
  draw_text(t, x+inset_x, y+inset_y+2);
}

void draw_caption_x(text t) {
  draw_caption(t, 0, 0);
}

void draw_caption_b(text t, BOX *box) {
  draw_caption(t, box->x, box->y);
}

// display caption for 2 seconds

text status_message=0;
uint show_status=0, status_timer=0,
  status_delay=2000;

int setup_status() {
  if (!allocate(text, status_message, 256))
    return 0;
  return 1;
}

void set_status_message(text t) {
  if (!status_message)
    if (!setup_status())
      return 0;
  text_copy(status_message, t);
  status_timer=get_ms();
  show_status=1;
}

void draw_status_message() {
  uint ms;
  if (!show_status or !status_message[0])
    return;
  ms=get_ms();
  if (ms-status_timer<status_delay)
    draw_caption(status_message, 0, 0);
  else
    show_status=0;
}