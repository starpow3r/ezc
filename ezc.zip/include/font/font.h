/* EZC LIBRARY. BY STARPOWER/MYSTERI/OUS.
    __  ___         __          _
  /  |/  /_ _____ / /____ ____(_)
 / /|_/ / // (_-<  __/ -_) __/ /
/_/  /_/\_, /___/\__/\__/_/ /_/
       /___/ (C) 2016+, KID-7/77 */

// load custom font, and draw characters,
// text, and source code with colors

///////////////////// FONT ///////////////////////

// custom "bitmap font". advantages: 100%
// customizable, portable to anything,
// lightning fast, no limitations.
// w/h are symbol size (example: 16x32).
// n=# symbols. default 95. ix/iy is the
// inset between symbols.

/* // generic monospace version

object {
  char name[24]; // example: "Console"
  uint type;     // FONT_MONOSPACE
  uint w, h, n;  // glyph size. n=95
  color c;       // current color
  IMAGE image;   // font glyphs
} FONT;
*/

object {
  uint id, type;    // =ID_FONT, |=FONT_x
  char name[24];    // example: "Console"
  uint w, h, n;     // glyph size. n=95
  uint file_size;
  byte width, format, extra,
    nc, effect, italic;
  char ix, iy, sx, sy;
  int *xs, *widths;
  BOX *boxes;
  uint italic;
  color c;          // current color
  color fc, lc, sc; // fade, line, shadow
  color colors[16]; // gradient
  int shx, shy;     // shadow offset
  IMAGE image;      // glyphs
} FONT;

enum { FONT_DEFAULT=0, FONT_MONOSPACE=1,
  FONT_VARIABLE_W=2, FONT_VARIABLE_H=4,
  FONT_INVERT=8, FONT_SOLID=16, FONT_OUTLINE=32,
  FONT_BOLD=64, FONT_ITALIC=128, FONT_RASTER=256,
  FONT_FADE=512, FONT_BITMAP=1*KB, FONT_RAINBOW=2*KB,
  FONT_SHADOW=4*KB, FONT_SPECIAL=8*KB, FONT_EFFECT=16*KB,
  FONT_FILE=32*KB };

// current font

FONT font, old_font;
ARRAY system_fonts;

///////////////////// SYMBOLS //////////////////////

// default arrangement. 95 standard characters

/*
0123456789ABCDEFGHI
JKLMNOPQRSTUVWXYZab
cdefghijklmnopqrstu
vwxyz_.?;:'",~!@#$%
^&*()[]{}=+-<>/\|`
*/

#define N_SYMBOLS 95
#define SPACE_W char_w('o')

text font_table=
  "0123456789ABCDEFGHI" \
  "JKLMNOPQRSTUVWXYZab" \
  "cdefghijklmnopqrstu" \
  "vwxyz_.?;:'\",~!@#$%" \
  "^&*()[]{}=+-<>/\\|`";

// symbol table to convert character 'c'
// to index. 0x7F=space/' ' or invisible

char font_symbols[128]={
  0x7F,0x7F,0x7F,0x7F,0x7F,0x7F,0x7F,0x7F,
  0x7F,0x7F,0x7F,0x7F,0x7F,0x7F,0x7F,0x7F,
  0x7F,0x7F,0x7F,0x7F,0x7F,0x7F,0x7F,0x7F,
  0x7F,0x7F,0x7F,0x7F,0x7F,0x7F,0x7F,0x7F,
  0x7F,0x47,0x44,0x49,0x4A,0x4B,0x4D,0x43,
  0x4F,0x50,0x4E,0x56,0x45,0x57,0x3F,0x5A,
  0x00,0x01,0x02,0x03,0x04,0x05,0x06,0x07,
  0x08,0x09,0x42,0x41,0x58,0x55,0x59,0x40,
  0x48,0x0A,0x0B,0x0C,0x0D,0x0E,0x0F,0x10,
  0x11,0x12,0x13,0x14,0x15,0x16,0x17,0x18,
  0x19,0x1A,0x1B,0x1C,0x1D,0x1E,0x1F,0x20,
  0x21,0x22,0x23,0x51,0x5B,0x52,0x4C,0x3E,
  0x5D,0x24,0x25,0x26,0x27,0x28,0x29,0x2A,
  0x2B,0x2C,0x2D,0x2E,0x2F,0x30,0x31,0x32,
  0x33,0x34,0x35,0x36,0x37,0x38,0x39,0x3A,
  0x3B,0x3C,0x3D,0x53,0x5C,0x54,0x46,0x7F
};

#define inset_x (font.w-(font.w/4))
#define inset_y ((font.h/4)+2)
#define inset_w (font.w+(font.w/2))
#define inset_h ((font.h/2)+1)

void set_font(FONT *f) {
  if (!f)
    return;
  if (&old_font!=&font)
    old_font=font;
  if (&font!=f)
    font=*f;
}

int get_font(FONT *f) {
  if (!f)
    return 0;
  if (&font!=f)
    *f=font;
}

void set_font_type(uint type) { font.type=type; }
void set_font_color(color c) { old_font.c=font.c, font.c=c; }
void reset_font() { set_font(&old_font); }

void set_font_c(FONT *f, color c) {
  set_font(f);
  set_font_color(c);
}

void destroy_font(FONT *f) {
  destroy(f->image.p);
  destroy(f->xs);
  destroy(f->widths);
  destroy(f->boxes);
}

// get character width in current font

int char_w(char c) {
  if (font.type&FONT_MONOSPACE)
    return font.w;
  if (!c or (c<0x20 or c>=0x7F))
    return 0;
  if (is_space(c))
    c='o';
  return font.boxes[font_symbols[c]].w;
}

int char_h(char c) {
  return font.h; // could be variable
}

int new_char_w(char c) {
  if (font.type&FONT_MONOSPACE)
    return font.w;
  if (!c or (c<0x20 or c>=0x7F))
    return 0;
  if (is_space(c))
    c='o';
  if (font.type&FONT_VARIABLE_W)
    return font.widths[font_symbols[c]];
  if (font.type&FONT_BITMAP)
    return font.boxes[font_symbols[c]].w;
  return 0;
}

int real_char_w(char c) {
  return font.boxes[font_symbols[c]].w;
}

// get total width of "text" in current font.
// if single line: monospace? w=length*font.w.
// variable w? w=length+font.widths.
// if multiline: w=longest line to create a box
// that contains it. gw=greatest width. example:

// [ "hi. this is"    ] // invisible return after
// [ "multiline text" ] // < longest line

uint text_w(text t) {
  uint w, gw;
  text p=t;
  for (gw=0; *p;) {
    for (w=0; *p and *p!=0xD; p++)
      w+=char_w(*p);
    if (*p==0xD)
      p+=2;
    if (w>gw)
      gw=w;
  }
  return gw;
}

uint text_h(text t) {
  return font.h*text_count_lines(t);
}

// get character x inside t.
// send start t then c address

uint char_x(text t, text c) {
  uint x;
  for (x=0; *t and t<c; t++)
    x+=char_w(*t);
  return x;
}

// create box the size of text in
// current font. optional insets

void make_text_b(text t, BOX *b) {
  b->w=text_w(t), b->h=text_h(t);
}

void make_text_box(text t, BOX *b) {
  b->w=text_w(t)+inset_w;
  b->h=text_h(t)+inset_h;
}

void make_text_box_at(text t, BOX *b, int x, int y) {
  b->x=x, b->y=y;
  b->w=text_w(t)+inset_w;
  b->h=text_h(t)+inset_h;
}

void make_text_box_wide(text t, BOX *b) {
  b->w=text_w(t)+(font.w*2);
  b->h=text_h(t)+(font.h);
}

// make text box (b) with alignment inside 
// another box (in). optional nudge x/y+=n after

void make_text_box_a(text t, BOX *b, BOX *in, int a) {
  make_text_box(t, b);
  align_box(b, in, a);
}

void make_text_box_in(text t, BOX *b, BOX *in,
  int align, int nx, int ny) {
  make_text_box_a(t, b, in, align);
  b->x+=nx, b->y+=ny;
}

// copy next line a=b until width. return advanced
// address of b

text text_get_line_w(text a, text b, int tw) {
  int i, w;
  text p=a, q=b;
  q=skip_space(q);
  if (!*q)
    return 0;
  // copy line until width
  for (w=0; *q and w<tw and !is_return(*q);
    *p++=*q++) {
    w+=char_w(*q);
    if (w>=tw) {
      // copy zeros backwards until previous word
      for (; !is_space(*q) and q>b;
        *p--=0, q--);
      for (; is_space(*q); *p--=0, q--);
      p++, q++;
      break;
    }
  }
  if (is_return(*q))
    q+=2;
  *p=0;
  return q;
}

// remove return/s. replace with spaces. return #

uint text_remove_returns(text t) {
  uint n;
  text a=t, b=t;
  for (n=0; *b; *a++=*b++)
    while (is_return(*b))
      *a++=' ', b++, n++;
  return n;
}

// insert return/s at width. remove return/s first.
// for "word wrap". a=b

void text_wrap(text a, text b, int tw) {
  text p=b;
  char s[1024];
  a[0]=0;
  text_remove_returns(p);
  while (*p) {
    p=text_get_line_w(s, p, tw);
    text_attach(a, s);
    text_attach_c(a, 0xD);
    text_attach_c(a, 0xA);
  }
}