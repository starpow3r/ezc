// FONT

// ignore this

color outline_shades[16]={
  0xe0ffe0, 0xc0ffc0, 0xa0ffa0, 0x80ff80,
  0x60ff60, 0x40ff40, 0x20ff20, 0x00ff00,
  0x00e000, 0x00d000, 0x00c000, 0x00a000,
  0x008000, 0x006000, 0x004000, 0x002000
};

// load .FONT. minimal version

int load_font(FONT *f, text name) {
  int i, j, x, y, w, h,
    bx, by, bw, bh, ws, iw, ih, in,
    sx, sy, sb, sa, cs;
  byte mode, type, format, width, license;
  char t[256], s[256], cd[256];
  text names;
  IMAGE *image=&font.image;
  uint pixel, *destiny, *q, re, im, n,
    c, c2, size, length=48;
  byte *pixels, *chs, *z;
  void *vp, *p;
  BOX box;
  text_copy(t, name);
  change_ext(t, "font");

  // set font name/size from media/font/roman/16.font

  extract_folder(font.name, t); // roman
  extract_file(s, t); // 16.font
  remove_ext(s); // 16
  text_attach_c(font.name, '/'); // roman/16
  text_attach(font.name, s);

  if (font_folder[0]) {
    print(s, "%s/%s", font_folder, t);
    if (not file_exists(s))
      print(s, "../../%s/%s", font_folder, t);
    text_copy(t, s);
  }

  byte *file=load_file(t);
  if (!file) {
    source_error("Font doesn't exist: %s", t);
    return 0;
  }
  
  font.file_size=file_size;
  font.ix=0, font.iy=0;

  if (!allocate(int *, font.xs, 96*4))
    return 0;
  if (!allocate(int *, font.widths, 96*4))
    return 0;
  if (!allocate(BOX *, font.boxes, 96*16))
    return 0;

  type=*(byte *) &file[0x04];
  width=*(byte *) &file[0x05];
  format=*(byte *) &file[0x06];
  cs=*(byte *) &file[0x09];
  n=*(uintw *) &file[0x0A];
  bw=*(uintw *) &file[0x0C];
  bh=*(uintw *) &file[0x0E];
  ws=*(uintw *) &file[0x10];
  font.sx=*(intw *) &file[0x12];
  font.sy=*(intw *) &file[0x14];
  im=*(uint *) &file[0x16];
  size=*(uint *) &file[0x1A];
  iw=*(uintw *) &file[0x1E];
  ih=*(uintw *) &file[0x20];
  chs=file+0x60;

  if (im)
    vp=(byte *) file+im;
  else
    vp=(byte *) file+0x640;
  pixels=vp;

  font.type|=FONT_FILE;

  if (width=='M')
    font.type|=FONT_MONOSPACE, font.type&=~FONT_VARIABLE_W;
  if (width=='V')
    font.type|=FONT_VARIABLE_W, font.type&=~FONT_MONOSPACE;
  if (format=='C')
    ;
  if (format=='O')
    font.type|=FONT_OUTLINE;
  if (format=='S')
    font.type|=FONT_SHADOW;
  if (format=='0')
    font.type|=FONT_OUTLINE|FONT_SHADOW;
  if (format=='$')
    font.type|=FONT_OUTLINE|FONT_SHADOW|FONT_SPECIAL;
  font.n=n;

  for (i=0; i<n; i++) {
    z=(byte *) chs+(i*16);
    box.x=*(intw *) &z[2], box.y=*(intw *) &z[4];
    box.w=*(intw *) &z[6], box.h=*(intw *) &z[8];
    font.boxes[i]=box, font.xs[i]=box.x,
    font.widths[i]=box.w;
  }

  if (!create_image(image, iw, ih))
    return 0;
  destiny=image->p;
  font.w=font.boxes[32].w, font.h=ih;

  uint ip=0, id=0;
  color previous=0;

  for (i=0; i<size; i++) {
    c=pixels[ip++]; // read 1 byte
    mode=(c>>4)&0xF;
    n=c&0xF;
    if (c==0)
      c=WHITE;
    else if (c==0x10)
      c=BLACK;
    else if (mode==2) // color
      c=n*17, c=rgb(c, c, c);
    else if (mode==3) // outline
      c=outline_shades[n];
    else if (mode==0 or mode==1) { // in/visible 4bit
      if (mode==0)
        c=WHITE;
      else
        c=BLACK;
      for (j=0; j<=n; j++) // <=n includes first
        destiny[id++]=c;
      previous=c;
      continue;
    }
    else if (mode==0xE) { // repeat
      n=((c&0xF)<<8)|
        pixels[ip++];
      c=previous;
      for (j=0; j<n; j++)
        destiny[id++]=c;
      continue;
    }
    destiny[id++]=c, previous=c;
  }

  *f=font;
  //add_system_font(&font);
  destroy(file);
  return 1;
}

int add_system_font(FONT *f) {
  if (!system_fonts.p) {
    if (!array_create(&system_fonts, sizeof(FONT)))
      return 0;
  }
  FONT *p=array_expand(&system_fonts);
  if (!p)
    return 0;
  *p=*f;
  system_fonts.i=system_fonts.n-1;
  return 1;
}

// get real font name ("roman/16") from filename
// ("media/font/roman/16.font")

int real_font_name(text filename, text name) {
  char s[64];
  extract_folder(name, filename); // roman
  extract_file(s, filename); // 16.font
  remove_ext(s); // 16
  text_attach_c(name, '/'); // roman/16
  text_attach(name, s);
  return 1;
}

// get font by name

FONT *get_system_font(text name) {
  uint i, n=system_fonts.n;
  FONT *f;
  char t[256];
  // get name/n from media/font/name/n.font
  if (text_begins(name, "media")) {
    text_copy(t, name);
    real_font_name(t, name);
  }
  if (text_ends(name, "font"))
    remove_ext(name);
  for (i=0; i<n; i++) {
    f=array_index(&system_fonts, i);
    if (text_equal(name, f->name)) {
      system_fonts.i=i;
      return f;
    }
  }
  return 0;
}