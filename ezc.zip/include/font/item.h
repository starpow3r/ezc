// ITEM; advanced ICON with text

object {
  uint id, type;
  text name, t, t2, note;
  BOX box;
  ICON *icon_p;
  // STYLE style;
} ITEM;

int set_item_name(ITEM *item, text name) {
  uint n=text_n(name);
  if (!allocate(text, item->name, n+1))
    return 0;
  text_copy(item->name, name);
  return 1;
}

int attach_item(ARRAY *list, text name) {
  ITEM *p;
  if (!(p=array_expand(list)))
    return 0;
  if (!set_item_name(p, name))
    return 0;
  return 1;
}

void destroy_item(ITEM *item) {
  destroy(item->name);
}