//////////////// DRAW CHARACTER //////////////////

int draw_c_invisible=NO, draw_c_outline=NO,
  draw_c_smooth=YES, text_selection=NO,
  text_reverse_select=NO;
text text_current_p=0, text_origin_p=0,
  text_start_p=0, text_end_p=0;
int text_box_x=0, text_box_y=0;

int is_selection() {
  return (text_current_p>=text_start_p
    and text_current_p<=text_end_p);
}

int draw_c_old(byte c, int x, int y);

extern int mouse_x, mouse_y, mouse_1;

// int draw_c(byte c, int x, int y);
// int draw_text(text t, int x, int y);

// draw raster scanlines. v = visible,
// o = outline, s = shadow, x = special

/*
int draw_raster_vo(void *pixels, int x, int y,
  int w, color vc, color oc);
int draw_raster_vos(void *pixels, int x, int y,
  int w, color vc, color oc, color sc);
int draw_raster_vosx(void *pixels, int x, int y,
  int w, color vc, color oc, color sc, color xc);
*/

byte color_tolerance=16;

int draw_raster_vo(void *pixels, int x, int y,
  int w, color vc, color oc) {
  uint i;
  byte r, g, b, gray;
  if (not visible_line_h(x, y, w))
    return 0;
  color c, d, sc, *p, *s=pixels;
  p=&screen_xy(x, y);
  // bug("W: %d", w);
  for (i=x; i<x+w; i++, p++, s++) {
    c=*s;
    if (c==WHITE)
      continue;
    d=vc;
    if (c==BLACK)
      ; // d=vc;
    else if (c==GREEN)
      d=oc;
    else {
      r=(c>>16)&0xFF, g=(c>>8)&0xFF, b=c&0xFF;
      gray=
        ((r+g+b)/3)&0xFF;
      sc=*(color *) p; // screen color
      if (g>r and g>b) { // green dominant
        if (c>=0x00ff00) // lightest
          d=mix(oc, sc, g); // d=outline_shades[7-(b/32)];
        else
          d=mix(vc, oc, g); // d=outline_shades[0xf0-(g/32)];
      }
      else // grayscale. visible + screen
      d=mix(vc, sc, gray); // ?
    }
    draw_pixel(i, y, d);
  }
  return 1;
}

/*        
        if (g<=0x7F) // dark
          c=mix(oc, *(color *) p, g);
        else
          c=mix(oc, vc, g);
        // pure green/white/background.
        // mix outline color with screen color by g
        if (r==b)
          c=mix(oc, *(color *) p, g);
        // green/black interior.
        // mix outline color with visible color by g
        else
          c=mix(oc, vc, g);
*/

/*
      // if (is_greenish(r, g, b, 1)) {
        // pure green/white/background.
        // mix outline color with screen color by g
        if (r==b)
          c=mix(oc, *(color *) p, g);
        // green/black interior.
        // mix outline color with visible color by g
        else
          c=mix(oc, vc, g);
      // }
*/

// draw char "bold", twice in the same location with
// edges more pronounced

int draw_c_bold(char c, int x, int y) {
  draw_c(c, x, y);
  draw_c(c, x, y);
}

int draw_c_shadow(char c, int x, int y) {
  int i, ay, ah, w=font.image.w, h=font.image.h;
  BOX *bp=&font.boxes[font_symbols[c]];
  color *p=font.image.p+bp->x, *q;
  for (ay=0; is_blank_line(p, WHITE, w); ay++, p+=w);
  q=p;
  for (ah=0; !is_blank_line(p, WHITE, w); p+=w, ah++);
  p=q;
  for (i=0; i<ah; i++, p+=w) {
    if (is_blank_line(p, WHITE, w))
      continue;
    draw_raster_sh(p, x, y+i, bp->w, font.sc);
  }
  return bp->w;
}

int draw_c_solid(char c, int x, int y) {
  int i, ay, ah, w=font.image.w, h=font.image.h;
  BOX *bp=&font.boxes[font_symbols[c]];
  color *p=font.image.p+bp->x, *q;
  for (ay=0; is_blank_line(p, WHITE, w); ay++, p+=w);
  q=p;
  for (ah=0; !is_blank_line(p, WHITE, w); p+=w, ah++);
  p=q;
  for (i=0; i<ah; i++, p+=w) {
    //if (is_blank_line(p, WHITE, w))
    //  continue;
    //if (font.type&FONT_OUTLINE)
    //  draw_raster_vo(p, x, y+i, bp->w, font.c, font.lc);
    //else
      draw_raster_sh(p, x, y+i, bp->w, font.c);
  }
  return bp->w;
}

// draw character with fade effect

int draw_c_fade(char ch, int x, int y) {
  int i, ay, ah, w=font.image.w, h=font.image.h;
  int r1, g1, b1, r2, g2, b2, nr, ng, nb;
  int n;
  BOX *bp=&font.boxes[font_symbols[ch]];
  color *p=font.image.p+bp->x, *q;
  color c, c1=font.fc, c2=font.c, lc=font.lc;
  // if (!(font.type&FONT_OUTLINE))
  //  font.lc=screen_color;
  for (ay=0; is_blank_line(p, WHITE, w); ay++, p+=w);
  q=p;
  for (ah=0; !is_blank_line(p, WHITE, w); p+=w, ah++);
  p=q, n=ah;
  r1=get_r(c1), g1=get_g(c1), b1=get_b(c1);
  r2=get_r(c2), g2=get_g(c2), b2=get_b(c2);
  r1<<=8, g1<<=8, b1<<=8;
  nr=((r2<<8)-r1), ng=((g2<<8)-g1), nb=((b2<<8)-b1);
  if (n)
    nr/=n, ng/=n, nb/=n;
  for (i=0; i<ah; i++, p+=w) {
    if (is_blank_line(p, WHITE, w)) {
      // r1+=nr, g1+=ng, b1+=nb;
      continue;
    }
    c=rgb(r1>>8, g1>>8, b1>>8);
    //draw_raster_vo(p, x, y+i, bp->w,
    //  c, font.lc);
    if (font.type&FONT_OUTLINE)
      draw_raster_vo(p, x, y+i, bp->w, c, font.lc);
    else
      draw_raster_sh(p, x, y+i, bp->w, c);
    r1+=nr, g1+=ng, b1+=nb;
  }
  return bp->w;
}

/*
  for (ay=0; is_blank_line(p, WHITE, w); ay++, p+=w);
  q=p;
  for (ah=0; !is_blank_line(p, WHITE, w); p+=w, ah++);
  p=q;
  for (i=0; i<ah; i++, p+=w) {
    if (is_blank_line(p, WHITE, w))
      continue;
    if (font.type&FONT_OUTLINE)
      draw_raster_vo(p, x, y+i, bp->w, font.c, font.lc);
    else
      draw_raster_sh(p, x, y+i, bp->w, font.c);
*/

int draw_c_fade_new(char ch, int x, int y) {
  int i, n, ay, ah, cw=char_w(ch),
    w=font.image.w, h=font.image.h;
  int r1, g1, b1, r2, g2, b2, nr, ng, nb;
  BOX *bp=&font.boxes[font_symbols[ch]];
  color *p=font.image.p+bp->x, *q, c, c1=font.fc,
    c2=font.c, lc=font.lc;
  for (ay=0; is_blank_line(p, WHITE, w); ay++, p+=w);
  q=p;
  for (ah=0; !is_blank_line(p, WHITE, w); p+=w, ah++);
  p=q, n=ah;
  r1=get_r(c1), g1=get_g(c1), b1=get_b(c1);
  r2=get_r(c2), g2=get_g(c2), b2=get_b(c2);
  r1<<=8, g1<<=8, b1<<=8;
  nr=((r2<<8)-r1), ng=((g2<<8)-g1), nb=((b2<<8)-b1);
  if (n)
    nr/=n, ng/=n, nb/=n;
  for (i=0; i<ah; i++, p+=w) {
    c=rgb(r1>>8, g1>>8, b1>>8);
    //if (font.type&FONT_OUTLINE)
    //  draw_raster_vo(p, x, y+i, bp->w, c, font.lc);
    //else
    //  draw_raster_sh(p, x, y+i, bp->w, c);
    draw_raster2(p, x, y+i, bp->w, c, BLACK, WHITE);
    r1+=nr, g1+=ng, b1+=nb;
  }
  return bp->w;
}

// draw 'c'/haracter gradient, 8-16 colors (font.nc)

int draw_c_gradient(char c, int x, int y) {
  int i, j, n, w=font.image.w, h=font.image.h,
    r1, g1, b1, r2, g2, b2, nr, ng, nb, ay, ah,
    n_colors=font.nc, n_fades=n_colors/2;
  BOX *bp=&font.boxes[font_symbols[c]];
  color a, b, c1, lc=font.lc,
    *pixels=font.image.p+bp->x, *p=pixels;

  // start at top, y=0. scroll down until visible
  // horizontal line, then get size until invisible line
  
  for (ay=0; is_blank_line(p, WHITE, w); ay++, p+=w);
  for (ah=0; !is_blank_line(p, WHITE, w); p+=w, ah++);
  p=pixels+(ay*w);
  n=(ah/n_fades);
  if (!n)
    n=2;

  // draw character horizontal lines in rainbow colors
  
  for (i=0; i<n_colors; i+=2) {
    a=font.colors[i], b=font.colors[i+1];
    r1=get_r(a), g1=get_g(a), b1=get_b(a);
    r2=get_r(b), g2=get_g(b), b2=get_b(b);
    r1<<=8, g1<<=8, b1<<=8;
    // nr=((r2<<8)-r1)/n; ng=((g2<<8)-g1)/n, nb=((b2<<8)-b1)/n;

    nr=((r2<<8)-r1), ng=((g2<<8)-g1), nb=((b2<<8)-b1);
    if (n)
      nr/=n, ng/=n, nb/=n;

    for (j=0, c1=a; j<n+1; j++, p+=w) {
      //if (font.type&FONT_OUTLINE)
        draw_raster_vo(p, x, y++, bp->w, c1, lc);
      //else
      //  draw_raster_sh(p, x, y++, bp->w, font.c);
      c1=rgb(r1>>8, g1>>8, b1>>8);
      r1+=nr, g1+=ng, b1+=nb;
    }
  }
  return bp->w;
}

int draw_raster_sh(void *pixels, int x, int y,
  int w, color sc) {
  uint i;
  byte r, g, b;
  if (not visible_line_h(x, y, w))
    return 0;
  color c, *p, *s=pixels;
  p=&screen_xy(x, y);
  for (i=0; i<w; i++, p++, s++) {
    c=*s;
    if (c==WHITE)
      continue;
    else if (c==GREEN or c==BLACK)
      c=sc;
    else {
      r=c>>16&0xFF, g=c>>8&0xFF, b=c&0xFF;
      if (g>r+4 and g>b+4) // inner outline
        c=sc;
      else // outer outline
        c=mix(sc, *(color *) p, g);
    }
    draw_pixel(i+x, y, c);
  }
  return 1;
}

// draw raster scanline in shades of color.
// pixels are grayscale where: 0/BLACK =
// invisible. 0xFFFFFF/WHITE = 100% visible.
// otherwise, GRAY = intensity (&0xFF).
// for drawing font glyphs, textures, brushes,
// masks, images with variable alpha,
// recolored images (example: sprites with
// different colors for clothes)

int draw_scanline_r2(void *pixels, int x, int y,
  int w, color c) {
  if (not visible_line_h(x, y, w))
    return 0;
  if (clip_text_y and y>=clip_text_y)
    return 0;
  int i, a=c;
  byte *p, *s=(byte *) pixels;
  p=&screen_xy(x, y);
  if (a==WHITE)
    a=0xFEFEFE;
  for (i=x; i<x+w; i++, p+=4, s+=4) {
    if (clip_text_x and i>=clip_text_x)
      return 0;
    c=*(color *) s;
    if (c==WHITE)
      continue;
    if (c==BLACK)
      c=a;
    else {
      int g=grayscale_color(c)&0xFF;
      //g-=32; if (g<0) g=0;
      /*g+=32;
      if (g>255)
        g=255;*/
      c=mix(a, *(color *) p, g);
    }
    // c=mix(a, *(color *) p, (c&0xFF));

    draw_pixel(i, y, c);
  }
  return 1;
}

int draw_raster2(void *pixels, int x, int y,
  int w, color fc, color vc, color tc) {
  int i, a=fc;
  if (not visible_line_h(x, y, w))
    return 0;
  if (clip_text_y and y>=clip_text_y)
    return 0;
  byte *p, *s=(byte *) pixels;
  p=&screen_xy(x, y);
  if (fc==WHITE)
    fc=0xFEFEFE;
  for (i=x; i<x+w; i++, p+=4, s+=4) {
    if (clip_text_x and i>=clip_text_x)
      return 0;
    color c=*(color *) s;
    if (c==tc)
      continue;
    else if (c==vc)
      c=a;
    else {
      int g=grayscale_color(c)&0xFF;
      g-=32; if (g<0) g=0;
      /*g+=32;
      if (g>255)
        g=255;*/
      c=mix(fc, *(color *) p, g);
    }
    draw_pixel(i, y, c);
  }
  return 1;
}

int draw_raster_i2(void *pixels, int x, int y,
  int w, color vc, color oc) {
  int i, g, b;
  if (not visible_line_h(x, y, w))
    return 0;
  color c, *p, *s=pixels;
  p=&screen_xy(x, y);
  for (i=x; i<x+w; i++, p++, s++) {
    c=*s;
    if (c==WHITE)
      continue;
    else if (c==BLACK)
      c=vc;
    else if (c==GREEN)
      c=oc;
    else {
      g=c>>8&0xFF, b=c&0xFF;
      if (g==b)
        c=mix(oc, vc, g);
      else
        c=mix(oc, *(color *) p, g);
    }
    draw_pixel(i, y, c);
  }
  return 1;
}

int draw_c_plain(char c, int x, int y) {
  int i, ay, ah, w=font.image.w, h=font.image.h;
  BOX *bp=&font.boxes[font_symbols[c]];
  color *p=font.image.p+bp->x, *q;
  for (ay=0; is_blank_line(p, WHITE, w); ay++, p+=w);
  q=p;
  for (ah=0; !is_blank_line(p, WHITE, w); p+=w, ah++);
  p=q;
  for (i=0; i<ah; i++, p+=w) {
    if (is_blank_line(p, WHITE, w))
      continue;
    //if (font.type&FONT_OUTLINE)
    //  draw_raster_vo(p, x, y+i, bp->w, font.c, font.lc);
    //else
      // draw_raster_sh(p, x, y+i, bp->w, font.c);
      draw_raster2(p, x, y+i, bp->w,
        font.c, BLACK, WHITE);
  }
  return bp->w;
}

int draw_c(byte c, int x, int y) {
  int i, cw=new_char_w(c), h=font.image.h,
    w=font.image.w;
  color *p=font.image.p, *q, fc=font.c,
    fc2=fc, sc=font.sc, lc=font.lc, co;
  BOX box;
  if (!c or !p or !w)
    return 0;
  set_box(&box, x, y, cw, h);
  if (!visible_box(&box))
    return 0;
  if (c==9) // tab=space
    c=' ';
  if (!is_visible(c)) // skip invisible
    return 0;

  if (font.type&FONT_MONOSPACE) { // center x
    x+=((font.w/2)-(real_char_w(c)/2));
  }

  // draw shadow behind

  if (font.type&FONT_SHADOW) { // or shx or shy) {
    sc=font.sc;
    draw_c_shadow(c, x+font.shx, y+font.shy);
  }

  // draw character via scanlines. h=#

  if (font.type&FONT_RAINBOW) {
    draw_c_gradient(c, x, y);
    return w;
  }
  if (font.type&FONT_FADE) {
    if (font.c!=font.fc) {
      draw_c_fade_new(c, x, y);
      return w;
    }
  }
  
  // does this cause problems!!!???

/*
  c=font_symbols[c],
  w=font.widths[c],
  p+=font.xs[c];
  for (i=0; i<h; i++, p+=font.image.w) {
    if (is_blank_line(p, WHITE, w))
      continue;
    draw_raster2(p, x, y+i, cw,
      fc, BLACK, WHITE);
    // font color, visible, invisible
  }
  return w;
*/

  // else, draw solid

  //if (font.type&FONT_OUTLINE) {
  // draw_c_shadow(c, x, y);
   //return w;
  //}

  int ay, ah;
  c=font_symbols[c], cw=font.widths[c],
  p=font.image.p+font.xs[c];
  for (ay=0; ay<h and is_blank_line(p, WHITE, w);
    ay++, p+=w);
  q=p;
  for (ah=0; ay<h and not is_blank_line(q, WHITE, w);
    q+=w, ay++, ah++);
  if (ay==h)
    ay--, ah--;
  for (i=0; i<ah; i++, p+=w)
    draw_raster2(p, x, y+i, cw,
      font.c, BLACK, WHITE);
  return w;
}

int draw_text(text t, int x, int y) {
  char c;
  int start_x=x;
  text p=t;
  if (!t or !*t or !font.image.p
    or x>=screen_w or y>=screen_h)
    return 0;
  if (clip_text_y and y>=clip_text_y)
    return 0;
  text_current_p=p;
  for (x=0; c=*p; text_current_p=p++) {
    if (y>=screen_h)
      break;
    if (c==0xD) {
      x=0, y+=font.h+font.iy, p++;
      continue;
    }
    if (font.type&FONT_MONOSPACE) {
      draw_c(c, start_x+x, y);
      x+=font.w;
    }
    else {
      draw_c(c, start_x+x, y);
      x+=new_char_w(c);
    }
  }
  return 1;
}

void draw_number(int n, int x, int y) {
  char t[16];
  i2t(n, t);
  draw_text(t, x, y);
}

// draw text centered in box ending
// with '...' if greater width. untested...

void draw_text_box_v(text t, BOX *b) {
  int i, w, tw, ww;
  BOX box;
  char s[256];
  text_copy(s, t);
  box.w=text_w(t);
  box.h=text_h(t);
  ww=font.widths[font_table['W']];
  if (box.w+(ww*2)>=b->w) {
    // how many symbols
    // can fit? total w
    tw=text_w("..");
    for (i=0; t[i]; i++) {
      w=font.widths[i];
      // +font.ix;
      tw+=w;
      if (tw+(w*2)>b->w-4) // can't fit
        break;
      s[i]=t[i];
    }
    s[i]=0;
    text_attach(s, "..");
    box.w=text_w(s);
  }
  draw_box(b, BLACK, WHITE);
  align_box(&box, b, CENTER);
  box.y+=2;
  draw_text(s, box.x, box.y);
}

void draw_text_b(text t, BOX *b) {
  draw_text(t, b->x, b->y);
}

// draw text with alignment

void draw_text_a(text t, BOX *b, int align) {
  BOX box;
  make_text_box(t, &box);
  align_box(&box, b, align);
  draw_text(t, box.x+inset_x, box.y+inset_y);
}

void draw_text_in(text t, BOX *b, int align,
  int nx, int ny) {
  BOX box;
  make_text_box(t, &box);
  align_in(&box, b, align, nx, ny);
  draw_text(t, box.x+inset_x, box.y+inset_y);
}

void draw_text_box_in(text t, BOX *a, BOX *b,
  int align, int nx, int ny) {
  make_text_box(t, a);
  align_in(a, b, align, nx, ny);
  draw_text(t, a->x+inset_x, a->y+inset_y);
}

void draw_text_g(text t, int orient, int style,
  BOX *b1, BOX *b2, int align, int nx, int ny,
  color a, color b) {
  make_text_box(t, b1);
  align_in(b1, b2, align, nx, ny);
  draw_gradient(orient, style, b1->x,
    b1->y, b1->w, b1->h, a, b);
  draw_text(t, b1->x+inset_x,
    b1->y+inset_y);
}

// draw text centered inside box with all
// lines centered horizontally and vertically.
// line can't exceed 1kb

void draw_text_center(text t, BOX *b) {
  int i, w, ty, th;
  text p=t;
  char s[1024];
  th=text_h(t), ty=(b->h/2)-(th/2);
  s[0]=0;
  for (i=0; *p; i++) {
    p=text_get_line_w(s, p, b->w);
    w=text_w(s);
    if (!w)
      continue;
    draw_text(s, b->x+(b->w/2)-(w/2),
      ty+(b->y+(i*font.h)));
  }
}