// save error text in file

text log_file="log.txt";
int log_exists=0, log_star=1, log_nl=1;

void log_t(text t) {
  char l[512];
  text p=l;
  if (log_star)
    p=text_copy(p, "* ");
  text_copy_n(p, t, 510);
  if (log_nl)
    text_attach(p, "\n");
  if (!log_exists) {
    create_file(log_file);
    log_exists=1;
    close_file();
  }
  append_file(log_file, p, text_n(p));
}

// edit: use new print(...)

void log(text t, ...) {
  int n;
  char s[1024];
  text p=s;
  if (!t or !*t)
    return;
  va_list va;
  va_start(va, t);
  while (*t) {
    if (p-s>=1023) {
      *p=0;
      break;
    }
    if (*t!='%') {
      *p++=*t++;
      continue;
    }
    t++;
    if (*t=='%')
      *p++='%';
    else if (*t=='s' or *t=='t')
      p=text_copy(p, va_arg(va, text));
    else {
      n=va_arg(va, int);
      if (!n)
        *p++='0';
      else {
        if (*t=='c')
          *p++=n;
        else if (*t=='u')
          p=u2t(n, p);
        else if (*t=='i' or *t=='d')
          p=i2t(n, p);
        else if (*t=='x' or
          *t=='X' or *t=='h')
          p=h2t(n, p);
        else if (*t=='b')
          p=b2t(n, p);
        else
          *p++='?';
      }
    }
    t++;
  }
  *p=0;
  log_t(s);
  va_end(va);
}

void show_log() {
  system(log_file);
  // execute_file(log_file);
}

// log array of text

void log_a(ARRAY *array) {
  for (int i=0; i<array->n; i++)
    log_t((text) array_index(array, i));
}