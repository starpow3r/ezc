/* EZC LIBRARY. BY STARPOWER/MYSTERI/OUS.
    __  ___         __          _
  /  |/  /_ _____ / /____ ____(_)
 / /|_/ / // (_-<  __/ -_) __/ /
/_/  /_/\_, /___/\__/\__/_/ /_/
       /___/ (C) 2016+, KID-7/77 */

////////////////////// FILE //////////////////////

// current file and size

FILE *file_p=0;
uint file_size=0;

// functions: open, create, close, exists, etc

int open_file(text name);
int create_file(text name);
void close_file();
int file_exists(text name);
uint tell_file();
int seek_file(uint n);
int seek_file_r(uint n, int r);
int is_eof();

int read_file(void *p, uint n);
int write_file(void *p, uint n);

#define read_byte read_1
#define write_byte write_1
#define read_word read_2
#define write_word write_2

int read_1(), write_1(int i);
int read_2(), write_2(int i);
int read_4(), write_4(int i);

int write_text(text t), write_string(text t);
int write_line(text t), write_nl();
int write_zeros(uint n);

void *load_file(text name);
uint save_file(text name, void *p, uint size);
uint append_file(text name, void *p, uint size);

text load_text(text name);
int save_text(text name, text t);
int append_text(text name, text t);

int get_directory(text t);
int set_directory(text t);
int create_directory(text t);

int copy_file(text a, text b);
int move_file(text a, text b);
int delete_file(text a);
int execute_file(text name);

text find_first(text name);
text find_next();
void find_end();

extern int os_get_directory(text t);
extern int os_set_directory(text t);
extern int os_create_directory(text t);

extern int os_copy_file(text a, text b);
extern int os_move_file(text a, text b);
extern int os_delete_file(text a);
extern int os_execute_file(text name);

extern text os_find_first(text name);
extern text os_find_next();
extern void os_find_end();

void extract_directory(text a, text b);
void extract_drive(text a, text b);
void extract_file(text a, text b);
void extract_name(text a, text b);
void extract_ext(text a, text b);
void change_ext(text a, text b);
void remove_ext(text a);
void deslash(text name);
void reslash(text name);

//////////////////////////////////////////////////

// open for read/write/etc

int open_file_x(text name, text mode) {
  file_size=0;
  if (!(file_p=fopen(name, mode)))
    return 0;
  if (*mode=='r') {
    seek_file_r(0, SEEK_END);
    file_size=tell_file();
    seek_file_r(0, SEEK_SET);
  }
  return 1;
}

// open for read. fail if non-existent

int open_file(text name) {
  return open_file_x(name, "rb");
}

// create for write. overwrite if exists

int create_file(text name) {
  return open_file_x(name, "wb");
}

// close current file

void close_file() {
  fclose(file_p);
}

// does file exist?

int file_exists(text name) {
  if (!open_file(name))
    return 0;
  close_file();
  return 1;
}

// get current location

uint tell_file() {
  return ftell(file_p);
}

// seek. set file location. r=relative

int seek_file(uint n) {
  if (!fseek(file_p, n, SEEK_SET))
    return 1;
  return 0;
}

int seek_file_r(uint n, int r) {
  if (!fseek(file_p, n, r))
    return 1;
  return 0;
}

// is end of file?

int is_eof() {
  return feof(file_p);
}

uint get_file_size(text name) {
  uint size;
  if (!open_file(name))
    return 0;
  size=file_size;
  close_file();
  return size;
}

// read/write to/from current file.
// memory/p or 1/2/4 bytes

int read_file(void *p, uint n) {
  return fread(p, 1, n, file_p)==n;
}

int write_file(void *p, uint n) {
  return fwrite(p, 1, n, file_p)==n;
}

int read_1() {
  return fgetc(file_p);  
}

int write_1(int c) {
  return fputc(c, file_p);
}

int read_2() {
  int i;
  read_file(&i, 2);
  return i;
}

int write_2(int i) {
  return write_file(&i, 2);
}

int read_4() {
  int i;
  read_file(&i, 4);
  return i;
}

int write_4(int i) {
  return write_file(&i, 4);
}

int write_0(uint n) {
  for (uint i=0; i<n; i++)
    if (!write_1(0))
      return 0;
  return 1;
}

int write_text(text t) {
  return write_file(t, text_n(t));
}

int write_string(text t) {
  if (!write_text(t))
    return 0;
  return write_1(0);
}

int write_line(text t) {
  if (!write_text(t))
    return 0;
  return write_nl();
}

int write_nl() {
  return write_1(0xD) and write_1(0xA);
}

int write_zeros(uint n) {
  for (uint i=0; i<n; i++)
    write_1(0);
  return 1;
}

// auto .extension for load/save

text default_ext=0;

void set_default_ext(text ext) { default_ext=ext; }

void get_filename(text filename, text name) {
  text_copy(filename, name);
  if (default_ext and not text_ends(filename, default_ext))
    text_attach(filename, default_ext);
}

// load/save entire file

void *load_file(text name) {
  void *p=0;
  char filename[256];
  get_filename(filename, name);
  if (open_file(filename)) {
    if (allocate(void *, p, file_size))
      if (!read_file(p, file_size))
        destroy(p); // p=0
    close_file();
  }
  return p;
}

uint save_file(text name, void *p, uint size) {
  uint r;
  char filename[256];
  get_filename(filename, name);
  if (!create_file(filename))
    return 0;
  r=write_file(p, size);
  close_file();
  return r;
}

uint append_file(text name, void *p, uint size) {
  uint r;
  if (!open_file_x(name, "a"))
    return 0;
  r=write_file(p, size);
  close_file();
  return r;
}

text load_text(text name) {
  text p=0;
  if (open_file(name)) {
    if (allocate(text, p, file_size+32)) {
      if (read_file(p, file_size))
        p[file_size]=0;
      else
        destroy(p); // p=0
    } // else p=0
    close_file();
  }
  return p;
}

int save_text(text name, text t) {
  return save_file(name, t, text_n(t));
}

int append_text(text name, text t) {
  return append_file(name, t, text_n(t));
}

// load or save array as name. it must've
// been created first with element size,
// then this allocates size # of elements

int load_array(ARRAY *array, text name, uint n) {
  uint i;
  void *p;
  if (!open_file(name))
    return 0;
  if (!array_size(array, n))
    return 0;
  for (i=0; i<n; i++) {
    p=array_index(array, i);
    read_file(p, array->size);
  }
  close_file();
  return 1;
}

int save_array(ARRAY *array, text name) {
  uint i, n;
  void *p;
  if (!create_file(name))
    return 0;
  for (i=0; i<n; i++) {
    p=array_index(array, i);
    write_file(p, array->size);
  }
  close_file();
  return 1;
}

/////////////////// DIRECTORY ////////////////////

int create_directory(text name) {
  return os_create_directory(name);
}

int set_directory(text name) {
  return os_set_directory(name);
}

int get_directory(text name) {
  return os_get_directory(name);
}

/////////////// FILE OPERATIONS //////////////////

int copy_file(text name, text to) {
  return os_copy_file(name, to);
}

int move_file(text name, text to) {
  return os_move_file(name, to);
}

int delete_file(text name) {
  return os_delete_file(name);
}

//////////////////// EXECUTE /////////////////////

int execute_file(text name) {
  return os_execute(name);
}

////////////////// FIND FILES ////////////////////

text find_first(text name) {
  return os_find_first(name);
}

text find_next() {
  return os_find_next();
}

void find_end() {
  os_find_end();
}

// create dynamic text array containing all
// filenames of "*.ext" in current directory
// or return 0 if there are none. use "*.*"
// for all files/folders

int find_files(ARRAY *array, text ext) {
  int i;
  text p;
  array_create(array, 256);
  for (i=0;; i++) {
    if (!i)
      p=find_first(ext);
    else
      p=find_next();
    if (!p)
      break;
    if (!array_attach(array, p))
      break;
  }
  return i;
}

////////////////// FILENAMES /////////////////////

// parse filename:

/*                  - b='C:/MY/FILE.EXT'
* extract_drive     - a='C'
* extract_directory - a='C:/MY'
* extract_folder    - a='MY'
* extract_file      - a='FILE.EXT'
* extract_name      - a='FILE'
* extract_ext       - a='.EXT'
* change_ext        - replace .EXT
* remove_ext        - remove .EXT
*/

void extract_drive(text a, text b) {
  text p=a;
  for (; *b and *b!=':'; *p++=*b++);
  *p=0;
  if (!*b) {
    *a=0;
    return;
  }
}

void extract_directory(text a, text b) {
  text p;
  text_copy(a, b);
  if ((p=text_find_r(a, '/'))
    or (p=text_find_r(a, '\\')))
    a=p;
  *a=0;
  if (p)
    text_attach_c(a, '/');
}

void extract_folder(text a, text b) {
  text p;
  text_copy(a, b);
  if ((p=text_find_r(a, '/'))
    or (p=text_find_r(a, '\\'))) {
    for (*p=0; p>a and *p!='/'
      and *p!='\\'; p--);
    if (p<=a) {
      *p=0;
      return;
    }
    for (p++; *p; *a++=*p++);
  }
  *a=0;
}

void extract_file(text a, text b) {
  text p;
  text_copy(a, b);
  if ((p=text_find_r(a, '/'))
    or (p=text_find_r(a, '\\')))
    text_copy(a, p+1);
}

void extract_name(text a, text b) {
  extract_file(a, b);
  remove_ext(a);
}

void extract_ext(text a, text b) {
  text p;
  *a=0;
  if ((p=text_find_r(b, '.')))
    text_copy(a, p+1);
}

void remove_ext(text a) {
  text p;
  if (!text_find(a, '.'))
    return;
  p=text_end(a);
  for (; p>a and *p!='.'; p--)
    if (*p=='/' or *p=='\\')
      return;
  if (p==a)
    return;
  *p=0;
}

void change_ext(text a, text b) {
  if (*a)
    remove_ext(a);
  if (*b!='.')
    text_attach_c(a, '.');
  text_attach(a, b);
}

// remove unnecessary slashes, and
// replace "\//" with forward slashes

// before: c://my\\code///\\\\include\\
// after: c:/my/code/include/

void deslash(text name) {
  text a=name, b=name;
  while (*b) {
    if (*b=='/' or *b=='\\') {
      *a++='/';
      while (*b=='/' or *b=='\\')
        b++;
    }
    else
      *a++=*b++;
  }
  *a=0;
}

// same, but replace with backslashes

// before: c://my\\code///\\\\include\\
// after: c:\my\code\include\

void reslash(text name) {
  text a=name, b=name;
  while (*b) {
    if (*b=='/' or *b=='\\') {
      *a++='\\';
      while (*b=='/' or *b=='\\')
        b++;
    }
    else
      *a++=*b++;
  }
  *a=0;
}

// move up

void file_up(text name) {
  text a=name, b=name;
  if (not text_search(a, ".."))
    return;
  while (*b) {
    if ((b[0]=='/' or b[0]=='\\')
      and b[1]=='.' and b[2]=='.') {
      for (a--; a>name and
        *a!='/' and *a!='\\'; a--);
      b+=3;
    }
    else
      *a++=*b++;
  }
  *a=0;
}

// generic load/save text templates in plain C

text load_text_c(text name) {
  text p;
  FILE *file_h;
  if (!(file_h=fopen(name, "rb")))
    return 0;
  fseek(file_h, 0, SEEK_END);
  file_size=ftell(file_h);
  fseek(file_h, 0, SEEK_SET);
  if ((p=(text) malloc(file_size+32))) {
    if (fread(p, 1, file_size, file_h)==file_size)
      p[file_size]=0;
    else
      p=0;
  }
  fclose(file_h);
  return p;
}

int save_text_c(text name, text p) {
  FILE *file_h;
  if (!(file_h=fopen(name, "wb")))
    return 0;
  uint n=text_n(p), r=0;
  if (fwrite(p, 1, n, file_h)==n)
    r=1;
  fclose(file_h);
  return r;
}

// VERSATILE VARIABLE BIT STREAM IN MEMORY
// OR FILE WITH ERROR CHECKING

#ifdef USE_STREAM

byte *stream=0, *stream_p=0;
uint stream_size=0, stream_baud_rate=0;

uint stream_type=0, stream_error=0,
  stream_attributes=0, stream_state=0;

uint stream_bit=0, stream_byte=0,
  stream_couple=0, stream_nibble=0;

enum { STREAM_NONE, STREAM_MEMORY, STREAM_SYSTEM,
  STREAM_FILE, STREAM_DEVICE, STREAM_NETWORK };

enum { STREAM_SHARED=1,
  STREAM_READABLE=2, STREAM_WRITEABLE=4,
  STREAM_EXECUTABLE=8, STREAM_SHARED=16 };

enum { STREAM_READING=1, STREAM_WRITING=2,
  STREAM_READY=4, STREAM_BUSY=8 };

enum { STREAM_ERROR_MEMORY=1, STREAM_ERROR_READ,
  STREAM_ERROR_WRITE };

enum { SERIAL_I2C=1, SERIAL_SPI, PARALLEL_UXP };

#define stream_offset (stream_p-stream)

// create stream for write. allocates size
// in bytes aligned to 16 for padding

int create_stream(uint size) {
  uint n=align_n(size, 16);
  if (!allocate(void *, stream, n)) {
    stream_error=STREAM_ERROR_MEMORY;
    return 0;
  }
  stream_p=stream, stream_size=size,
  stream_bit=0, stream_byte=0,
  stream_couple=0, stream_nibble=0,
  stream_type=STREAM_MEMORY,
  stream_error=STREAM_NONE,
  stream_attributes=STREAM_WRITEABLE,
  stream_state=STREAM_READY;
  return 1;
}

void destroy_stream() {
  destroy(stream);
  stream_p=0, stream_type=0, stream_error=0,
  stream_attributes=0, stream_state=0;
}

// set current location to read/write

int seek_stream(uint i) {
  if (stream_size and i>=stream_size)
    return 0;
  stream_p=stream+i;
  return 1;
}

// set existing stream for read or write.
// read starts by reading the first byte.
// stream_size is not set by set_stream_write

void set_stream_read(byte *p, uint size) {
  stream=p, stream_p=p, stream_size=size,
  stream_byte=*stream_p++, stream_bit=0,
  stream_couple=0, stream_nibble=0,
  stream_type=STREAM_MEMORY,
  stream_error=STREAM_NONE,
  stream_attributes=STREAM_READABLE,
  stream_state=STREAM_READY;
}

void set_stream_write(byte *p) {
  stream=p, stream_p=p, stream_size=0,
  stream_byte=0, stream_bit=0,
  stream_couple=0, stream_nibble=0,
  stream_type=STREAM_MEMORY,
  stream_error=STREAM_NONE,
  stream_attributes=STREAM_WRITEABLE,
  stream_state=STREAM_READY;
}

// is stream readable or writeable?
// (note: read uses > and write uses >=
// because it read the first byte.
// intentional. not typo)

int is_stream_readable() {
  if (stream_error or not
    (stream_attributes&STREAM_READABLE)
    or stream_offset>stream_size) {
    if (!stream_error)
      stream_error=STREAM_ERROR_READ;
    return 0;
  }
  return 1;
}

int is_stream_writeable() {
  if (stream_error or not
    (stream_attributes&STREAM_WRITEABLE)
    or (stream_size and
    stream_offset>=stream_size)) {
    if (!stream_error)
      stream_error=STREAM_ERROR_WRITE;
    return 0;
  }
  return 1;
}

// read/write individual bit from/to memory/file,
// from leftmost bit (#7) to rightmost bit (#0).
// reads or writes a byte every 8 BITs. if error,
// stream_error = 1+

uint read_bit() {
  uint b;
  if (not is_stream_readable())
    return 0;
  stream_state=STREAM_READING;
  b=(stream_byte>>(7-stream_bit++))&1;
  if (stream_bit>7) {
    stream_bit=0;
    if (stream_type==STREAM_MEMORY)
      stream_byte=*stream_p++;
    else if (stream_type==STREAM_FILE)
      stream_byte=read_byte();
  }
  return b;
}

uint write_bit(uint n) {
  uint b;
  if (not is_stream_writeable())
    return 0;
  stream_state=STREAM_WRITING;
  b=(1<<(7-stream_bit++));
  if (n)
    stream_byte|=b;
  else
    stream_byte&=~b;
  if (stream_bit>7) {
    stream_bit=0;
    if (stream_type==STREAM_MEMORY)
      *stream_p++=stream_byte;
    else if (stream_type==STREAM_FILE)
      write_byte(stream_byte);
  }
  return 1;
}

// read or write multiple bits. for this,
// size is specified in bits, not bytes

uint read_bits(byte *p, uint n) {
  uint i, b;
  for (i=0; i<n; i++) {
    // ... unfinished
  }
  return 1;
}

uint write_bits(byte *p, uint n) {
  uint i, a, b;
  if (not is_stream_writeable())
    return 0;
  stream_bit=0, stream_byte=0;
  byte source_byte=*p++,
    source_bit=0;
  for (i=0; i<n; i++) {
    a=source_byte&(1<<(7-source_bit++));
    b=(1<<(7-stream_bit++));
    if (a)
      stream_byte|=b;
    else
      stream_byte&=~b;
    if (stream_bit>7) {
      stream_bit=0, source_bit=0;
      if (stream_type==STREAM_MEMORY)
        *stream_p++=source_byte;
      else if (stream_type==STREAM_FILE)
        write_byte(source_byte);
      source_byte=*p++;
    }
    if (not is_stream_writeable())
      return 0;
  }
  return 1;
}

// write the last odd byte at end of stream/file
// if size is not divisible by 8. example:
// if write_bit is used 16 times, it will write
// 2 bytes. but if it's used 17 times, it must
// write 3 bytes, another one for alignment.
// write_bit sets the current stream_byte, and
// only writes it after processing the last
// rightmost bit (#0)

void write_last_byte() {
  if (stream_bit) {
    if (stream_type==STREAM_MEMORY)
      *stream_p++=stream_byte;
    else if (stream_type==STREAM_FILE)
      write_byte(stream_byte);
  }
}

// unfinished, untested...

// write number, size in bits, 1-32

uint write_nx(uint n, uint size) {
  uint i;
  for (i=size-1; i>=0; i--) {
    write_bit((n>>i)&1);
    if (stream_error)
      break;
  }
  return not stream_error;
}

uint write_couple(byte b) { write_nx(b, 2); }
uint write_triple(byte b) { write_nx(b, 3); }
uint write_nibble(byte b) { write_nx(b, 4); }
uint write_five(byte b)   { write_nx(b, 5); }
uint write_six(byte b)    { write_nx(b, 6); }
uint write_seven(byte b)  { write_nx(b, 7); }

uint write_eight(byte b)  {
  // ...
  return not stream_error;
}

/*
2-DO: upgrade this to a versatile stream that
supports any numbers, 1-64 BIT, and text.

1 BIT = ABCDEFHI - bit
2 BIT = AA.BB.CC.DD - couple
4 BIT = AAAA.BBBB - nibble

numbers may be stored in files with odd sizes
of 3/5/7/9/11/13+ BIT, then interpreted as
variable binary (for compression schemes),
but they must be aligned in memory by
1/2/4/8/16/24/32/64.
*/

#endif