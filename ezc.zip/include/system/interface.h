/* EZC LIBRARY. BY STARPOWER/MYSTERI/OUS.
    __  ___         __          _
  /  |/  /_ _____ / /____ ____(_)
 / /|_/ / // (_-<  __/ -_) __/ /
/_/  /_/\_, /___/\__/\__/_/ /_/
       /___/ (C) 2016+, KID-7/77 */

// interface, title, icons, events. for multiple
// document interface (MDI), see document.h

/////////////////////// FONT /////////////////////

ICON main_icon, code_icon;
FONT main_font, small_font;

void set_main_font() { set_font(&main_font); }

////////////////////// TITLE /////////////////////

text title_text_p=0;
int title_text_x=8, title_text_y=-4;
BOX title_box, title_close_box, title_minimize_box;

color title_color=0x202020, title_shade_color=BLACK,
  title_font_color=WHITE, title_close_color=0x440077,
  title_minimize_color=0x001188;

enum { TS_SHADE=1, TS_CHROME };

int _title_style=TS_CHROME;

#define set_title_text(p...) \
  print(t, p), set_title(t)

int set_title(text t) {
  if (!title_text_p)
    if (!allocate(text, title_text_p, 256))
      return 0;
  text_copy(title_text_p, t);
  show_title_bar=1;
  draw_title_before=0;
  return 1;
}
  
void draw_title_bar() {
  BOX box;
  if (!title_text_p)
    return;
  set_box(&box, 0, 0, screen_w-2, 32);
  title_box=box;
  if (title_shade_color==WHITE)
    draw_shade(&box, 0xEEF3FF, WHITE, 0x777777);
  else
    draw_vista(box.x, box.y, box.w, box.h, title_shade_color);
}

void draw_title_boxes() {
  BOX box;
  if (!title_text_p)
    return;
  set_box(&box, screen_w-64-4, 2, 64, 28);
  copy_box(&title_close_box, &box);
  draw_vista(box.x, box.y, box.w, box.h, title_close_color);
  draw_c('X', box.x+32-5, title_text_y+9);
  box.x=screen_w-(box.w*2)-2;
  copy_box(&title_minimize_box, &box);
  if (_title_style==TS_SHADE)
    draw_shade_d(&box, 'v', title_shade_color, title_minimize_color);
  else if (_title_style==TS_CHROME)
    draw_vista(box.x, box.y, box.w, box.h, title_minimize_color);
  draw_c('-', box.x+(box.w/2)-5, title_text_y+9);
}

BOX address_title_box;
text address_title_text;

void (*draw_title_address_p)()=0;

void draw_title() {
  if (!title_text_p)
    return;
  if (!main_font.image.p)
    return;
  set_font_c(&main_font, WHITE);
  draw_title_bar();
  draw_title_boxes();
  BOX box={ 3, 2, 28, 28 };
  draw_box(&box, BLACK, 0x7000A0);
  draw_icon_at(&main_icon, 5, 4);
  font.c=WHITE;
  draw_text(title_text_p,
    title_text_x+32, title_text_y+9);
  if (draw_title_address_p)
    draw_title_address_p();
}

int title_moveable=0;

int input_title() {
  if (!title_text_p)
    return 0;
  if (mouse_1) {
    if (select_box(&title_box)) {
      if (select_box(&title_close_box))
        exit();
      else if (select_box(&title_minimize_box))
        os_minimize();
    }
    return 1;
  }
  return 0;
}

//////////////// CUSTOM CONTROLS /////////////////

#ifdef USE_CONTROL

  #include "control/event.h"
  #include "control/icons.h"
  #include "control/control.h"
  #include "control/button.h"
  #include "control/scrollbar.h"
  #include "control/toolbar.h"
  #include "control/listbox.h"
  #include "control/menu.h"
  #include "control/edit.h"

//////////////// COMMON DIALOGS //////////////////

// optional predefined common dialogs; select color dialog,
// select font, select_image, select file, etc

#include "control/dialog.h"

///////////// CUSTOM MESSAGE BOXES ///////////////

// message box dialogs with questions and error messages
// create controls: (CONTROL_TYPE, C_ID, "Text", x, y,
// w, h). use generic C_LABEL=0 for all

FRAME dialog_message, dialog_question,
  dialog_error, dialog_load_error,
  dialog_ask_save, dialog_ask_replace,
  dialog_input_text, dialog_input_user;

ICON dialog_icon_question, dialog_icon_error;

enum { DIALOG_MESSAGE_BOX=999999, DIALOG_QUESTION,
  DIALOG_ERROR, DIALOG_LOAD_ERROR, DIALOG_ASK_SAVE,
  DIALOG_ASK_REPLACE, DIALOG_INPUT_TEXT, DIALOG_INPUT_USER };

enum { C_BUTTON_OK=1, C_BUTTON_YES, C_BUTTON_NO,
  C_BUTTON_CANCEL };

int create_custom_dialogs() {
  FRAME *frame;
  ICON *icon;
  int x, y, w, h, fx=8, fy=40, fw=350, fh=170;
  set_icon_folder("media/icon/64");
  if (!load_icon(&dialog_icon_question, "help"))
    return 0;
  if (!load_icon(&dialog_icon_error, "image"))
    return 0;

  frame=&dialog_message;
  create_frame(frame, DIALOG_MESSAGE_BOX,
    "Message Box", fw, fh);
  frame->x=fx, frame->y=fy;
  x=40, y=48, w=100, h=32;
  create_control(CONTROL_LABEL, C_LABEL,
    "  Click Run to Save, \r\n" \
    "Compile, Build, Execute.", x, y, w, h);
  create_control(CONTROL_BUTTON, C_BUTTON_OK,
    "Ok", 124, frame->h-42, 100, h);

  frame=&dialog_load_error;
  create_frame(frame, DIALOG_LOAD_ERROR,
    "Error", fw, fh);
  fy+=fh+8, frame->x=fx, frame->y=fy;
  x=16, y=50;
  create_control(CONTROL_ICON, C_ICON,
    &dialog_icon_error, x, y, 64, 64);
  x+=80, y=47, w=100, h=32;
  create_control(CONTROL_LABEL, C_LABEL,
    "Error loading:", x, y, w, h);
  y+=32;
  create_control(CONTROL_LABEL, C_LABEL,
    "  image.bmp", x, y, w, h);
  create_control(CONTROL_BUTTON, C_BUTTON_OK,
    "Ok", 124, frame->h-42, 100, h);

  frame=&dialog_ask_save;
  create_frame(frame, DIALOG_ASK_SAVE,
    "Save?", fw, fh);
  fx+=fw+8, fy=40, frame->x=fx, frame->y=fy;
  x=16, y=50;
  create_control(CONTROL_ICON, C_ICON,
    &dialog_icon_question, x, y, 64, 64);
  x+=80, y=47, w=100, h=32;
  create_control(CONTROL_LABEL, C_LABEL,
    "Save this file?", x, y, w, h);
  y+=32;
  create_control(CONTROL_LABEL, C_LABEL,
    "   text.h", x, y, w, h);
  y+=32;
  create_control(CONTROL_BUTTON, C_BUTTON_YES,
    "Yes", 74, frame->h-42, 100, h);
  create_control(CONTROL_BUTTON, C_BUTTON_NO,
    "No", 178, frame->h-42, 100, h);

  frame=&dialog_ask_replace;
  create_frame(frame, DIALOG_ASK_REPLACE,
    "Replace?", fw, fh);
  fy+=fh+8, frame->x=fx, frame->y=fy;
  x=16, y=50;
  create_control(CONTROL_ICON, C_ICON,
    &dialog_icon_question, x, y, 64, 64);
  x+=80, y=47, w=100, h=32;
  create_control(CONTROL_LABEL, C_LABEL,
    "File exists. Replace?", x, y, w, h);
  y+=32;
  create_control(CONTROL_LABEL, C_LABEL,
    "   text.h", x, y, w, h);
  y+=32;
  create_control(CONTROL_BUTTON, C_BUTTON_YES,
    "Yes", 74, frame->h-42, 100, h);
  create_control(CONTROL_BUTTON, C_BUTTON_NO,
    "No", 178, frame->h-42, 100, h);
  return 1;
}

#endif

/* load_system_x functions. prevents reloading

ARRAY system_images, system_fonts, system_icons,
  system_cursors, system_sounds;

IMAGE *load_system_image(text name);
FONT *load_system_font(text name);
ICON *load_system_icon(text name);
CURSOR *load_system_cursor(text name);
SOUND *load_system_sound(text name);

IMAGE *load_system_image(text name) {
  uint i, n=system_images.n;
  IMAGE *p;
  if (!n)
    if (!array_create(&system_images, sizeof(IMAGE)))
      return 0;
  for (i=0; i<n; i++) {
    p=array_index(&system_images, i);
    if (text_equal(p->name, name))
      return p;
  }
  if (!(p=array_expand(&system_images)))
    return 0;
  if (!load_image(p, name))
    return 0;
  return p;
}

*/