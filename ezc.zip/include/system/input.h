// INPUT

byte keyboard_connected, mouse_connected, gamepad_connected;

byte keyboard_keys[128], key_event, key_code, key_flags,
  key_shift, key_control, key_menu, key_function;
uint key_event_time, key_update_speed;

byte mouse_event, mouse_1, mouse_2, mouse_3, mouse_click;
int mouse_x, mouse_y, mouse_down_x, mouse_down_y,
  mouse_wheel, mouse_drag, mouse_drag_x, mouse_drag_y,
  mouse_drop, mouse_drop_x, mouse_drop_y;
uint mouse_event_time, mouse_update_speed, mouse_click_speed;

byte gamepad_event, gamepad_move,
  gamepad_up, gamepad_right, gamepad_down, gamepad_left,
  gamepad_b1, gamepad_b2, gamepad_b3, gamepad_b4,
  gamepad_b5, gamepad_b6, gamepad_b7, gamepad_b8,
  gamepad_start, gamepad_select, gamepad_home, gamepad_back,
  gamepad_left_press, gamepad_left_press;
char gamepad_left_x, gamepad_left_y, // -100 to 100
  gamepad_right_x, gamepad_right_y;
uint gamepad_event_time, gamepad_update_speed;

byte remote_event, remote_power, remote_move, remote_up,
  remote_right, remote_down, remote_left,
  remote_volume_up, remote_volume_down, remote_channel_up,
  remote_channel_down, remote_input, remote_source, remote_home,
  remote_ok, remote_menu, remote_back, remote_play, remote_pause,
  remote_stop, remote_previous, remote_next, remote_reverse,
  remote_forward;
uint remote_event_time, remote_update_speed;