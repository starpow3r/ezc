#ifdef SYSTEM_WINDOWS
  #include "system/windows.h"
#endif

#ifdef SYSTEM_DOS
  #include "system/dos.h"
#endif

#ifdef SYSTEM_LINUX
  #include "system/linux.h"
#endif

#ifdef SYSTEM_ANDROID
  #include "system/android.h"
#endif

#ifdef SYSTEM_ARDUINO
  #include "system/arduino.h"
#endif

#ifdef SYSTEM_RASPBERRY
  #include "system/rpi.h"
#endif

#ifdef SYSTEM_PICO
  #include "system/pico.h"
#endif

#ifdef SYSTEM_STM8
  #include "system/stm8.h"
#endif

#ifdef SYSTEM_STM32
  #include "system/stm32.h"
#endif

#ifdef SYSTEM_ESP32
  #include "system/esp32.h"
#endif