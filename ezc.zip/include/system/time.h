/* EZC LIBRARY. BY STARPOWER/MYSTERI/OUS.
    __  ___         __          _
  /  |/  /_ _____ / /____ ____(_)
 / /|_/ / // (_-<  __/ -_) __/ /
/_/  /_/\_, /___/\__/\__/_/ /_/
       /___/ (C) 2016+, KID-7/77 */

uint startup_time=0;

object {
  uint zone,
    month, day, year, weekday,
    hour, minute, second, xm;
} TIME;

/* time or date in 32BIT:

time32: 1, z3, hour5, minute6, ms10, pm1, zone6
0.000.HHHHHMMMMMMSSSSSSSSSSPZZZZZZ = time
date32: 0, z7, weekday3, month4, day5, year12
1.0000000.WWWMMMMDDDDDYYYYYYYYYYYY = date
*/

typedef unsigned int time32, date32;

// byte a __attribute__((packed)); // byte a;

enum { SECOND=1000, MINUTE=SECOND*60, HOUR=MINUTE*60,
  DAY=HOUR*24, WEEK=DAY*7, YEAR=DAY*365 };

text month_names[]={ "January", "February",
  "March", "April", "May", "June", "July", "August",
  "September", "October", "November", "December" };

text day_names[]={ "Sunday", "Monday", "Tuesday",
  "Wednesday", "Thursday", "Friday", "Saturday" };

/*
text time_when[]={ "Today", "Yesterday", "Tomorrow",
  "Soon", "Recently", "Later" };

text time_often[]={ "Always", "Often", "Sometimes",
  "Rarely", "Never" };
*/

void get_time(TIME *t) {
  time_t tt;
  time(&tt);
  struct tm *ts=localtime(&tt);
  t->month=ts->tm_mon, t->day=ts->tm_mday,
  t->weekday=ts->tm_wday, t->year=1900+ts->tm_year;
  t->hour=ts->tm_hour, t->minute=ts->tm_min,
  t->second=ts->tm_sec, t->xm=0;
  if (t->hour==0)
    t->hour=12, t->xm=1;
  else if (t->hour>12)
    t->hour-=12, t->xm=1;
}

#define get_date(t) get_time(t)

int is_leap_year(int year) {
  return ((!(year%4) && year%100) or !(year%400));
}

/*
// 2-do: example of multiple timers

object {
  uint ms, i, n;
  int (*function)(void *);
  BOX box;
} TIMER;

ARRAY timers;

int clock_timer(), ball_timer(), sprite_timer(),
  explosion_timer();

// set timer unit. lowest value. default = 1 MS

event_create
  set_timer_unit(1);
  create_timer(clock_timer, 1000);
  create_timer(ball_timer, 25);
  create_timer(sprite_timer, 100);
  create_timer(explosion_timer, 250);
end

int clock_timer() {
  get_time(time_text);
  return 1;
}

int ball_timer() {
  ball1.x+=ball1.vx,
  ball1.y+=ball1.vy;
  return 1;
}
*/