/* EZC LIBRARY. BY STARPOWER/MYSTERI/OUS.
    __  ___         __          _
  /  |/  /_ _____ / /____ ____(_)
 / /|_/ / // (_-<  __/ -_) __/ /
/_/  /_/\_, /___/\__/\__/_/ /_/
       /___/ (C) 2016+, KID-7/77 */

void say(char *t) { MessageBox(0, t, t, 0); }

//////////////////// WINDOW //////////////////////

#define WS_BLANK WS_VISIBLE|WS_POPUP|CS_DBLCLKS
#define WS_STANDARD WS_VISIBLE|WS_OVERLAPPED|\
  WS_CAPTION|WS_SYSMENU|WS_MINIMIZEBOX|CS_DBLCLKS

// WS_EX_ACCEPTFILES

HINSTANCE h_instance;
HWND h_window;
MSG msg;
HDC h_dc, h_mdc;
RECT screen_r;
BITMAP w_bmp;
HBITMAP screen_hbmp;
BITMAPINFO screen_bmi;

LRESULT CALLBACK window_function(HWND w,
  UINT m, WPARAM wp, LPARAM lp);

///////////////////// EVENTS /////////////////////

int event_type, initialized=0;

#define event_main int on_main() {
#define event_create int on_create() {
#define event_draw int on_draw() {
#define event_input int on_input() {
#define event_timer int on_timer() {
#define event_exit int on_exit() {
#define ende return 1; }

#define event_key (event_type=='k' \
  and key_type=='k')
#define event_key_c (event_type=='k' \
  and key_type=='c')
#define event_key_r (event_type=='k' \
  and key_type=='r')
#define event_key_release (event_type=='k' \
  and key_type=='r')
#define event_mouse (event_type=='m')
#define event_mouse_move (event_type=='m' \
  and mouse_type=='m')
#define event_mouse_drag (event_type=='m' \
  and mouse_type=='d')
#define event_mouse_down (event_type=='m' \
  and mouse_type=='c')
#define event_mouse_press event_mouse_down
#define event_mouse_click event_mouse_down
#define event_mouse_release (event_type=='m' \
  and mouse_type=='r')
#define event_mouse_right_down (event_type=='m' \
  and mouse_type=='C')
#define event_mouse_right_click event_mouse_right_down
#define event_mouse_right_release (event_type=='m' \
  and mouse_type=='r')
#define event_mouse_wheel (event_type=='m' \
  and mouse_type=='w')

#ifdef ON_CREATE
  extern int on_create();
#endif

#ifdef ON_DRAW
  extern int on_draw();
#endif

#ifdef ON_INPUT
  extern int on_input();
#endif

#ifdef ON_EXIT
  extern int on_exit();
#endif

#ifdef ON_TIMER
  extern int on_timer();

  void set_timer(int ms) {
    SetTimer(h_window, 1, ms, (TIMERPROC) 0);
  }
#endif

////////////////////// INPUT /////////////////////

#define mouse_click mouse_1

int key, key_type, key_flags,
  mouse_type, mouse_x, mouse_y, mouse_px, mouse_py,
  mouse_1, mouse_2, mouse_p1, mouse_p2,
  mouse_last_up, mouse_last_double, mouse_double,
  mouse_double_speed=350, mouse_triple,
  mouse_wheel, mouse_drag, mouse_drop,
  mouse_down_x, mouse_down_y,
  mouse_drag_x, mouse_drag_y,
  mouse_drop_x, mouse_drop_y,
  screen_down_x, screen_down_y;
int exit_if_esc=1;

enum { K_UP=VK_UP, K_RIGHT=VK_RIGHT,
  K_DOWN=VK_DOWN, K_LEFT=VK_LEFT, K_HOME=VK_HOME,
  K_SPACE=VK_SPACE, K_TAB=VK_TAB, K_BACKSPACE=VK_BACK,
  K_DELETE=VK_DELETE, K_CONTROL=VK_CONTROL,
  K_SHIFT=VK_SHIFT, K_ALT=VK_MENU, K_MENU=VK_MENU,
  K_ESCAPE=VK_ESCAPE, K_RETURN=VK_RETURN,
  K_INSERT=VK_INSERT, K_PAGE_UP=VK_PRIOR,
  K_PAGE_DOWN=VK_NEXT };
enum { K_L_CTRL=162, K_R_CTRL, K_L_ALT, K_R_ALT };

int keys(int k) { return GetAsyncKeyState(k); }

int select_it(int x, int y, int w, int h) {
  return (mouse_x>=x and mouse_x<x+w
    and mouse_y>=y and mouse_y<y+h);
}

int click_it(int x, int y, int w, int h) {
  return mouse_click and select_it(x, y, w, h);
}

int select_box(BOX *b) {
  return select_it(b->x, b->y, b->w, b->h);
}

int click_box(BOX *b) {
  return click_it(b->x, b->y, b->w, b->h);
}

//////////////////////////////////////////////////

object {
  int x, y, w, h, id, state,
    message, event, wp, lp;
  HWND hwnd;
  WNDCLASSEX wc;
  int (*event_p)(int m, int a, int b);
} WINDOW;

WINDOW *window_p=0;

typedef LRESULT CALLBACK Event;

char *window_class_name="wc1";

#ifdef ON_DRAW

int make_window(WINDOW *window, char *title,
  int style, int x, int y, int w, int h,
  Event (*fp)(HWND, UINT, WPARAM, LPARAM)) {
  if (h>=720)
    y=0;
  window->x=x, window->y=y;
  window->w=w, window->h=h;
  window_p=window;
  WNDCLASSEX *p=&window->wc;
  memory_set(p, 0, 48);
  p->cbSize=48;
  p->hInstance=h_instance;
  p->lpszClassName=window_class_name;
  p->hbrBackground=(HBRUSH)
    GetStockObject(WHITE_BRUSH);
  p->hCursor=(HCURSOR)
    LoadCursor(0, IDC_ARROW);
  p->lpfnWndProc=fp;
  if (!RegisterClassEx(p))
    return 0;
  if (!(window->hwnd=CreateWindowEx(0,
    window_class_name, title, style, x, y, w, h,
    0, 0, h_instance, 0)))
    return 0;
  ShowWindow(window->hwnd, SW_SHOW);
  UpdateWindow(window->hwnd);
  h_window=window->hwnd;
  return 1;
}

int make_main_window(WINDOW *window, char *title,
  int style, int w, int h, Event (*fp)(HWND,
  UINT, WPARAM, LPARAM)) {
  screen_w=w, screen_h=h;
  int x=(os_w/2)-(w/2),
    y=(os_h/2)-(h/2);
  return make_window(window, title, style,
    x, y, w, h, fp);
}

int create_blank_window(int w, int h) {
  int x, y;
  WNDCLASSEX wc={ 48, 0, window_function,
    0, 0, h_instance, 0, 0, 0, 0,
    window_class_name, 0 };
  x=(os_w/2)-(w/2), y=(os_h/2)-(h/2);
  wc.hbrBackground=(HBRUSH)
    GetStockObject(BLACK_BRUSH);
  wc.hCursor=(HCURSOR)
    LoadCursor(0, IDC_ARROW);
  wc.lpfnWndProc=window_function;
  if (!RegisterClassEx(&wc))
    return 0;
  if (!(h_window=CreateWindowEx(0,
    window_class_name, "", WS_BLANK, x, y,
    w, h, 0, 0, h_instance, 0)))
    return 0;
  ShowWindow(h_window, SW_SHOW);
  UpdateWindow(h_window);
  return 1;
}

// windows event function. see EZ.H > WinMain

int show_title_bar=0, draw_title_before=1,
  moving_window=0, mouse_tracking=0;

LRESULT CALLBACK window_function(HWND w,
  UINT m, WPARAM wp, LPARAM lp) {
  int i, x, y;
  RECT r;
  event_type=0, key_type=0;
  mouse_type=0, mouse_wheel=0;
  mouse_drop=0, mouse_last_double=mouse_double,
  mouse_double=0, mouse_triple=0;
  
  GetWindowRect(h_window, &r);
  screen_x=r.left, screen_y=r.top;
  extern text title_text_p;
  extern BOX title_box;
  extern void input_title();

  if (m==WM_CREATE) {
    goto _default;
  }
  else if (m==WM_DESTROY) {
    exit();
    return 0;
  }
  else if (m==WM_ACTIVATE) {
    mouse_1=mouse_2=mouse_drag=key=0;
    mouse_type=key_type=0;
  }
  else if (m==WM_TIMER) {
    #ifdef ON_TIMER
      on_timer();
    #endif
    return 0; // goto default;
  }
  else if (m==WM_PAINT) {
    if (!initialized)
      return 0;
    extern void draw_title();
    //if (show_title_bar and draw_title_before)
    //  draw_title();
    if (do_clear_screen)
      clear_screen(screen_color);
    on_draw();
    if (show_title_bar and !draw_title_before)
      draw_title();
    // minus hot_spot_x/y
    /*
    extern IMAGE arrow_cursor;
    if (arrow_cursor.p)
      draw_image_at(&arrow_cursor, mouse_x, mouse_y);
    */
    show_screen();
    goto _default;
  }
  else if (m==WM_KEYDOWN) {    
    key=wp, key_type='k';
    _key:
    event_type='k';
    #ifdef ON_INPUT
      on_input();
    #endif
    if (exit_if_esc and key==VK_ESCAPE) {
      exit();
    }
    return 0;
  }
  else if (m==WM_KEYUP) {
    key=0, key_type='r';
    goto _key;
  }
  else if (m==WM_CHAR) {
    key=wp, key_type='c';
    goto _key;
  }   
  /*  
  else if (m==WM_SYSKEYDOWN) {
    key=wp, event_type='k', key_type='k';
    if (key==K_L_ALT or key==K_R_ALT)
      key_alt=1;
    goto _key;
  }
  else if (m==WM_SYSKEYUP) {
    key=wp, event_type='k', key_type='r';
    if (key==K_L_ALT or key==K_R_ALT)
      key_alt=0;
    goto _key;
  }
  */
  else if (m==WM_MOUSEMOVE) {
    mouse_type='m';
    // track mouse and send WM_MOUSELEAVE when
    // it leaves window
    /*
    TRACKMOUSEEVENT tme;
    if (not mouse_tracking) {
      mouse_tracking=1;
      tme.cbSize=sizeof(tme);
      tme.hwndTrack=h_window;
      tme.dwFlags=TME_LEAVE; // send WM_MOUSELEAVE
      tme.dwHoverTime=1; // 1 ms, immediately
      TrackMouseEvent(&tme);
    }*/
    _mouse: // mouse event
    event_type='m';
    mouse_px=mouse_x, mouse_py=mouse_y;
    mouse_x=lp&0xFFFF, mouse_y=(lp>>16)&0xFFFF;
    if (mouse_1)
      mouse_drag=1;
    
    if (mouse_drag and select_box(&title_box)) {
      /*
      mouse_drag_x=mouse_x, mouse_drag_y=mouse_y;
      x=screen_x+(mouse_x-mouse_down_x);
      y=screen_y+(mouse_y-mouse_down_y);
      SetWindowPos(h_window, 0, x, y, 0, 0, SWP_NOACTIVATE|
        SWP_NOOWNERZORDER|SWP_NOZORDER|SWP_NOSIZE);
      */
    }
    if (title_text_p)
      input_title();
    #ifdef ON_INPUT
      on_input();
    #endif
    goto _default;
  }
  else if (m==WM_MOUSELEAVE) {
    /*
    mouse_type=0, event_type='m';
    x=?, y=?;
    SetCursorPos(x, y);
    mouse_tracking=0;
    */
    goto _default;
  }

/*
  else if (m==WM_NCMOUSEMOVE) {
    mouse_type='', event_type='m';
    goto _default;
  }
  else if (m==WM_NCLBUTTONDOWN) {
    mouse_type='', mouse_p1=mouse_1, mouse_1=1, mouse_drop=0;
    mouse_down_x=mouse_x, mouse_down_y=mouse_y;
    goto _mouse;
  }
  */
  else if (m==WM_LBUTTONDOWN) {
    if (select_box(&title_box)) {
      // SetCapture(h_window);
    }
    mouse_type='c', mouse_p1=mouse_1, mouse_1=1, mouse_drop=0;
    mouse_down_x=mouse_x, mouse_down_y=mouse_y;
    goto _mouse;
  }
  else if (m==WM_LBUTTONUP) {
    if (get_ms()-mouse_last_up<mouse_double_speed) {
      if (not mouse_last_double) {
        mouse_double=1;
      }
      else {
        mouse_last_double=0, mouse_triple=1;
      }
    }
    mouse_last_up=get_ms();
    mouse_type='r', mouse_p1=mouse_1, mouse_1=0;
    if (mouse_drag) {
      mouse_drag=0, mouse_drop=1;
      mouse_drop_x=mouse_x, mouse_drop_y=mouse_y;
    }
    // ReleaseCapture();
    goto _mouse;
  }
  else if (m==WM_RBUTTONDOWN) {
    mouse_type='C', mouse_p2=mouse_2, mouse_2=1;
    goto _mouse;
  }
  else if (m==WM_RBUTTONUP) {
    mouse_type='R', mouse_p2=mouse_2, mouse_2=0;
    goto _mouse;
  }
  else if (m==WM_MOUSEWHEEL) {
    mouse_type='w', mouse_wheel=(short) (wp>>16);
    goto _mouse;
  }
  _default:
  return DefWindowProc(w, m, wp, lp);
}

int os_cursor_visible=1;

void os_show_cursor(int i) {
  if (i==os_cursor_visible)
    return;
  ShowCursor(i);
  os_cursor_visible=i;
}

void os_minimize() {
  mouse_1=mouse_2=mouse_drag=key=0;
  mouse_type=key_type=0;
  ShowWindow(h_window, SW_MINIMIZE);
  mouse_1=mouse_2=mouse_drag=key=0;
  mouse_type=key_type=0;
}

void os_move_screen(int x, int y) {
  MoveWindow(h_window, x, y, screen_w, screen_h, 1);
}

#endif // ON_DRAW

///////////////////// BITMAP /////////////////////

typedef HBITMAP OS_BITMAP;

OS_BITMAP os_load_bitmap(text name) {
  OS_BITMAP os_bmp;
  os_bmp=LoadImageA(h_instance, name,
    0, 0, 0, 0x10);
  if (!os_bmp)
    return 0;
  GetObjectA(os_bmp, sizeof(BITMAP), &w_bmp);
  return os_bmp;
}

void os_draw_bitmap(OS_BITMAP os_bmp,
  int x, int y, int w, int h) {
  int bw, bh;
  GetObjectA(os_bmp, sizeof(BITMAP), &w_bmp);
  bw=w_bmp.bmWidth, bh=w_bmp.bmHeight;
  h_mdc=CreateCompatibleDC(h_dc);
  SelectObject(h_mdc, os_bmp);
  StretchBlt(h_dc, x, y, w, h,
    h_mdc, 0, 0, bw, bh, SRCCOPY);
  DeleteDC(h_mdc);
}

void os_destroy_bitmap(OS_BITMAP os_bmp) {
  DeleteObject(os_bmp);
}

/////////////////// CLIPBOARD ////////////////////

int is_clipboard_text() {
  return IsClipboardFormatAvailable(1);
}

text get_clipboard_text() {
  int n;
  text p, q;
  if (!is_clipboard_text())
    return 0;
  if (!OpenClipboard(0))
    return 0;
  p=GetClipboardData(1);
  CloseClipboard();
  return p;
}

int set_clipboard_text(text t) {
  int r=1;
  uint n=text_n(t);
  HGLOBAL hg;
  text q, p=GlobalAlloc(GMEM_MOVEABLE|GMEM_DDESHARE, n+1);
  q=GlobalLock(p);
  memory_copy(q, t, n+1);
  q[n]=0;
  GlobalUnlock(hg);
  if (!OpenClipboard(0))
    return 0;
  EmptyClipboard();
  if (!SetClipboardData(1, p))
    r=0;
  CloseClipboard();
  return r;
}

// set_clipboard_bitmap(image->p, image->w, image->h);

int set_clipboard_bitmap(uint *pixels, int w, int h) {
  if (!pixels or w<=1 or h<=1)
    return 0;
  HBITMAP bmp_new=
    CreateBitmap(w, h, 1, 32, pixels);
  HDC source_dc=CreateCompatibleDC(GetDC(0)),
    new_dc=CreateCompatibleDC(GetDC(0));
  HBITMAP source_bmp=(HBITMAP) SelectObject(source_dc, pixels),
    new_bmp=(HBITMAP) SelectObject(new_dc, bmp_new);
  BitBlt(new_dc, 0, 0, w, h, source_dc, 0, 0, SRCCOPY);
  SelectObject(source_dc, source_bmp);
  SelectObject(new_dc, new_bmp);
  DeleteDC(source_dc);
  DeleteDC(new_dc);
  if (!OpenClipboard(0))
    return 0;
  EmptyClipboard();
  SetClipboardData(CF_BITMAP, bmp_new);
  CloseClipboard();
  return 1;
}

//////////////////// SCREEN //////////////////////

int os_create_screen(int w, int h) {
  if (!(screen_hbmp=CreateBitmap(w, h, 32,
    1, screen_p)))
    return 0;
  int n=sizeof(BITMAPINFOHEADER);
  BITMAPINFOHEADER *p=&screen_bmi.bmiHeader;
  memory_zero(&screen_bmi, n);
  p->biSize=n;
  p->biWidth=w, p->biHeight=-h;
  p->biPlanes=1, p->biBitCount=32;
  if (!create_blank_window(w, h))
    return 0;
  return 1;
}

void show_screen() {
  h_dc=GetDC(h_window);
  SetDIBits(h_dc, screen_hbmp, 0, screen_h,
    (void *) screen_p, &screen_bmi, 0);
  os_draw_bitmap(screen_hbmp, 0, 0,
    screen_w, screen_h);
  ReleaseDC(h_window, h_dc);
  screen_r.left=0, screen_r.top=0;
  screen_r.right=screen_w;
  screen_r.bottom=screen_h;
  InvalidateRect(h_window, &screen_r, 0);
}

void render() {
  h_dc=GetDC(h_window);
  RECT screen_r={ 0, 0, screen_w, screen_h };
  SetDIBits(h_dc, screen_hbmp, 0, screen_h,
    screen_p, &screen_bmi, 0);
  os_draw_bitmap(screen_hbmp,
     0, 0, screen_w, screen_h);
  InvalidateRect(h_window, &screen_r, 0);
}

void render_box(BOX *b) {
  h_dc=GetDC(h_window);
  RECT screen_r={ b->x, b->y,
    b->x+b->w, b->y+b->h };
  SetDIBits(h_dc, screen_hbmp, 0, screen_h,
    screen_p, &screen_bmi, 0);
  os_draw_bitmap(screen_hbmp,
     b->x, b->y, b->w, b->h);
  InvalidateRect(h_window, &screen_r, 0);
}

// redraw all or section

int redraw() {
  if (!on_draw())
    return 0;
  extern void draw_title();
  extern text title_text_p;
  if (title_text_p)
    draw_title();
  show_screen();
  return 1;
}

///////////////////// ERROR //////////////////////

void os_exit() {
  #ifdef SYSTEM_WINDOWS
    // unload_imports();
    ExitProcess(0);
    PostQuitMessage(0);
  #endif
}

void exit() {
  #ifdef EXIT
    if (!on_exit())
      return;
  #endif
  os_exit();
}

void quit(text why) {
  say(why);
  exit();
}

// WINDOWS FILE DIALOG

//#include <commdlg.h>

/*

DECLSPEC_IMPORT WINBOOL WINAPI GetOpenFileNameA(LPOPENFILENAMEA);

typedef UINT_PTR (CALLBACK *LPOFNHOOKPROC)(HWND,UINT,WPARAM,LPARAM);
  
typedef struct tagOFNA {
  DWORD lStructSize;
  HWND hwndOwner;
  HINSTANCE hInstance;
  LPCSTR lpstrFilter;
  LPSTR lpstrCustomFilter;
  DWORD nMaxCustFilter;
  DWORD nFilterIndex;
  LPSTR lpstrFile;
  DWORD nMaxFile;
  LPSTR lpstrFileTitle;
  DWORD nMaxFileTitle;
  LPCSTR lpstrInitialDir;
  LPCSTR lpstrTitle;
  DWORD Flags;
  WORD nFileOffset;
  WORD nFileExtension;
  LPCSTR lpstrDefExt;
  LPARAM lCustData;
  LPOFNHOOKPROC lpfnHook;
  LPCSTR lpTemplateName;
  void *pvReserved;
  DWORD dwReserved;
  DWORD FlagsEx;
} OPENFILENAMEA;

OPENFILENAMEA ofn; 

text os_open_file_dialog() {
  memory_zero(&ofn, sizeof(OPENFILENAMEA));
  char name[260];
  ofn.lStructSize=sizeof(ofn);
  ofn.hwndOwner=window_p->hwnd;
  ofn.lpstrFile=name, ofn.nMaxFile=260;
  ofn.lpstrFilter="All\0*.*\0Text\0*.TXT\0"; 
  ofn.nFilterIndex=1, ofn.lpstrFileTitle=0;
  ofn.nMaxFileTitle=0, ofn.lpstrInitialDir=0;
  enum { OFN_PATHMUSTEXIST=0x800,
    OFN_FILEMUSTEXIST=0x1000 };
  ofn.Flags=OFN_PATHMUSTEXIST|OFN_FILEMUSTEXIST;

  if(GetOpenFileNameA(&ofn))
    return ofn.lpstrFile;
  return 0;
}
*/

/*
ERROR SYSTEM

set_error("record");
// ...
end_error(); // reset previous. optional

enum { ERROR_IGNORE, ERROR_RECORD,
  ERROR_DISPLAY, ERROR_SERIOUS };

* ignore: don't save errors, or exit. functions
return failure, and allow for custom response
by the caller (example: load_image)
* record: save errors (log.txt), but don't
display or exit. this should be default,
but exit if it's "serious" like p=allocate(n),
or load_font(&main_font, "main")
* display: display errors, and save them,
but don't exit
* serious: display + exit

Error: Memory Allocate: #size
Error: Memory Read/Write: #address, #size
Error: Array[#index] exceeds boundaries
Error: File Read/Write: $name
Error: Load File: $name
Error: Save File: $name
Error: Invalid file type: $name
Error: Unsupported file extension: *.$name
Error: Invalid file header: $name
Error: Corrupt file format: $name
Error: Unexpected end reached: $name

standard low-level file functions - open_file,
create_file, etc - return 0 if failure, and
don't record or respond to errors. error
checking is performed in higher level functions
like load_image(image, name)
*/

#ifdef SYSTEM_ERRORS

object {
  byte action, name, serious, a;
  void *data;
} SYSTEM_ERROR;

ARRAY system_errors;
uint maximum_system_errors=32;

text system_actions[]={
  "None", "Setup", "Create", "Destroy", "Load",
  "Save", "Access", "Read", "Write", "Convert" };

enum {
  ER_NONE, ER_SETUP, ER_CREATE, ER_DESTROY,
  ER_LOAD, ER_SAVE, ER_ACCESS, ER_READ,
  ER_WRITE, ER_CONVERT };

text system_objects[]={
  "None", "Memory", "Number", "Text", "Array",
  "Device", "File", "Resource", "Control",
  "Image", "Font", "Sound", "Video" };

enum {
  ER_NONE, ER_MEMORY, ER_NUMBER, ER_TEXT, ER_ARRAY,
  ER_DEVICE, ER_FILE, ER_RESOURCE, ER_CONTROL,
  ER_IMAGE, ER_FONT, ER_SOUND, ER_VIDEO };

int setup_system_errors() {
  if (!array_create(&system_errors, sizeof(SYSTEM_ERROR)))
    return 0;
  return 1;
}

#define system_error(action, o, x) \
  system_error_x(ER_##action, ER_##o, x)

int system_error_x(int a, int o, void *x);

int error_exit(int a, int o, void *x) {
  system_error_x(a, o, x);
  exit();
  return 0;
}

#define error_allocate(type) \
  system_error(ALLOCATE, type, 0)
#define exit_allocate(type) \
  error_exit(ALLOCATE, type, 0)

#define error_array() error_allocate(ARRAY)
#define exit_array() exit_allocate(ARRAY)

#define error_load_file(type, name) \
  system_error(LOAD, type, name)
#define exit_load_file(type, name) \
  error_exit(LOAD, type, name)

#define error_load_image(name) \
  error_load_file(IMAGE, name)
#define exit_load_image(name) \
  exit_load_file(IMAGE, name)

int system_error_x(int action, int o,
  int serious, void *x) {
  SYSTEM_ERROR *se;
  if (system_errors.n>=maximum_system_errors)
    return 0;
  if (!(se=array_expand(&system_errors)))
    return error_array();
  se->action=action, se->objec=o,
  se->serious=serious, se->data=x;
  return 0; // always
}

void display_system_error(int a, int b, void *c) {
  char t[256];
  text p=(text) c;  
}

#endif

// setup_printer(...);
// printer(text command, void *p);
// printer("print text", (text) "Message");
// printer("print text file", (text) "name");
// printer("print image", (IMAGE *) &image);

/////////////////// DIRECTORY ////////////////////

int os_create_directory(text t) {
  return CreateDirectory(t, 0);
}

int os_set_directory(text t) {
  return SetCurrentDirectory(t);
}

int os_get_directory(text t) {
  // reslash(t)
  if (!GetCurrentDirectory(256, t))
    return 0;
  // deslash(t)
  return 1;
}

/////////////// FILE OPERATIONS //////////////////

int os_copy_file(text a, text b) {
  return CopyFile(a, b, 0);
}

int os_move_file(text a, text b) {
  return MoveFile(a, b);
}

int os_delete_file(text a) { return DeleteFile(a); }

int file_time_to_system(FILETIME *file_time, SYSTEMTIME *system_time) {
  return FileTimeToSystemTime(file_time, system_time);
}

int get_file_time(SYSTEMTIME *create, SYSTEMTIME *access,
  SYSTEMTIME *modify) {
  FILETIME create_ft, access_ft, modify_ft;
  GetFileTime(file_p, &create_ft, &access_ft, &modify_ft);
  file_time_to_system(&create_ft, create);
  file_time_to_system(&access_ft, access);
  file_time_to_system(&modify_ft, modify);
}

////////////////// FIND FILES ////////////////////

HANDLE find_data_h;
WIN32_FIND_DATAA find_data;
text found_file=0;

text os_find_first(text name) {
  found_file=0;
  if (!(find_data_h=FindFirstFile(name,
    &find_data)))
    return 0;
  return found_file=find_data.cFileName;
}

text os_find_next() {
  if (!FindNextFile(find_data_h, &find_data))
    return 0;
  return found_file=find_data.cFileName;
}

void os_find_end() {
  FindClose(find_data_h);
}

//////////////////// EXECUTE /////////////////////

int os_execute(text name) {
  // system(name);
  // ShellExecute(0, 0, name, 0, 0, 3);
  STARTUPINFO si;
  PROCESS_INFORMATION pi;
  ZeroMemory(&si, sizeof(si));
  ZeroMemory(&pi, sizeof(pi));
  si.cb=sizeof(si);
  if (!CreateProcess(0, name, 0, 0, 0, 
    CREATE_NO_WINDOW, 0, 0, &si, &pi))
    return 0;
  return 1;
}