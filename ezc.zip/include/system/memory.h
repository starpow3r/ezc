/* EZC LIBRARY. BY STARPOWER/MYSTERI/OUS.
    __  ___         __          _
  /  |/  /_ _____ / /____ ____(_)
 / /|_/ / // (_-<  __/ -_) __/ /
/_/  /_/\_, /___/\__/\__/_/ /_/
       /___/ (C) 2016+, KID-7/77 */

// memory allocation, copy, move, set, zero

#define allocate(t,p,n) (p=(t)malloc(n))
#define reallocate(t,p,n) (p=(t)realloc(p,n))
#define relocate(t,p,n) (p=(t)realloc(p,n))
#define destroy(p) free(p), p=0

#define memory_copy(a,b,n) memcpy(a,b,n)
#define memory_move(a,b,n) memmove(a,b,n)
#define memory_set(p,v,n) memset(p,v,n)
#define memory_zero(p,n) memset(p,0,n)

// binary arithmetic: get, set, zero,
// assign, or rotate bits of n at i/ndex,
// or from s/tart-e/nd

#define get_bit(n, i) (((n)>>(i))&1)
#define get_bits(n, s, e) \
  (((n)>>(e))&~(1<<((s)-(e)+1)))
#define set_bit(n, i) n|=(1<<(i))
#define set_bits(n, s, e, v) \
  n|=((v)<<((s)-(e)+1))
#define zero_bit(n, i) n&=~(1<<(i))
#define zero_bits(n, s, e) \
  n&=~(((1<<((s)-(e)+1))-1)<<(e))
#define assign_bits(n, s, e, v) \
  zero_bits(n, s, e), set_bits(n, s, e, v)
#define rotate_bits(v, n, size) \
  (((v)>>(n)|((v)<<((size)-(n))))&((1<<(size))-1))

/*
// #=76543210b // example usage
// N=10101111b // get_bits(n, 7, 4)=00001010b
// N=11111111b // zero_bits(n, 5, 2), n=11000011b
// N=11000111b // set_bits(n, 5, 3, 7), n=11111111b
// N=11100011b // rotate_bits(n, 2, 8)=11111000b

#define print_bits() \
  print(t, "Bits: N=%bb. " \
    "J=%bb", n, j), puts(t)

uint n, j;
char t[128];
n=0xAF, j=get_bits(n, 7, 4);       // 10101111b, 00001010b
print_bits();
n=0xFF, j=n, zero_bits(j, 5, 2);   // 11111111b, 11000011b
print_bits();
n=0xC7, j=n, set_bits(j, 5, 3, 7); // 11000111b, 11111111b
print_bits();
n=0xE3, j=rotate_bits(n, 2, 8);    // 11100011b, 11111000b
print_bits();
*/

// search value for 1st bit set from left to right (31-0).
// get number of bits-1 required to store n (or -1 if n=0)

uint first_bit(uint n) {
  uint i;
  for (i=31; i>=0; i--)
    if (n&(1<<i))
      return i;
  return -1;
}

int seed_n=0;

int random(int to) {
  if (!seed_n) {
    seed_n=time(0);
    srand(seed_n);
  }
  return (rand()%to);
}

int random_n(int from, int to) {
  return (random((to+1)-from)+from);
}

// memory usage

uint program_memory=0, executable_memory=0,
  text_memory=0, image_memory=0, font_memory=0,
  icon_memory=0, control_memory=0, sound_memory=0,
  text_memory_n=0, image_memory_n=0, font_memory_n=0,
  icon_memory_n=0, control_memory_n=0, sound_memory_n=0,
  image_file_size=0, font_file_size=0, icon_file_size=0;