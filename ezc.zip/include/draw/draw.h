/* EZC LIBRARY. BY STARPOWER/MYSTERI/OUS.
    __  ___         __          _
  /  |/  /_ _____ / /____ ____(_)
 / /|_/ / // (_-<  __/ -_) __/ /
/_/  /_/\_, /___/\__/\__/_/ /_/
       /___/ (C) 2016+, KID-7/77 */

////////////////////// DRAW //////////////////////

#define xy(x, y) (((y*screen_w)+x)*4)
#define screen_xy(x, y) screen_p[xy(x, y)]
#define color_xy(x, y) screen_xy(x, y)

#define xy2(x, y) (((y*screen_w)+x)*2)
#define screen_xy2(x, y) screen_p[xy2(x, y)]
#define color_xy2(x, y) screen_xy2(x, y)
#define sgn(x) ((x<0)?-1:((x>0)?1:0))

void clear_screen(color c);
int draw_pixel(int x, int y, color c);
int draw_line_h(int x, int y, int w, color c);
int draw_line_v(int x, int y, int h, color c);
int draw_line(int x, int y, int x2, int y2, color c);
int draw_box(BOX *box, color c, color o);

int draw_circle(int x, int y, int w, int h, color c);
int outline_circle(int x, int y, int w, int h, color c);
int draw_scanline(void *p, int x, int y, int w,
  int key, int alpha, int style);
int draw_bitmap(void *p, int x, int y,
  int w, int h, int key, int alpha, int style);

int draw_line_g(int orient, int type, int x, int y,
  int wh, color a, color b);
int draw_fade_d(BOX *b, int orient, color c1, color c2);
int draw_shade_d(BOX *b, int orient, color c1, color c2);
int draw_gradient(int orient, int type, int x, int y,
  int w, int h, color a, color b);
int draw_bevel(int x, int y, int w, int h,
  color a, color b, int state, int n); 

int visible_line_h(int x, int y, int w);
int visible_line_v(int x, int y, int h);
int clip_line_h(int *x, int *y, int *w);
int clip_line_v(int *x, int *y, int *h);
int clip_scanline_h(int *i, int *x, int *y, int *w);

/*
popular screen sizes:

HD: 1920x1080, 1280x720, 1024x576, 960x540,
  720x405, 512x288, 240x135, 192x108, 96x54
SD: 1024x768, 640x480, 320x240, 160x120
arduino: 480x320, 480x272, 320x240, 240x240,
  240x135, 160x128, 128x128, 128x64, 64x32
*/

BOX screen_box;

int create_screen(int w, int h);
extern int os_create_screen(int w, int h);
extern void show_screen();

int create_screen(int w, int h) {
  if (!allocate(void *, screen_p, w*h*4))
    return 0;
  screen_w=w, screen_h=h;
  screen_box.x=0, screen_box.y=0;
  screen_box.w=w, screen_box.h=h;
  if (!os_create_screen(w, h))
    return 0;
  return 1;
}

#define create_screen_hd() create_screen(1920, 1080)

///////////////////// STYLE //////////////////////

// global style variables. see FONT > STYLE

uint graphics_style, graphics_n_colors,
  graphics_direction='v', graphics_line_w,
  graphics_alpha, graphics_shadow_alpha,
  graphics_shadow_x, graphics_shadow_y;

color graphics_color, graphics_line_color,
  graphics_fade_color, graphics_shadow_color,
  graphics_key, graphics_alpha;
color graphics_colors[16];

enum {
  G_SOLID=1, G_PIXEL=2, G_LINE=4, G_BOX=8, G_CIRCLE=16,
  G_SCANLINE=32, G_OUTLINE=64, G_FADE=128, G_SHADE=256,
  G_CHROME=512, G_RAINBOW=1*KB, G_REVERSE=2*KB, G_ORIENT=4*KB,
  G_INVERT_X=8*KB, G_INVERT_Y=16*KB, G_ROTATE_L=32*KB,
  G_ROTATE_R=64*KB, G_ROTATE_R2=128*KB, G_TEXT=256*KB,
  G_SHADOW=512*KB, G_RASTER=1*MB, G_BITMAP=2*MB, G_ALPHA=4*MB,
  G_KEY=8*MB, G_STRETCH=16*MB, G_SCROLL=32*MB, G_COLOR=64*MB,
  G_GRAYSCALE=128*MB, G_COLORSCALE=256*MB, G_TEXTURE=512*MB,
  G_BRUSH=1*GB, G_EFFECT=2*GB, G_VISTA=G_FADE+G_CHROME,
  G_NONE=0
};

enum { G_SOLID_BOX=G_BOX+G_SOLID+G_OUTLINE };
enum { G_FADE_BOX=G_BOX+G_FADE+G_OUTLINE };
enum { G_SHADE_BOX=G_BOX+G_SHADE+G_OUTLINE };
enum { G_CHROME_BOX=G_BOX+G_CHROME+G_OUTLINE };
enum { G_RAINBOW_BOX=G_BOX+G_RAINBOW+G_OUTLINE };

void set_graphic(uint s) { graphics_style=s; }
void set_alpha(byte a) { graphics_alpha=a; }
void set_color(color c) { graphics_color=c; }
void set_line_color(color c) { graphics_line_color=c; }
void set_line_w(uint w) { graphics_line_w=w; }
void set_fade_color(color c) { graphics_fade_color=c; }
void set_shadow_alpha(byte a) { graphics_shadow_alpha=a; }
void set_shadow_color(color c) { graphics_shadow_color=c; }
void set_shadow_depth(int x, int y) { graphics_shadow_x=x,
  graphics_shadow_y=y; }

void set_shadow(color c, int x, int y, byte a) {
  graphics_shadow_color=c, graphics_shadow_alpha=a,
  graphics_shadow_x=x, graphics_shadow_y=y;
}

void set_fade_colors(color fade_c, color main_c, color line_c) {
  graphics_fade_color=fade_c, graphics_color=main_c;
  graphics_line_color=line_c;
}

void set_shade_colors(color fade_c, color main_c, color line_c) {
  set_fade_colors(fade_c, main_c, line_c);
}

void set_colors(color main_c, color line_c,
  color fade_c, color shadow_c) {
  graphics_n_colors=4;
  graphics_color=main_c, graphics_line_color=line_c;
  graphics_fade_color=fade_c, graphics_shadow_color=shadow_c;
}

void set_colors_8(color c1, color c2, color c3, color c4,
  color c5, color c6, color c7, color c8) {
  graphics_n_colors=8;
  graphics_colors[0]=c1, graphics_colors[1]=c2;
  graphics_colors[2]=c3, graphics_colors[3]=c4;
  graphics_colors[4]=c5, graphics_colors[5]=c6;
  graphics_colors[6]=c7, graphics_colors[7]=c8;
}

void set_colors_16(
  color c1, color c2, color c3, color c4,
  color c5, color c6, color c7, color c8,
  color c9, color c10, color c11, color c12,
  color c13, color c14, color c15, color c16) {
  set_colors_8(c1, c2, c3, c4, c5, c6, c7, c8);
  graphics_n_colors=16;
  graphics_colors[8]=c9, graphics_colors[9]=c10;
  graphics_colors[10]=c11, graphics_colors[11]=c12;
  graphics_colors[12]=c13, graphics_colors[13]=c14;
  graphics_colors[14]=c15, graphics_colors[15]=c16;
}

void reverse_colors() {
  if (!graphics_n_colors)
    return;
  for (int i=0, n=graphics_n_colors; i<n/2; i++) {
    color c=graphics_colors[i], d=graphics_colors[n-1-i];
    graphics_colors[i]=d, graphics_colors[n-1-i]=c;
  }
}

/* // example usage:

set_graphic(G_CHROME_BOX+G_SHADOW);
set_alpha(128);
set_color(BLUE);
set_line_w(2);
set_line_color(WHITE);
set_fade_color(DARK_BLUE);
set_shadow_color(RED);
set_shadow_depth(-4, 4);
set_shadow_alpha(96);
draw_box_x(&box);
*/

//////////////////// DRAWING /////////////////////

int do_clear_screen=1;

void set_screen_color(color c) {
  do_clear_screen=1;
  screen_color=c;
}
    
void clear_screen(color c) {
  uint i, n=screen_w*screen_h;
  color *p=(color *) screen_p;
  for (i=0; i<n; p[i++]=c);
}

// initialize screen. see SYSTEM.H > create_screen

int set_screen(int w, int h, color c) {
  if (!create_screen(w, h))
    return 0;
  set_screen_color(c);
  return 1;
}

BOX *get_screen_box() {
  BOX *p=&screen_box;
  p->x=0, p->y=0, p->w=screen_w, p->h=screen_h;
  return p;
}

void outline_screen(color c) {
  BOX box=screen_box;
  box.w-=1, box.h-=1;
  draw_outline(&box, c);
}

int visible_xy(int x, int y) {
  if (not ((x>=0 and x<screen_w) and
    (y>=0 and y<screen_h)))
    return 0;
  if (clip.w)
    if ((x>=clip.x and x<clip.x+clip.w) and
      (y>=clip.y and y<clip.y+clip.h))
      return 1;
    else
      return 0;
  return 1;
}

color get_color_at(int x, int y) {
  if (x<0 or x>=screen_w or y<0 or y>=screen_h)
    return 0;
  return *(color *) &screen_p[xy(x, y)];
}

// draw pixel. safe and versatile.
// first, if it's located outside of the
// screen boundaries or clip_box, it
// returns 0

int draw_pixel(int x, int y, color c) {
  color *p;
  if (not visible_xy(x, y))
    return 0;
  if (clip.w) {
    if (not (x>=clip.x and x<clip.x+clip.w
      and y>=clip.y and y<clip.y+clip.h))
      return 0;
  }
  p=(color *) &screen_xy(x, y);
  if (graphics_style&G_KEY and c==graphics_key)
    return 2;
  //if (graphics_style&G_ALPHA)
  //  c=mix(*p, c, graphics_alpha);
  *p=c; // draw
  return 1;
}

#define draw_pixel_fast(x, y, c) \
  screen_xy(x, y)=c

int draw_line_h(int x, int y, int w, color c) {
  int i;
  if (w<0 or y<0 or y>=screen_h
    or x>=screen_w or x+w<0)
    return 0;
  if (x<0)
    w+=x, x=0;
  if (x+w>=screen_w)
    w=screen_w-x;
  for (i=x; i<x+w; i++)
    draw_pixel(i, y, c);
  return 1;
}

int draw_line_v(int x, int y, int h, color c) {
  int i;
  if (h<0 or x<0 or x>=screen_w
    or y>=screen_h or y+h<0)
    return 0;
  if (y<0)
    h+=y, y=0;
  if (y+h>=screen_h)
    h=screen_h-y;
  for (i=y; i<y+h; i++)
    draw_pixel(x, i, c);
  return 1;
}

int draw_line(int x1, int y1, int x2, int y2,
  color c) {
  int i, x, y, px, py, dx, dy,
    sdx, sdy, dxa, dya;
  dx=x2-x1, dy=y2-y1; // distance
  dxa=abs(dx), dya=abs(dy); // deltas
  sdx=sgn(dx), sdy=sgn(dy);
  x=dya/2, y=dxa/2, px=x1, py=y1;
  draw_pixel(px, py, c);
  if (dxa>=dya) { // horizontal-ish
    if (y1==y2) {
      draw_line_h(x1, y1, x2-x1, c);
      return;
    }
    for (i=0; i<dxa; i++) {
      y+=dya;
      if (y>=dxa) {
        y-=dxa, py+=sdy;
      }
      px+=sdx;
      draw_pixel(px, py, c);
    }
    return;
  }
  if (x1==x2) { // vertical
    draw_line_v(x1, y1, y2-y1, c);
    return;
  }
  for (i=0; i<dya; i++) { // vertical-ish
    x+=dxa;
    if (x>=dya) {
      x-=dya, px+=sdx;
    }
    py+=sdy;
    draw_pixel(px, py, c);
  }
  return 1;
}

int draw_solid(BOX *box, color c) {
  int i, x, y, w, h, bt;
  if (not visible_box(box))
    return 0;
  x=box->x, y=box->y,
  w=box->w, h=box->h, bt=y+h;
  for (i=y; i<bt; i++)
    draw_line_h(x, i, w, c);
  return 1;
}

int draw_outline(BOX *box, color c) {
  int x, y, w, h, r, bt;
  if (not visible_box(box))
    return 0;
  x=box->x, y=box->y,
  w=box->w, h=box->h,
  r=x+w, bt=y+h;
  draw_line_h(x, y, w-1, c);
  draw_line_v(r-1, y, h, c);
  draw_line_h(x+1, bt-1, w-1, c);
  draw_line_v(x, y, h, c);
  return 1;
}

int draw_outline_w(BOX *box, color c, int w) {
  int i;
  BOX b=*box;
  if (!visible_box(&b))
    return 0;
  for (i=0; i<w; i++) {
    draw_outline(&b, c);
    b.x--, b.y--, b.w+=2, b.h+=2;
  }
  return 1;
}

int draw_border_w(BOX *box, color c, int w) {
  int i;
  BOX b=*box;
  if (!visible_box(&b))
    return 0;
  for (i=0; i<w; i++) {
    draw_outline(&b, c);
    b.x++, b.y++, b.w-=2, b.h-=2;
  }
  return 1;
}

int draw_outside(BOX *box, color c) {
  if (not visible_box(box))
    return 0;
  int x=box->x-1, y=box->y-1,
    w=box->w+2, h=box->h+2,
    r=x+w, bt=y+h;
  draw_line_h(x, y, w-1, c); // top
  draw_line_v(r-1, y, h, c); // right
  draw_line_h(x+1, bt-1, w-1, c); // bottom
  draw_line_v(x, y, h, c); // left
  return 1;
}

// draw box inside

int draw_inline(BOX *box, color c) {
  if (not visible_box(box))
    return 0;
  int x=box->x+1, y=box->y+1,
    w=box->w-2, h=box->h-2,
    r=x+w, bt=y+h;
  draw_line_h(x, y, w-1, c); // top
  draw_line_v(r-1, y, h, c); // right
  draw_line_h(x+1, bt-1, w-1, c); // bottom
  draw_line_v(x, y, h, c); // left
  return 1;
}

// standard draw_box with color and outline

int draw_box(BOX *box, color c, color o) {  
  BOX b=*box;
  draw_solid(&b, c);
  draw_outline(&b, o);
  return 1;
}

// draw 'x' inside box

int draw_x_box(BOX *b, color c) {
  draw_line(b->x, b->y, b->x+b->w-1, b->y+b->h-1, c);
  draw_line(b->x, b->y+b->h-1, b->x+b->w-1, b->y, c);
  return 1;
}

// draw box outline with dashes every 4 colors

void draw_box_dash(BOX *b, color c1, color c2) {
  int i, c=c1, n=4, j,
    x=b->x, y=b->y, w=b->w, h=b->h;
  j=n;
  for (i=x; i<x+w; i++) { // top
    draw_pixel(i, y, c);
    if (--n<=0) {
      n=j;
      if (c==c1) c=c2;
      else c=c1;
    }
  }
  for (i=x; i<x+w; i++) { // bottom
    draw_pixel(i, y+h, c);
    if (--n<=0) {
      n=j;
      if (c==c1) c=c2;
      else c=c1;
    }
  }
  for (i=y; i<y+h; i++) { // left
    draw_pixel(x, i, c);
    if (--n<=0) {
      n=j;
      if (c==c1) c=c2;
      else c=c1;
    }
  }
  for (i=y; i<y+h; i++) { // right
    draw_pixel(x+w, i, c);
    if (--n<=0) {
      n=j;
      if (c==c1) c=c2;
      else c=c1;
    }
  } 
}

// draw with double thickness

void draw_box_dash2(BOX *b, color c1, color c2) {
  draw_box_dash(b, c1, c2);
  BOX box=*b;
  increase_box(&box, 1);
  draw_box_dash(&box, c1, c2);
}

// draw solid circle/ellipse

int draw_circle(int x, int y, int w, int h, color c) {
  int px, py, w2=w*w, h2=h*h;
  x+=(w/2), y+=(h/2);
  if (not visible_area(x, y, w, h))
    return 0;
  for (py=-h; py<=h; py++) {
    for (px=-w; px<=w; px++) {
      if (px*px*h2+py*py*w2<=h2*w2)
        draw_pixel(x+px, y+py, c);
    }
  }
  return 1;
}

// draw circle outline

int outline_circle(int x, int y, int w, int h, color c) {
  int px, py, dx, dy, w2=w*w, h2=h*h,
    w8=w2*4, h8=h2*4;
  x+=(w/2), y+=(h/2);
  if (not visible_area(x, y, w, h))
    return 0;
  py=h, dx=2*h2+w2*(1-2*h);
  for (px=0; h2*px<=w2*py; px++) {
    draw_pixel(x+px, y+py, c);
    draw_pixel(x-px, y+py, c);
    draw_pixel(x+px, y-py, c);
    draw_pixel(x-px, y-py, c);
    if (dx>=0)
      dx+=w8*(1-py), py--;
    dx+=h2*((px*4)+6);
  }
  px=w, dy=2*w2+h2*(1-2*w);
  for (py=0; w2*py<=h2*px; py++) {
    draw_pixel(x+px, y+py, c);
    draw_pixel(x-px, y+py, c);
    draw_pixel(x+px, y-py, c);
    draw_pixel(x-px, y-py, c);
    if (dy>=0)
      dy+=h8*(1-px), px--;
    dy+=w2*((py*4)+6);
  }
  return 1;
}

/////////////////// SCANLINE /////////////////////

/* draw scanline with optional color key to
  exclude (or 0=none), alpha (0=none or 1-255)
  and type ('i'=draw image, 'r'=raster image) */

int draw_scanline(void *pixels, int x, int y,
  int w, int key, int alpha, int type) {
  int i;
  if (!clip_scanline_h(&i, &x, &y, &w))
    return 0;
  byte *p, *s=(byte *) pixels;
  p=&screen_xy(x, y);
  s+=i*4;

  if (type=='i' or !type) {
    if (!(key|alpha)) {
      memory_copy(p, s, w*4);
      return 1;
    }
    for (i=0; i<w; i++, p+=4, s+=4) {
      color c=*(color *) s;
      if (key and c==key)
        continue;
      if (alpha)
        c=mix(*(color *) p, c, alpha);
      *(color *) p=c;
    }
  }
  else if (type=='r') {
    // if pure BLACK, use 1.1.1 instead
    if (alpha==0)
      alpha=0x010101;
    for (i=0; i<w; i++, p+=4, s+=4) {
      color c=*(color *) s;
      // case BLACK: 100% invisible, most likely
      // case WHITE: 100% visible, secondary
      // case GRAY: X% visible, antialias edges
      if (c==0)
        continue; // skip
      if (c==0xFFFFFF)
        *(color *) p=alpha; // copy
      else
        *(color *) p=mix(*(color *)p,
          alpha, c&0xFF);
    }
  }
  return 1;
}

int clip_text_x=0, clip_text_y=0;

// draw raster scanline in shades of color.
// pixels are grayscale where: 0/BLACK =
// invisible. 0xFFFFFF/WHITE = 100% visible.
// otherwise, GRAY = intensity (&0xFF).
// for drawing font glyphs, textures, brushes,
// masks, images with variable alpha,
// recolored images (example: sprites with
// different colors for clothes)

int draw_scanline_r(void *pixels, int x, int y,
  int w, color c) {
  if (not visible_line_h(x, y, w))
    return 0;
  if (clip_text_y and y>=clip_text_y)
    return 0;
  int i, a=c;
  byte *p, *s=(byte *) pixels;
  p=&screen_xy(x, y);
  if (a==BLACK)
    a=0x010101;
  for (i=x; i<x+w; i++, p+=4, s+=4) {
    if (clip_text_x and i>=clip_text_x)
      return 0;
    c=*(color *) s;
    if (c==BLACK)
      continue;
    if (c==WHITE)
      c=a;
    else
      c=mix(*(color *) p, a, c&0xFF);
    draw_pixel(i, y, c);
  }
  return 1;
}

int draw_raster(void *pixels, int x, int y,
  int w, color fc, color vc, color tc) {
  int i, a=fc;
  if (not visible_line_h(x, y, w))
    return 0;
  if (clip_text_y and y>=clip_text_y)
    return 0;
  byte *p, *s=(byte *) pixels;
  p=&screen_xy(x, y);
  if (a==tc) {
    if (a==BLACK)
      a=0x010101;
    else if (a==WHITE)
      a=0xFEFEFE;
    else if (a==GREEN)
      a=0x00FE00;
  }
  for (i=x; i<x+w; i++, p+=4, s+=4) {
    if (clip_text_x and i>=clip_text_x)
      return 0;
    color c=*(color *) s;
    if (c==tc)
      continue;
    else if (c==vc)
      c=a;
    else {
      color g=grayscale_color(c)&0xFF;
      c=mix(a, *(color *) p, g);
    }
    draw_pixel(i, y, c);
  }
  return 1;
}

#define is_grayish(r, g, b, n) \
  (abs((r)-(g))<n and abs((r)-(b))<n)
#define is_greenish(r, g, b, n) \
  ((g)>(r)+(n)) and ((g)>(b)+(n))

int draw_raster_i(void *pixels, int x, int y,
  int w, color vc, color oc) {
  int i, g, b;
  if (not visible_line_h(x, y, w))
    return 0;
  color c, *p, *s=pixels;
  p=&screen_xy(x, y);
  for (i=x; i<x+w; i++, p++, s++) {
    c=*s;
    if (c==GREEN)
      continue;
    else if (c==WHITE)
      c=vc;
    else if (c==BLACK)
      c=oc;
    else {
      g=c>>8&0xFF, b=c&0xFF;
      if (g==b)
        c=mix(oc, vc, g);
      else
        c=mix(oc, *(color *) p, g);
    }
    draw_pixel(i, y, c);
  }
  return 1;
}

int draw_raster_shadow_i(void *pixels, int x, int y,
  int w, color sc) {
  int i, g, b;
  if (not visible_line_h(x, y, w))
    return 0;
  color c, *p, *s=pixels;
  p=&screen_xy(x, y);
  for (i=0; i<w; i++, p++, s++) {
    c=*s;
    if (c==GREEN)
      continue;
    else if (c==WHITE or c==BLACK)
      c=sc;
    else {
      g=c>>8&0xFF, b=c&0xFF;
      if (g<b+32) // inner outline
        c=sc;
      else // outer outline
        c=mix(sc, *(color *) p, g);
    }
    draw_pixel(i+x, y, c);
  }
  return 1;
}

///////////////////// BITMAP /////////////////////

int draw_bitmap(void *pixels, int x, int y,
  int w, int h, int key, int alpha, int type) {
  int i;
  color *p=pixels;
  if (not visible_area(x, y, w, h))
    return 0;
  for (i=y; i<h; i++, p+=w)
    draw_scanline(p, x, i, w, key,
      alpha, type);
  return 1;
}

//////////////////// GRADIENT ////////////////////

// draw gradient line. orient/ation = 'h'/'v'.
// type = fade to/from color 'a'/'b' or
// 't'/ransparent

int draw_line_g(int orient, int type, int x,
  int y, int wh, color a, color b) {
  int i, n, xi, xc=0, an=0, in;
  color *p, c;
  if (orient=='h') {
    if (!clip_line_h(&x, &y, &wh))
      return 0;
  }
  else
    if (!clip_line_v(&x, &y, &wh))
      return 0;

  if (wh<255)
    xi=0, n=(255/wh);
  else
    xi=(wh/255), n=2;
  p=&screen_xy(x, y);
  if (!orient or orient=='h')
    in=1;
  else if (orient=='v')
    in=screen_w;

  // fade to/from color a/b?
  if (type=='a' or type=='b') {
    for (i=0; i<wh; i++, p+=in) {
      if (an<255 && xc++>=xi) {
        xc=0, an+=n;
        if (type=='a')
          c=mix(a, b, an);
        else
          c=mix(b, a, an);
      }
      *p=c;
    }
  }
  // fade to/from transparent/color?
  else {
    for (i=0; i<wh; i++, p+=in) {
      if (an<255 && xc++>=xi) {
        xc=0, an+=n;
        if (type=='t')
          c=mix(*p, a, an);
        else
          c=mix(a, *p, an);
      }
      *p=c;
    }
  }
  return 1;
}

int draw_fade_d(BOX *b, int orient, color c1, color c2) {
  int i, n, c, r1, g1, b1, r2, g2, b2,
    nr, ng, nb, first, last;
  if (not visible_box(b))
    return 0;
  if (orient=='h')
    first=b->x, n=b->w;
  else
    first=b->y, n=b->h;
  last=first+n;
  r1=get_r(c1), g1=get_g(c1), b1=get_b(c1);
  r2=get_r(c2), g2=get_g(c2), b2=get_b(c2);
  r1<<=8, g1<<=8, b1<<=8;
  nr=((r2<<8)-r1)/n;
  ng=((g2<<8)-g1)/n;
  nb=((b2<<8)-b1)/n;

  for (i=first; i<last; i++) {
    c=rgb(r1>>8, g1>>8, b1>>8);
    if (orient=='h')
      draw_line_v(i, b->y, b->h, c);
    else
      draw_line_h(b->x, i, b->w, c);
    r1+=nr, g1+=ng, b1+=nb;
  }
  return 1;
}

int draw_shade_d(BOX *b, int orient, color c1, color c2) {
  BOX box;
  box=*b;
  if (not visible_box(b))
    return 0;
  if (orient=='v') {
    box.h/=2;
    draw_fade_d(&box, 'v', c1, c2);
    move_box_d(&box);
    draw_fade_d(&box, 'v', c2, c1);
  }
  else {
    box.w/=2;
    draw_fade_d(&box, 'h', c1, c2);
    move_box_r(&box);
    draw_fade_d(&box, 'h', c2, c1);    
  }
  return 1;
}

int draw_gradient(int orient, int type, int x, int y,
  int w, int h, color a, color b) {
  BOX box;
  set_box(&box, x, y, w, h);
  draw_fade_d(&box, orient, a, b);
  return 1;
}

int draw_gradient_b(int orient, int type, BOX *box,
  color a, color b) {
  draw_gradient(orient, type, box->x, box->y,
    box->w, box->h, a, b);
  return 1;
}

int draw_bevel(int x, int y, int w, int h,
  color a, color b, int state, int n) {
  int i;
  if (not visible_area(x, y, w, h))
    return 0;
  if (!n)
    n=w>>4;
  if (n>w>>2) {
    if (w>16) n=4;
    else if (w>8) n=2;
    else if (w>4) n=1;
    else n=0;
  }
/*
  if (!state)
    b=darken_color(b, 128);
  else if (state=='h')
    a=lighten_color(a, 32), b=darken_color(b, 64);
  else if (state=='c')
    a=lighten_color(a, 64), b=darken_color(b, 32);
*/
  color c;
  int z=256/n;
  if (n) {
    for (i=0, c=a; i<n; i++) // top
      draw_line_h(x+i-1, y+i-1,
        w-(i*2)+2, c=mix(c, b, z));
    for (i=0, c=a; i<n; i++) // bottom
      draw_line_h(x+i-1, y+h-i,
        w-(i*2)+2, c=mix(c, b, z));
    for (i=n, c=a; i>0; i--) // left
      draw_line_v(x+i-1, y+i-1,
        h-(i*2)+2, c=mix(c, b, z));
    for (i=n, c=a; i>0; i--) // right
      draw_line_v(x+w-i, y+i-1,
        h-(i*2)+2, c=mix(c, b, z));
  }
  draw_gradient('v', 'a', x+n-1, y+n-1,
    w-(n<<1)+2, h-(n<<1)+2, a, b);
  BOX box={ x, y, w, h };
  if (state=='h')
    draw_outline(&box, lighten_color(a, 96));
  else if (state=='c')
    draw_outline(&box, lighten_color(a, 96));
  return 1;
}

int draw_bevel_b(BOX *b, color a, color c, int state, int n) {
  draw_bevel(b->x, b->y, b->w, b->h,
    a, c, state, n);
  return 1;
}

int draw_bevel_z(BOX *b, color a, color c, color o, int n) {
  draw_bevel_b(b, a, c, 0, n);
  draw_outline(b, o);
  return 1;
}

int draw_vista(int x, int y, int w, int h, color c) {
  color lc=lighten_color(c, 16), dc=darken_color(c, 128),
    lx=lighten_color(c, 64), dx=darken_color(c, 224);
  draw_gradient('v', 'a', x+2, y+2,
    w-4, (h>>1)-2, lx, lc);
  draw_gradient('v', 'a', x+2, y+(h>>1),
    w-4, (h>>1)-1, dc, lc);
  BOX box;
  set_box(&box, x, y, w, h);
  draw_outline(&box, lx);
  return 1;
}

int draw_vista_b(BOX *box, color c) {
  color lc=lighten_color(c, 64), dc=darken_color(c, 64),
    lx=lighten_color(c, 128), dx=darken_color(c, 192);
  draw_gradient('v', 'a', box->x+2, box->y+2,
    box->w-4, (box->h>>1)-2, lx, lc);
  draw_gradient('v', 'a', box->x+2, box->y+(box->h>>1),
    box->w-4, (box->h>>1)-1, dc, lc);
  draw_outline(box, lx);
  return 1;
}

int draw_chrome2(BOX *box, color a, color c) {
  int x=box->x, y=box->y, w=box->w, h=box->h;
  draw_gradient('v', 'a', x+2, y+2,
    w-4, (h>>1)-2, a, c);
  draw_gradient('v', 'a', x+2, y+(h>>1),
    w-4, (h>>1)-1, a, c);
  return 1;
}

int draw_chrome(BOX *box, color a, color c, color o) {
  draw_chrome2(box, a, c);
  draw_outline(box, o);
  return 1;
}

int draw_shade_depth(BOX *bo, color a,
  color b, color o, uint n) {
  if (!visible_box(bo))
    return 0;
  BOX box=*bo;
  box.h=n;
  draw_fade(&box, a, b);
  box.y=bo->y+bo->h-n;
  draw_fade(&box, b, a);
  box=*bo, box.y+=n-1, box.h-=(n*2)-2;
  draw_solid(&box, b);
  draw_outline(bo, o);  
  return 1;
}

// draw box with X inside

void draw_box_none(BOX *box, color a, color b) {
  draw_box(box, a, b);
  draw_line(box->x, box->y, box->x+box->w-1, box->y+box->h-1, b);
  draw_line(box->x, box->y+box->h-1, box->x+box->w-1, box->y, b);
}

//////////////////// CLIPPING ////////////////////

// is visible?

int visible_line_h(int x, int y, int w) {
  if (x+w<0 or x>=screen_w or y<0
    or y>=screen_h)
    return 0;
  return 1;
}

int visible_line_v(int x, int y, int h) {
  if (x<0 or x>=screen_w or y+h<0
    or y>=screen_h)
    return 0;
  return 1;
}

// adjust location/size of line/scanline
// within screen before drawing

int clip_line_h(int *x, int *y, int *w) {
  if (*x>=screen_w or *y>=screen_h
    or *x+*w<0 or *y<0 or *w<0)
    return 0;
  if (*x<0)
    *w+=*x, *x=0;
  if (*x+*w>=screen_w)
    *w=screen_w-*x;
  return 1;
}

int clip_line_v(int *x, int *y, int *h) {
  if (*x>=screen_w or *y>=screen_h
    or *y+*h<0 or *x<0 or *h<0)
    return 0;
  if (*y<0)
    *h+=*y, *y=0;
  if (*y+*h>=screen_h)
    *h=screen_h-*y;
  return 1;
}

int clip_scanline_h(int *i, int *x, int *y, int *w) {
  *i=0;
  if (*x>=screen_w or *y>=screen_h
    or *x+*w<0 or *y<0 or *w<0)
    return 0;
  if (*x<0)
    *i=-*x, *w+=*x, *x=0;
  if (*x+*w>=screen_w)
    *w=screen_w-*x;
  return 1;
}

int draw_rainbow(BOX *box) {
  int i, n, j, x=box->x, y=box->y,
    w=box->w, h=box->h, s,
    r1, g1, b1, r2, g2, b2, nr, ng, nb,
    n_colors=graphics_n_colors, n_fades=n_colors/2;
  color a, b, c1;
  int orient=graphics_style&G_ORIENT;
  if (orient)
    s=w;
  else
    s=h;
  n=(s/n_fades);
  if (!n)
    n=2;
  for (i=0; i<n_colors and i<h; i+=2) {
    a=graphics_colors[i], b=graphics_colors[i+1];
    r1=get_r(a), g1=get_g(a), b1=get_b(a);
    r2=get_r(b), g2=get_g(b), b2=get_b(b);
    r1<<=8, g1<<=8, b1<<=8, nr=((r2<<8)-r1)/n;
    ng=((g2<<8)-g1)/n, nb=((b2<<8)-b1)/n;
    for (j=0, c1=a; j<n; j++) {
      if (orient)
        draw_line_v(x++, y, h, c1);
      else
        draw_line_h(x, y++, w, c1);
      c1=rgb(r1>>8, g1>>8, b1>>8);
      r1+=nr, g1+=ng, b1+=nb;
    }
  }
  return 1;
}

// draw hue color selection. box.w/h size must be 256/256

int draw_hue_light(BOX *box) {
  int i, n, j, k, l, x=box->x, y=box->y,
    w=box->w, h=box->h,
    r1, g1, b1, r2, g2, b2, nr, ng, nb,
    n_colors=graphics_n_colors, n_fades=n_colors/2;
  color a, b, c, c1;
  n=(w/n_fades);
  if (!n)
    n=2;
  for (i=0; i<n_colors; i+=2) {
    a=graphics_colors[i], b=graphics_colors[i+1];
    r1=get_r(a), g1=get_g(a), b1=get_b(a);
    r2=get_r(b), g2=get_g(b), b2=get_b(b);
    r1<<=8, g1<<=8, b1<<=8, nr=((r2<<8)-r1)/n;
    ng=((g2<<8)-g1)/n, nb=((b2<<8)-b1)/n;
    for (j=0, c1=a; j<n; j++) {
      // draw_line_v(x++, y, h, c1);
      if (!clip_line_v(&x, &y, &h))
        continue;
      c=c1;
      for (k=y; k<y+h; k++) {
        draw_pixel(x, k, c);
        l=k-y;
        if (l<(h/2))
          c=mix(BLACK, c1, l*2);
        else
          c=mix(c1, WHITE, l*2);
      }
      x++;
      c1=rgb(r1>>8, g1>>8, b1>>8);
      r1+=nr, g1+=ng, b1+=nb;
    }
  }
  return 1;
}

int gray_to_color=0; // or color to gray

void draw_hue_gray(BOX *box, color c) {
  int x, y, w=box->w, h=box->h, hd2=h/2;
  color ic=c;
  for (y=0; y<h; y++) {
    for (x=0; x<w; x++) {      
      if (y<hd2)
        c=mix(BLACK, ic, (y*2));
      else
        c=mix(ic, WHITE, (y-hd2)*2);
      if (gray_to_color)
        c=mix(GRAY, c, x);
      else
        c=mix(c, GRAY, x);
      if (y<hd2)
        c=mix(BLACK, c, (y*2));
      else
        c=mix(c, WHITE, (y-hd2)*2);
      draw_pixel(box->x+x, box->y+y, c);
    }
  }
}

void draw_fade_x(BOX *box) {
  draw_fade_d(box, 'v', graphics_fade_color, graphics_color);
  draw_outline(box, graphics_line_color);
}

void draw_shade_x(BOX *box) {
  draw_shade_d(box, 'v', graphics_fade_color, graphics_color);
  draw_outline(box, graphics_line_color);
}

void draw_box_x(BOX *box) {
  uint i, style=graphics_style, lw=graphics_line_w;
  color c=graphics_color, fc=graphics_fade_color,
    lc=graphics_line_color;
  if (style&G_RAINBOW)
    draw_rainbow(box);
  else if (style&G_CHROME)
    draw_chrome2(box, fc, c);  
  else if (style&G_SHADE)
    draw_shade_d(box, 'v', fc, c);
  else if (style&G_FADE)
    draw_fade_d(box, 'v', fc, c);
  else if (style&G_FADE and style&G_CHROME)
    draw_vista_b(box, c);
  else if (style&G_SOLID)
    draw_solid(box, c);
  if (style&G_OUTLINE) { // outline
    if (lw==1 or !lw)
      draw_outline(box, lc);
    else {
      BOX b=*box;
      for (i=0; i<lw; i++) { // line width
        draw_outline(&b, lc);
        b.x++, b.y++, b.w-=2, b.h-=2;
      }
    }
  }
}

// draw meter/gauge with shade and double outline.
// for controls, statistics, life/power/etc in games.
// fc=fade color, c=main color, oc=outline color.
// n=current value, max/imum

int custom_meter_style=NO;

void draw_meter(BOX *box, color fc, color c,
  color oc, int n, int max) {
  BOX b=*box;
  draw_outline(&b, oc);
  decrease_box(&b, 1);
  draw_outline(&b, oc);
  decrease_box(&b, 1);
  if (n)
    b.w=(b.w/((double)max/n));
  else
    b.w=1;
  if (custom_meter_style)
    draw_box_x(&b);
  else
    draw_shade_d(&b, 'v', fc, c);
  draw_outline(&b, c);
}

////////////////////// NEW ///////////////////////

// gradient functions. fade=a-b, shade=a-b-a,
// chrome=a-b-a-b. direction is 'v'ertical. draws horizontal
// lines downwards from box.y to box.y+box.h.
// draw_shade_d+chrome reuse draw_fade_d. o=outline

int draw_fade(BOX *box, color a, color b, color o);
int draw_shade(BOX *box, color a, color b, color o);

int draw_fade(BOX *box, color a, color b, color o) {
  draw_fade_d(box, graphics_direction, a, b);
  draw_outline(box, o);
  return 1;
}

int draw_shade(BOX *box, color a, color b, color o) {
  BOX bo=*box;
  if (not visible_box(box))
    return 0;
  int d=graphics_direction;
  if (!d or d=='v') {
    bo.h/=2;
    draw_fade_d(&bo, 'v', a, b);
    move_box_d(&bo);
    draw_fade_d(&bo, 'v', b, a);
  }
  else if (d=='h') {
    bo.w/=2;
    draw_fade_d(&bo, 'h', a, b);
    move_box_r(&bo);
    draw_fade_d(&bo, 'h', b, a);    
  }
  draw_outline(box, o);
  return 1;
}

// fade to/from color and t/ransparent
// ct: from color to transparent. tc: from transparent to color

int draw_fade_ct(BOX *box, color c);
int draw_fade_tc(BOX *box, color c);
int draw_shade_ct(BOX *box, color c);
int draw_shade_tc(BOX *box, color c);
int draw_chrome_ct(BOX *box, color c);
int draw_chrome_tc(BOX *box, color c);

/* SCREEN, BRUSH, CANVAS

#define vga screen.p // current screen

object {
  int type, mode,
    x, y, w, h, n_colors;
  color c;
  void *p, *palette;
} SCREEN;

SCREEN screen, backup_screen;

SCREEN *get_screen() { return screen; }
void set_screen(SCREEN *s) { screen=*s; }
void backup_screen(SCREEN *s) { backup_screen=*s; }
void restore_screen() { screen=backup_screen; }
void draw2(SCREEN *s) { backup_screen=screen, screen=*s; }
void end_draw2() { screen=backup_screen; }

int create_screen(SCREEN *screen, int w, int w, int type, int mode);
int resize_screen(int w, int h);
int convert_screen(SCREEN *a, SCREEN *b, int type);

int get_screen_w(), get_screen_h(), get_screen_type(), get_screen_mode();
color get_screen_color(), get_color_at(int x, int y);
void set_screen_size(int w, int h), set_screen_type(int type),
void set_screen_mode(int mode), set_screen_color(color c);

// CANVAS; a SCREEN with FONT, BRUSH, STYLE,
// binary/alpha mask (1-4BPP), and "display size"
// dw/dh to draw at another size for zoom/preview,
// but doesn't resize image/screen pixels

object {
  int type, mode, x, y, w, h,
    dw, dh, n_colors;
  color c;
  void *p, *palette, *mask;
  FONT font;
  BRUSH brush;
  STYLE style;
} CANVAS;

// mask can be a 1BPP monochrome mask (1/0, visible
// or not), or a 4BPP alpha mask (0=invisible,
// 15/1111b=opaque). 16 intensities of alpha is
// more than enough

// create common colors table, and arrange by frequency

object {
  uint n;
  color value;
} COMMON_COLOR_ENTRY;

object {
  uint n_colors;
  COMMON_COLOR_ENTRY *colors;
} COMMON_COLOR_TABLE;

COMMON_COLOR_TABLE *create_common_colors(int n);

*/

/*
Design buttons visually.
 ____________________________________________________
|[]_Button_Creator_____________________________[-][X]|
|____________________________________________________|
| Text:    ___Example___
| Font:    [[O] Color] [[F] roman_lb] [i][b]
| Shadow:  [[O] Color] [[O] Fade] Depth: [-4][4]
|
| Colors:  [[O] Color][[X] None][[X] None][[X] None]
| Style:   [[.] Fade ] Direction: [[|] Vertical ]
|[Preview] [[O] Solid][[X] None][Fade_V][Fade_H]
|[       ] [Shade_V][Shade_H][Chrome_V][Chrome_H]
| Preset:  [[ ] None] ([[@] Rainbow])
| Texture: [[ ] None]
| Alpha:   [[O] Opaque] [100%]
|          (0/15/25/40/50/60/75/85/100)
|          [[25] Alpha] (Drop down menu buttons)
| Outline: [[O] Color] Size: [1 ]
| Style:   [[-] Solid]
| Edge:    [[>] Sharp] [[R] Round]
| Shadow:  [[O] Color] [[O] Fade] Depth: [-4][4]
|
| Icon:    __file__ Size: [32] [X] Key
| Outline: [[O] Color] Size: [1 ]
__________________________________________________

[[O] Example ]
__________________________________________________
*/

/*

// SPECIFIC STYLE objects

object {
  byte style, line, shadow, inset;
  color c, c2, c3, c4, line_c, shadow_c;
} BOX_STYLE;

object {
  byte style, line, shadow, inset;
  color line_c, shadow_c;
} IMAGE_STYLE;

object {
  byte style;
  BOX_STYLE box_style;
  IMAGE_STYLE image_style;
} ICON_STYLE;

object {
  byte style;
  color c, c2, shadow_c;
  FONT font;
} TEXT_STYLE;

object {
  byte style;
  BOX_STYLE box_style;
  TEXT_STYLE text_style;
} LABEL_STYLE;

object {
  byte style;
  BOX_STYLE box_style;
  LABEL_STYLE label_style;
  ICON_STYLE icon_style;
  IMAGE texture;
} BUTTON_STYLE;

BYTE_STYLE: ST.NC.IV.RO. A generic style byte for boxes,
images, buttons. If all 0s, defaults will be used.
Example: solid 1 color.

* ST: STYLE: 0-3 = NONE, SOLID, FADE, CHROME
* NC: COLORS: 0-3 = 1-4
* IV: INVERT: 0-3 = NONE, X, Y, BOTH
* RO: ROTATE: 0-3 = NONE, LEFT, RIGHT, 2

BYTE_LINE: LS.SIZE.O.X

* LS: STYLE: 0-3 = NONE, SOLID, DASHES, LINES
* SIZE: 1-8, 0=NONE. CURVE: 9=LEAST, 10=LESSER,
11=LESS, 12=AVERAGE, 13=MORE, 14=MOST. 15=circle
* O: 0=INNER "BORDER", 1=OUTTER "OUTLINE"

* BYTE_SHADOW: SS.XXX.YYY. STYLE: 0-3 = NONE, SOLID,
  FADE1, FADE2. X/Y: 0-7 = -8/-4/-2/0/2/4/8
* BYTE_INSET: XXX.YYY.0000

enum { STYLE_NONE, STYLE_SOLID, STYLE_FADE, STYLE_CHROME };
enum { STYLE_C1, STYLE_C2, STYLE_C3, STYLE_C4 };
enum { STYLE_INVERT_NONE, STYLE_INVERT_X, STYLE_INVERT_Y,
  STYLE_INVERT_BOTH };
enum { STYLE_ROTATE_NONE, STYLE_ROTATE_L, STYLE_ROTATE_R,
  STYLE_ROTATE_2 };
enum { STYLE_CURVE_1=9, STYLE_CURVE_2, STYLE_CURVE_3,
  STYLE_CURVE_4, STYLE_CURVE_5, STYLE_CURVE_6 };
*/