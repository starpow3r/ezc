/* EZC LIBRARY. BY STARPOWER/MYSTERI/OUS.
    __  ___         __          _
  /  |/  /_ _____ / /____ ____(_)
 / /|_/ / // (_-<  __/ -_) __/ /
/_/  /_/\_, /___/\__/\__/_/ /_/
       /___/ (C) 2016+, KID-7/77 */

//////////////////// COLOR ///////////////////////

// standard colors

enum {
  BLACK=0, WHITE=0xFFFFFF, RED=0xFF0000,
  GREEN=0xFF00, BLUE=0xFF, CYAN=GREEN|BLUE,
  MAGENTA=RED|BLUE, YELLOW=RED|GREEN,
  GRAY=0x7F7F7F, GRAY25=0xC0C0C0,
  GRAY50=0x808080, GRAY75=0x404040
};

/* personally selected "cool colors" for
  interfaces. includes nature colors for
  custom textures and brushes; water,
  grass, dirt, etc */

enum {
  LIGHTER_RED=0xFF8080, LIGHT_RED=0xFF4747,
  FIRE_RED=0xFF2323, MEDIUM_RED=0xD7002F,
  CHERRY_RED=0xAA1120, RED_ROSE=0x87001F,
  ROSE_RED=RED_ROSE, DARK_RED=0x470707,
  DARKER_RED=0x280404,
  DARKEST_RED=0x170202, LIGHTEST_BLUE=0xE3F1FF,
  LIGHTER_BLUE=0xB7DEFF, BABY_BLUE=0x87CFFB,
  SKY_BLUE=0x11A3F5, BEACH_BLUE=0x0362C1,
  NICE_BLUE=0x1107A0, ROYAL_BLUE=0x1122A0,
  DARK_BLUE=0x100357, DARKER_BLUE=0x070030,
  DARKEST_BLUE=0x030017, LIGHTEST_CYAN=0xE0FFFF,
  LIGHTERS_CYAN=0xB0FFFF, LIGHTER_CYAN=0x7DFFFA,
  AQUA=0x11EEFF, LIGHT_CYAN=0x2FF7FF,
  LIGHT_TURQUOISE=0x07DBFF,
  TURQUOISE=0x00A3C7, DARKER_AQUA=0x00677C,
  DARKERS_AQUA=0x004048,
  DARKEST_TURQUOISE=0x00253A,
  LIGHTEST_GREEN=0xE7FFE7, LIGHTERS_GREEN=0xCCFFCC,
  LIGHTER_GREEN=0xAAFFAA, LIGHT_GREEN=0x77FF77,
  NICE_GREEN=0x07FF0C, REAL_GREEN=0x05CC00,
  MEDIUM_GREEN=0x05A000, ROYAL_GREEN=0x037014,
  DARK_GREEN=0x1C3E14, GRASS_GREEN=0x507B11,
  DARK_GRASS=0x305B07, LIME_GREEN=0x9CF007,
  LEAF_GREEN=0x7EBB1D, EMERALD_GREEN=0x025007,
  SPEARMINT=0x85FFB0, SEA_GREEN=0x72CC90,
  LILAC=0xE1ABFF, PURPLE=0x7309CC,
  VIOLET=0x700E7F, DARK_VIOLET=0x550B5F,
  PINK=0x0FF67A0, PASTEL_PINK=0xF7A7CF,
  ROSE_PINK=0xFB57A0, HOT_PINK=0xF200A7,
  DARK_PINK=0x70004E, FUSHIA=0x8C005A,
  PINK_FLESH=0xFFCCCC, FLESH2=0xFFA7A7,
  FLESH=0xFCEEDE, PALE_FLESH=0xFFF2B3,
  SAND_FLESH=0xFBD7BD, LIGHTEST_BROWN=0xEF9F5D,
  TAN=0xD1A877, LIGHTER_BROWN=0xD77500,
  SAND=0xF4E4CE, BEIGE=0xE1D8CB,
  BROWN=0xA76000, LIGHT_BROWN=0xBB6000, 
  DARK_BROWN=0x4D2207, ORANGE_BROWN=0xB04700,
  RED_BROWN=0x782712, GOLD=0xFFDB27,
  DARK_GOLD=0xCCAA00, DARKER_GOLD=0xAA8800,
  DARKEST_GOLD=0x4C3F00, LIGHT_YELLOW=0xFFFF20,
  SUN_YELLOW=0xFFD713, LIGHT_ORANGE=0xFFCA07,
  ORANGE=0xFF7F00, COOL_GRAY=0x837B9B,
  LILAC_GRAY=0xE7D5F3, METAL_GRAY=0xAEBECE,
  LIGHT_GRAY=0xE7E7E7, MEDIUM_GRAY=0xA0A0A0,
  DARK_GRAY=0x404040, WINDOW_C=0xE1E0E7,
  WINDOW_C2=0xC1C0C7
};

// color name structures

object {
  color c;
  char name[28];
} COLOR_NAME;

COLOR_NAME standard_colors[]= {
  { BLACK, "Black" },
  { 0x101010, "Darkest Gray" },
  { 0x202020, "Darkers Gray" },
  { 0x404040, "Darker Gray" },
  { 0x606060, "Dark Gray" },
  { 0x808080, "Gray" },
  { 0xA0A0A0, "Light Gray" },
  { 0xC0C0C0, "Lighter Gray" },
  { 0xD0D0D0, "Lighters Gray" },
  { 0xE0E0E0, "Lightest Gray" },
  { 0xF0F0F0, "White Gray" },
  { WHITE, "White" },
  { BLACK, "Black" },
  { RED, "Red" },
  { GREEN, "Green" },
  { BLUE, "Blue" },
  { CYAN, "Cyan" },
  { MAGENTA, "Magenta" },
  { YELLOW, "Yellow" }
};

uint n_standard_colors=
  sizeof(standard_colors)/sizeof(COLOR_NAME);

COLOR_NAME cool_colors[]= {
  { LIGHTER_RED, "Lighter Red" },
  { LIGHT_RED, "Light Red" },
  { FIRE_RED, "Fire Red" },
  { MEDIUM_RED, "Medium Red" },
  { CHERRY_RED, "Cherry Red" },
  { RED_ROSE, "Red Rose" },
  { DARK_RED, "Dark Red" },
  { DARKER_RED, "Darker Red" },
  { LIGHTEST_BLUE, "Lightest Blue" },
  { LIGHTER_BLUE, "Lighter Blue" },
  { BABY_BLUE, "Baby Blue" },
  { SKY_BLUE, "Sky Blue" },
  { BEACH_BLUE, "Beach Blue" },
  { NICE_BLUE, "Nice Blue" },
  { ROYAL_BLUE, "Royal Blue" },
  { DARK_BLUE, "Dark Blue" },
  { DARKER_BLUE, "Darker Blue" },
  { LIGHTEST_CYAN, "Lightest Cyan" },
  { LIGHTERS_CYAN, "Lighter Cyan" },
  { LIGHTER_CYAN, "Light Cyan" },
  { AQUA, "Light Aqua" },
  { LIGHT_TURQUOISE, "Aqua" },
  { TURQUOISE, "Dark Aqua" },
  { DARKER_AQUA, "Darker Aqua" },
  { LIGHTERS_GREEN, "Lighters Green" },
  { LIGHTER_GREEN, "Lighter Green" },
  { LIGHT_GREEN, "Light Green" },
  { NICE_GREEN, "Nice Green" },
  { LIME_GREEN, "Lime Green" },
  { REAL_GREEN, "Real Green" },
  { 0x9FB700, "Leaf Green 1" },
  { LEAF_GREEN, "Leaf Green 2" },
  { GRASS_GREEN, "Grass Green" },
  { ROYAL_GREEN, "Royal Green" },
  { EMERALD_GREEN, "Emerald Green" },
  { DARK_GREEN, "Dark Green" },
  { LILAC, "Lilac" },
  { 0xD48CFB, "Lavender" },
  { 0xB73BF9, "Light Violet" },
  { 0x973BFA, "Light Purple" },
  { PURPLE, "Purple" },
  { VIOLET, "Violet" },
  { DARK_VIOLET, "Dark Violet" },
  { PASTEL_PINK, "Pastel Pink" },
  { PINK, "Pink" },
  { 0xFF57C0, "Pink Gum" },
  { ROSE_PINK, "Rose Pink" },
  { HOT_PINK, "Hot Pink" },
  { 0xBD0082, "Fuschia" },
  { DARK_PINK, "Dark Pink" },
  { FLESH, "Pale Flesh" },
  { SAND, "Sand" },
  { SAND_FLESH, "Sand Flesh" },
  { PINK_FLESH, "Flesh 1" },
  { FLESH2, "Flesh 2" },
  { 0xD38A8A, "Flesh 3" },
  { TAN, "Tan" },
  { LIGHTEST_BROWN, "Lightest Brown" },
  { LIGHTER_BROWN, "Lighter Brown" },
  { ORANGE, "Orange" },
  { LIGHT_BROWN, "Light Brown" },
  { 0xFF4300, "Orange Red" },
  { BROWN, "Brown" },
  { ORANGE_BROWN, "Orange Brown" },
  { RED_BROWN, "Red Brown" },
  { DARK_BROWN, "Dark Brown" },
  { 0xFFFF77, "Lighter Yellow" },
  { LIGHT_YELLOW, "Light Yellow" },
  { GOLD, "Gold" },
  { SUN_YELLOW, "Sun Yellow" },
  { LIGHT_ORANGE, "Light Orange" },
  { DARK_GOLD, "Dark Gold" },
  { DARKER_GOLD, "Darker Gold" },
  { DARKEST_GOLD, "Darkest Gold" },
  { 0xF7F7FF, "Lightest Metal" },
  { 0xF3F7FF, "Lighter Metal" },
  { 0xF0F3FF, "Light Metal" },
  { LIGHT_GRAY, "Light Gray" },
  { WINDOW_C, "Window Color" },  
  { LILAC_GRAY, "Lilac Gray" },
  { BEIGE, "Beige" },
  { WINDOW_C2, "Window Color 2" },
  { METAL_GRAY, "Metal Gray" },
  { COOL_GRAY, "Cool Gray" }
};

uint n_cool_colors=sizeof(cool_colors)/sizeof(COLOR_NAME);

color get_standard_color(int i) {
  if (i>=0 and i<n_standard_colors)
    return standard_colors[i].c;
  return 0;
}

color get_cool_color(int i) {
  if (i>=0 and i<n_cool_colors)
    return cool_colors[i].c;
  return 0;
}

color random_color() {
  if (random(5)==1)
    return get_standard_color(random(n_standard_colors));
  return get_cool_color(random(n_cool_colors));
}

///////////////////// RGB ////////////////////////

object { byte a, r, g, b; } RGB;

color rgb(byte r, byte g, byte b) {
  return r<<16|g<<8|b;
}

#define _rgb3(r, g, b)   ((((r)&1)<<2)|(((g)&1)<<1)|((b)&1))
#define _rgb6(r, g, b)   ((((r)&3)<<4)|(((g)&3)<<2)|((b)&3))
#define _rgb8rb(r, g, b) ((((r)&7)<<5)|(((g)&3)<<3)|((b)&7))
#define _rgb8gb(r, g, b) ((((r)&3)<<6)|(((g)&7)<<3)|((b)&7))
#define _rgb8rg(r, g, b) ((((r)&7)<<5)|(((g)&7)<<2)|((b)&3))
#define _rgb9(r, g, b)   ((((r)&7)<<6)|(((g)&7)<<3)|((b)&7))
#define _rgb12(r, g, b)  ((((r)&0xF)<<8)|(((g)&0xF)<<4)|((b)&0xF))
#define _rgb15(r, g, b)  ((((r)&0x1F)<<10)|(((g)&0x1F)<<5)|((b)&0x1F))
#define _rgb16(r, g, b)  ((((r)&0x1F)<<11)|(((g)&0x3F)<<5)|((b)&0x1F))
#define _rgb18(r, g, b)  ((((r)&0x3F)<<12)|(((g)&0x3F)<<6)|((b)&0x3F))
#define _rgb21(r, g, b)  ((((r)&0x7F)<<14)|(((g)&0x7F)<<7)|((b)&0x7F))
#define _rgb24(r, g, b)  ((((r)&0xFF)<<16)|(((g)&0xFF)<<8)|((b)&0xFF))

#define _argb12(a, r, g, b) \
  ((((a)&0xF)<<12)|(((r)&0xF)<<8)|(((g)&0xF)<<4)|((b)&0xF))
#define _argb32(a, r, g, b) \
  ((((a)&0xFF)<<24)|(((r)&0xFF)<<16)|(((g)&0xFF)<<8)|((b)&0xFF))

color rgb3(byte r, byte g, byte b)   { return _rgb3(r, g, b); }
color rgb6(byte r, byte g, byte b)   { return _rgb6(r, g, b); }
color rgb8rb(byte r, byte g, byte b) { return _rgb8rb(r, g, b); }
color rgb8gb(byte r, byte g, byte b) { return _rgb8gb(r, g, b); }
color rgb8rg(byte r, byte g, byte b) { return _rgb8rg(r, g, b); }
color rgb9(byte r, byte g, byte b)   { return _rgb9(r, g, b); }
color rgb12(byte r, byte g, byte b)  { return _rgb12(r, g, b); }
color rgb15(byte r, byte g, byte b)  { return _rgb15(r, g, b); }
color rgb16(byte r, byte g, byte b)  { return _rgb16(r, g, b); }
color rgb18(byte r, byte g, byte b)  { return _rgb18(r, g, b); }
color rgb21(byte r, byte g, byte b)  { return _rgb21(r, g, b); }
color rgb24(byte r, byte g, byte b)  { return _rgb24(r, g, b); }

color argb12(byte a, byte r, byte g, byte b)
  { return _argb12(a, r, g, b); }
color argb32(byte a, byte r, byte g, byte b)
  { return _argb32(a, r, g, b); }

color (*rgbp[])(byte r, byte g, byte b)={
  rgb24, rgb3, rgb6, rgb8rb, rgb8gb, rgb8rg, rgb9,
  rgb12, rgb15, rgb16, rgb18, rgb21, rgb24 };

enum { RGB_0, RGB_3, RGB_6, RGB_8RB, RGB_8GB, RGB_8RG,
  RGB_9, RGB_12, RGB_15, RGB_16, RGB_18, RGB_21,
  RGB_24 };

/////////////////// CONVERT //////////////////////

// convert color RGBx to RGB24:
// RRRRRRRR.GGGGGGGG.BBBBBBBB

// rgb_3: 5.1.1.1:  00000R.G.B
// rgb_6: 2.2.2.2:  00RR.GG.BB
// rgb_8rb: 3.2.3:  RRR.GG.BBB
// rgb_8gb: 2.3.3:  RR.GGG.BBB
// rgb_8rg: 3.3.2:  RRR.GGG.BB
// rgb_9: 7.3.3.3:  0000000RRR.GGG.BBB
// rgb_12: 4.4.4.4: 0000RRRR.GGGG.BBBB
// rgb_15: 1.5.5.5: 0RRRRR.GGGGG.BBBBB
// rgb_16: 5.6.5:   RRRRR.GGGGGG.BBBBB
// rgb_18: 6.6.6:   00000000000000RRRRRR.GGGGGG.BBBBBB
// rgb_21: 7.7.7:   00000000000RRRRRRR.GGGGGGG.BBBBBBB
// rgb_24: 8.8.8:   00000000RRRRRRRR.GGGGGGGG.BBBBBBBB

#define _rgb_3(c) \
  rgb((((c>>2)&1)*255), (((c>>1)&1)*255), ((c&1)*255))
#define _rgb_6(c) \
  rgb((((c>>4)&3)*85), (((c>>2)&3)*85), ((c&3)*85))
#define _rgb_8rb(c) \
  rgb((((c>>5)&7)*36), (((c>>3)&3)*85), ((c&7)*36))
#define _rgb_8gb(c) \
  rgb((((c>>6)&3)*85), (((c>>3)&7)*36), ((c&7)*36))
#define _rgb_8rg(c) \
  rgb((((c>>5)&7)*36), (((c>>2)&7)*36), ((c&3)*85))
#define _rgb_9(c) \
  rgb((((c>>6)&7)*36), (((c>>3)&7)*36), ((c&7)*36))
#define _rgb_12(c) \
  rgb((((c>>8)&15)*15), (((c>>4)&15)*15), ((c&15)*15))
#define _rgb_15(c) \
  rgb((((c>>10)&0x1F)*8), (((c>>5)&0x1F)*8), ((c&0x1F)*8))
#define _rgb_16(c) \
  rgb((((c>>11)&0x1F)*8), (((c>>5)&0x3F)*4), ((c&0x1F)*8))
#define _rgb_18(c) \
  rgb((((c>>12)&0x3F)*4), (((c>>6)&0x3F)*4), ((c&0x3F)*4))
#define _rgb_21(c) \
  rgb((((c>>14)&0x7F)*2), (((c>>7)&0x7F)*2), ((c&0x7F)*2))
#define _rgb_24(c) c

color rgb_3(color c)   { return _rgb_3(c); }
color rgb_6(color c)   { return _rgb_6(c); }
color rgb_8rb(color c) { return _rgb_8rb(c); }
color rgb_8gb(color c) { return _rgb_8gb(c); }
color rgb_8rg(color c) { return _rgb_8rg(c); }
color rgb_9(color c)   { return _rgb_9(c); }
color rgb_12(color c)  { return _rgb_12(c); }
color rgb_15(color c)  { return _rgb_15(c); }
color rgb_16(color c)  { return _rgb_16(c); }
color rgb_18(color c)  { return _rgb_18(c); }
color rgb_21(color c)  { return _rgb_21(c); }
color rgb_24(color c)  { return _rgb_24(c); }

color (*rgb_p[])(color c)={
  rgb_24, rgb_3, rgb_6, rgb_8rb, rgb_8gb, rgb_8rg, rgb_9,
  rgb_12, rgb_15, rgb_16, rgb_18, rgb_21, rgb_24 };

// convert color from RGB24/32 to RGB 3/6/8/9/12/15/16/18/21

#define _rgb__6(c) \
  rgb6(((c>>16)&0xFF)/85, ((c>>8)&0xFF)/85, (c&0xFF)/85)
#define _rgb__8rb(c) \
  rgb8rb(((c>>16)&0xFF)/36, ((c>>8)&0xFF)/85, (c&0xFF)/36)
#define _rgb__8gb(c) \
  rgb8gb(((c>>16)&0xFF)/85, ((c>>8)&0xFF)/36, (c&0xFF)/36)
#define _rgb__8rg(c) \
  rgb8rg(((c>>16)&0xFF)/36, ((c>>8)&0xFF)/36, (c&0xFF)/85)
#define _rgb__9(c) \
  rgb9(((c>>16)&0xFF)/32, ((c>>8)&0xFF)/32, (c&0xFF)/32)
#define _rgb__12(c) \
  rgb12(((c>>16)&0xFF)/16, ((c>>8)&0xFF)/16, (c&0xFF)/16)
#define _rgb__15(c) \
  rgb15(((c>>16)&0xFF)/8, ((c>>8)&0xFF)/8, (c&0xFF)/8)
#define _rgb__16(c) \
  rgb16(((c>>16)&0xFF)/8, ((c>>8)&0xFF)/4, (c&0xFF)/8)
#define _rgb__18(c) \
  rgb18(((c>>16)&0xFF)/4, ((c>>8)&0xFF)/4, (c&0xFF)/4)
#define _rgb__21(c) \
  rgb21(((c>>16)&0xFF)/2, ((c>>8)&0xFF)/2, (c&0xFF)/2)
#define _rgb__24(c) c

#define _argb__12(c) \
  argb12(((c>>24)&0xFF)/16, ((c>>16)&0xFF)/16, \
    ((c>>8)&0xFF)/16, (c&0xFF)/16)
  
color rgb__3(color c) {
  uint r=(c>>16)&0xFF, g=(c>>8)&0xFF, b=c&0xFF;
  color z=0;
  if (r>127) z|=(1<<2);
  if (g>127) z|=(1<<1);
  if (b>127) z|=1;
  return c;
}

color rgb__6(color c)   { return _rgb__6(c); }
color rgb__8rb(color c) { return _rgb__8rb(c); }
color rgb__8gb(color c) { return _rgb__8gb(c); }
color rgb__8rg(color c) { return _rgb__8rg(c); }
color rgb__9(color c)   { return _rgb__9(c); }
color rgb__12(color c)  { return _rgb__12(c); }
color rgb__15(color c)  { return _rgb__15(c); }
color rgb__16(color c)  { return _rgb__16(c); }
color rgb__18(color c)  { return _rgb__18(c); }
color rgb__21(color c)  { return _rgb__21(c); }
color rgb__24(color c)  { return _rgb__24(c); }
color argb__12(color c)  { return _argb__12(c); }

color (*rgb__p[])(color c)={
  rgb__24, rgb__3, rgb__6, rgb__8rb, rgb__8gb,
  rgb__8rg, rgb__9, rgb__12, rgb__15, rgb__16,
  rgb__18, rgb__21, rgb__24 };

///////////////////// CLIP ///////////////////////

// clip RGB components. if n<0, n=0.
// if n>maximum, n=maximum

void clip_color(int *r, int *g, int *b) {
  if (*r<0) *r=0;
  if (*g<0) *g=0;
  if (*b<0) *b=0;
  if (*r>255) *r=255;
  if (*g>255) *g=255;
  if (*b>255) *b=255;
}

// add/sub/mul/div r/g/b components with clipping.
// n is positive

#define add_c(c, n) if (c+n<255) c+=n; else c=255
#define sub_c(c, n) if (c-n>0) c-=n; else c=0
#define mul_c(c, n) if (c*n<255) c*=n; else c=255
#define div_c(c, n) if (c/n>0) c/=n; else c=0

color add_r(int r, byte n) { add_c(r, n); return r; }
color add_g(int g, byte n) { add_c(g, n); return g; }
color add_b(int b, byte n) { add_c(b, n); return b; }
color sub_r(int r, byte n) { sub_c(r, n); return r; }
color sub_g(int g, byte n) { sub_c(g, n); return g; }
color sub_b(int b, byte n) { sub_c(b, n); return b; }
color mul_r(int r, byte n) { mul_c(r, n); return r; }
color mul_g(int g, byte n) { mul_c(g, n); return g; }
color mul_b(int b, byte n) { mul_c(b, n); return b; }
color div_r(int r, byte n) { div_c(r, n); return r; }
color div_g(int g, byte n) { div_c(g, n); return g; }
color div_b(int b, byte n) { div_c(b, n); return b; }

/////////// ADJUST LIGHT & DARKNESS //////////////

#define get_r(c) ((c)>>16&0xFF)
#define get_g(c) ((c)>>8&0xFF)
#define get_b(c) ((c)&0xFF)

color lighten_color(color c, byte n) {
  int r=get_r(c)+n, g=get_g(c)+n, b=get_b(c)+n;
  clip_color(&r, &g, &b);
  return rgb(r, g, b);
}

color darken_color(color c, byte n) {
  int r=get_r(c)-n, g=get_g(c)-n, b=get_b(c)-n;
  clip_color(&r, &g, &b);
  return rgb(r, g, b);
}

color invert_color(color c) {
  int r=255-((c>>16)&0xFF), g=255-((c>>8)&0xFF),
    b=255-(c&0xFF);
  return rgb(r, g, b);
}

color grayscale_color(color c) {
  int r=(c>>16)&0xFF, g=(c>>8)&0xFF, b=c&0xFF;
  c=(r+g+b)/3;
  clip_color(&r, &g, &b);
  return rgb(c, c, c);
}

//////////////////// ALPHA ///////////////////////

color mix(color d, color s, byte a); // a=0-255
color mixp(color d, color s, byte n); // n=0-100%
color mix75(color a, color b);
color mix50(color a, color b);
color mix25(color a, color b);

uint p_of(uint n, uint of) {
  if (n<1)
    return 0;
  else if (n>of)
    return of;
  return of/((double)100/n);
}

uint p_255(color c) { return p_of(c, 255); }
uint p_63(color c) { return p_of(c, 63); }
uint p_31(color c) { return p_of(c, 31); }

// alpha blend by %

color mixp(color d, color s, byte n) {
  return mix(d, s, p_255(n));
}

color mix75(color a, color b) {
  a=mix50(a, b);
  return mix50(a, b);
}

color mix50(color a, color b) {
  return ((a&0xFEFEFE)>>1)+((b&0xFEFEFE)>>1);
}

color mix25(color a, color b) {
  b=mix50(a, b);
  return mix50(a, b);
}

// alpha blend: x=((a*(sx-dx))/256)+dx)

color mix(color d, color s, byte a) {
  byte r, g, b, sr, sg, sb, dr, dg, db;
  sr=s>>16&0xFF, sg=s>>8&0xFF, sb=s&0xFF;
  dr=d>>16&0xFF, dg=d>>8&0xFF, db=d&0xFF;
  r=(a*(sr-dr)>>8)+dr;
  g=(a*(sg-dg)>>8)+dg;
  b=(a*(sb-db)>>8)+db;
  return (r<<16)|(g<<8)|b;
}

// in images where black and/or white is used as a
// special color - for transparency, alpha, compression.
// use this instead. no visual difference: +-1

enum { BLACK_X=0x000001, WHITE_X=0xFFFFFE };

// custom .palette

object {
  char name[12];
  color c;
} PALETTE;

ARRAY my_palette;

int create_my_palette(uint n) {
  if (!array_new(&my_palette, sizeof(PALETTE), n))
    return 0;
  return 1;
}

// get color element, value or name at i/ndex

PALETTE *get_palette_element(uint i) {
  return array_index(&my_palette, i);
}

color get_palette_color(uint i) {
  PALETTE *p=get_palette_element(i);
  return p->c;
}

void get_palette_color_name(text name, uint i) {
  PALETTE *p=get_palette_element(i);
  memory_copy(name, p->name, 12);
}

// get color index by name. return index or
// -1 if doesn't exist

int get_palette_index_by_name(text name) {
  uint i, r=-1, n=my_palette.n;
  char t[16];
  for (i=0; i<n; i++) {
    get_palette_color_name(t, i);
    if (text_equal(t, name)) {
      r=i;
      break;
    }
  }
  return r;
}

// get element by name. return index or 0
// if doesn't exist

PALETTE *get_palette_element_by_name(text name) {
  int i=get_palette_index_by_name(name);
  if (i==-1)
    return 0;
  return get_palette_element(i);
}

int palette_color_exists(text name) {
  if (get_palette_index_by_name(name)==-1)
    return 0;
  return 1;
}

int get_palette_color_by_name(text name, color *c) {
  PALETTE *p=get_palette_element_by_name(name);
  if (!p)
    return 0;
  *c=p->c;
  return 1;
}

// assign color at index, or create new,
// attach to end

int set_palette_color(text name, uint i, color c) {
  PALETTE p;
  p.c=c;
  memory_copy(p.name, name, 12);
  array_set(&my_palette, i, &p);
  return 1;
}

int new_palette_color(text name, color c) {
  PALETTE p;
  p.c=c;
  memory_copy(p.name, name, 12);
  if (!array_attach(&my_palette, &p))
    return 0;
  return 1;
}

void set_palette_color_name(text name, uint i) {
  PALETTE *p=array_index(&my_palette, i);
  memory_copy(p->name, name, 12);
  return 1;
}

// save my_palette colors as name.palette:

// header: 14 bytes signature, # colors 16BIT
// "PALETTE       NN"
// for each color: 12 bytes name, space, then argb32
// "BLUE        ARGB"

int save_my_palette(text name) {
  PALETTE *p;
  uint i, n=my_palette.n;
  if (!create_file(name))
    return 0;
  write_text("PALETTE ");
  write_4(0x20202020); // 6 spaces
  write_2(0x2020);
  write_2(n);
  for (i=0; i<n; i++) {
    p=array_index(&my_palette, i);
    write_file(p->name, 12);
    write_2(p->c);
  }
  close_file();
  return 1;
}

int get_hue(color c) {
  byte r=get_r(c), g=get_g(c), b=get_b(c), h, s, v, n,
    min=r<g?(r<b?r:b):(g<b?g:b), max=r>g?(r>b?r:b):(g>b?g:b);
  v=max, n=max-min;
  if (!v)
    return 0;
  if (!n)
    n=1;
  if (max==r)
    h=((43*(g-b))/n);
  else if (max==g)
    h=85+((43*(b-r))/n);
  else
    h=171+((43*(r-g))/n);
  return h;
}

int get_saturation(color c) {
  byte r=get_r(c), g=get_g(c), b=get_b(c), s,
    min=r<g?(r<b?r:b):(g<b?g:b), max=r>g?(r>b?r:b):(g>b?g:b);
  if (!max)
    return 0;
  s=(255*(max-min))/max;
  if (!s)
    return max;
  return s;
}

int get_gray(color c) {
  return 255-get_saturation(c);
}

int get_light(color c) {
  byte r=get_r(c), g=get_g(c), b=get_b(c), v,
    max=r>g?(r>b?r:b):(g>b?g:b);
  v=max;
  if (!v)
    return 0;
  return v;
}

color rgb_hsv(color c) {
  byte h=get_hue(c), s=get_gray(c), v=get_light(c);
  return rgb(h, s, v);
}

color hsv_rgb(color c) {
  byte region, re, p, q, t, r, g, b,
    h=get_r(c), s=get_g(c), v=get_b(c);
  if (!s) {
    r=g=b=v;
    return rgb(r, g, b);
  }
  region=h/43;
  re=(h-(region*43))*6; 
  p=(v*(255-s))>>8;
  q=(v*(255-((s*re)>>8)))>>8;
  t=(v*(255-((s*(255-re))>>8)))>>8;

  if (region==0)
    r=v, g=t, b=p;
  else if (region==1)
    r=q, g=v, b=p;
  else if (region==2)
    r=p, g=v, b=t;
  else if (region==3)
    r=p, g=q, b=v;
  else if (region==4)
    r=t, g=p, b=v;
  else
    r=v, g=p, b=q;
  return rgb(r, g, b);
}

/*
BEST 6BIT PALETTE: 64-COLORS

* 9: black to white
* 15: 5: reds, 5: blues, 5: greens
* 30: 2 cyans, 3 cyan-blues, 3 blue-grays,
3 magenta-blues, 3 magentas, 3 magenta-reds,
4 yellows (light/y/sun/dark), 3 oranges
(orange/redish/dark), 4 pinks (pastel/pink/hot/dark),
2 green-yellows
* 10: 5 fleshes, 5 browns
*/

/* 2-DO: HSL8. H=0-7. S=50% gray?
SS=0%/25%/50%/75% gray. L=0-15/0-7.
this produces much better results than
RGB8 (R3.G2.B2) which is not usable
because many colors are the same/similar,
slight variations of cyan, magenta and
yellow and there's no smooth shading or
grayish or flesh colors. HSL314 has
smoother shading, but HSL323 has more
color variation by mixing percentages
of gray with each hue value

HSL314: HHH.S.LLLL
HSL323: HHH.SS.LLL
*/