/* EZC LIBRARY. BY STARPOWER/MYSTERI/OUS.
    __  ___         __          _
  /  |/  /_ _____ / /____ ____(_)
 / /|_/ / // (_-<  __/ -_) __/ /
/_/  /_/\_, /___/\__/\__/_/ /_/
       /___/ (C) 2016+, KID-7/77 */

extern int screen_w, screen_h;

////////////////////// BOX ///////////////////////

// create, set, move, size, etc. the simplest
// little functions. useful for interfaces,
// images, icons, fonts, controls

// object { int x, y, w, h; } BOX; // in ez.h

void set_box(BOX *b, int x, int y, int w, int h) {
  b->x=x, b->y=y, b->w=w, b->h=h;
}

void get_area(BOX *b, int *x, int *y, int *w, int *h) {
  *x=b->x, *y=b->y, *w=b->w, *h=b->h;
}

void move_box(BOX *b, int x, int y) {
  b->x=x, b->y=y;
}

void size_box(BOX *b, int w, int h) {
  b->w=w, b->h=h;
}

void nudge_box(BOX *b, int x, int y) {
  b->x+=x, b->y+=y;
}

void budge_box(BOX *b, int w, int h) {
  b->w+=w, b->h+=h;
}

void copy_box(BOX *a, BOX *b) {
  a->x=b->x, a->y=b->y, a->w=b->w, a->h=b->h;
}

void move_box_up(BOX *b, int n) { b->y-=n; }
void move_box_right(BOX *b, int n) { b->x+=n; }
void move_box_down(BOX *b, int n) { b->y+=n; }
void move_box_left(BOX *b, int n) { b->x-=n; }

void move_box_way(BOX *b, int way, int n) {
  if (way=='u')
    b->y-=n;
  else if (way=='r')
    b->x+=n;
  else if (way=='d')
    b->y+=n;
  else if (way=='l')
    b->x-=n;
}

void move_box_u(BOX *b) { b->y-=b->h; }
void move_box_r(BOX *b) { b->x+=b->w; }
void move_box_d(BOX *b) { b->y+=b->h; }
void move_box_l(BOX *b) { b->x-=b->w; }

int size_box_percent(BOX *box, int p) {
  if (p<=0 or p==100)
    return 0;
  if (p<100) {
    box->w/=((float) 100/p);
    box->h/=((float) 100/p);
    return -box->w;
  }
  else {
    box->w*=((float) p/100);
    box->h*=((float) p/100);
    return box->w;
  }
  return 0;
}

// is visible partially or 100%? example: if an
// image is 100% visible, draw it entirely,
// and if it's slightly visible, draw that section

int visible_area(int x, int y, int w, int h) {
  return w>0 and h>0 and x<screen_w and y<screen_h
    and x+w>=0 and y+h>=0;
}

int visible_box(BOX *b) {
  return b->w>0 and b->h>0 and b->x<screen_w
    and b->y<screen_h and b->x+b->w>=0 and b->y+b->h>=0;
}

int visible_all(BOX *b) {
  return b->w>0 and b->h>0 and b->x>=0 and b->y>=0 and 
    b->x+b->w<screen_w and b->y+b->h<screen_h;
}

// is point inside box? example: mouse click x/y

int inside_area(int px, int py, int x, int y, int w, int h) {
  return px>=x and px<x+w and py>=y and py<y+h;
}

int inside_box(int px, int py, BOX *b) {  
  return px>=b->x and px<b->x+b->w and
    py>=b->y and py<b->y+b->h;
}

#define is_outside_box not is_inside_box

// are boxes touching? partially inside

int collide_box(BOX *a, BOX *b) {
  return a->x<b->x+b->w and a->x+a->w>b->x
    and a->y<b->y+b->h and a->y+a->h>b->y;
}

// does box contain another? 100% inside

int contains_box(BOX *a, BOX *b) {
  return b->x>=a->x and b->x+b->w<=a->x+a->w
    and b->y>=a->y and b->y+b->h<=a->y+a->h;
}

// increase/decrease box size with center

void increase_box(BOX *b, int n) {
  b->x-=n, b->y-=n, b->w+=n*2, b->h+=n*2;
}

void decrease_box(BOX *b, int n) {
  b->x+=n, b->y+=n, b->w-=n*2, b->h-=n*2;
}

// alignment

enum {
  CENTER_X=1, CENTER_Y=2, CENTER=CENTER_X|CENTER_Y,
  ALIGN_L=4, ALIGN_T=8, ALIGN_R=16, ALIGN_B=32
};

enum {
  NORTH=ALIGN_T|CENTER_X, ALIGN_N=NORTH,
  NORTH_EAST=ALIGN_T|ALIGN_R, ALIGN_NE=NORTH_EAST,
  EAST=ALIGN_R|CENTER_Y, ALIGN_E=EAST,
  SOUTH_EAST=ALIGN_B|ALIGN_R, ALIGN_SE=SOUTH_EAST,
  SOUTH=ALIGN_B|CENTER_X, ALIGN_S=SOUTH,
  SOUTH_WEST=ALIGN_B|ALIGN_L, ALIGN_SW=SOUTH_WEST,
  WEST=ALIGN_L|CENTER_Y, ALIGN_W=WEST,
  NORTH_WEST=ALIGN_T|ALIGN_L, ALIGN_NW=NORTH_WEST,
  ALIGN_C=CENTER, JUSTIFY_L=ALIGN_NW, JUSTIFY_R=ALIGN_NE
};

// align box inside another: b1 in b2. a=ALIGN_X

void align_box(BOX *b1, BOX *b2, int a) {
  if (a&ALIGN_L)
    b1->x=b2->x;
  if (a&ALIGN_T)
    b1->y=b2->y;
  if (a&ALIGN_R)
    b1->x=b2->x+b2->w-b1->w;
  if (a&ALIGN_B)
    b1->y=b2->y+b2->h-b1->h;
  if (a&CENTER_X)
    b1->x=b2->x+(b2->w/2)-(b1->w/2);
  if (a&CENTER_Y)
    b1->y=b2->y+(b2->h/2)-(b1->h/2);
}

void align_b(BOX *b1, int a) {
  BOX b2;
  set_box(&b2, 0, 0, screen_w-1, screen_h-1);
  align_box(b1, &b2, a);
}

void align_in(BOX *b1, BOX *b2, int a, int x, int y) {
  align_box(b1, b2, a);
  b1->x+=x, b1->y+=y;
}

#define align_box_in align_in