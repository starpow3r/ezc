/* EZC LIBRARY. BY STARPOWER/MYSTERI/OUS.
    __  ___         __          _
  /  |/  /_ _____ / /____ ____(_)
 / /|_/ / // (_-<  __/ -_) __/ /
/_/  /_/\_, /___/\__/\__/_/ /_/
       /___/ (C) 2016+, KID-7/77 */

// DYNAMIC ARRAY

/*
array_create a, size   ; initialize, set size
array_size a, n        ; allocate # elements
array_new a, size, n   ; allocate # elements of size
array_destroy a        ; deallocate a.p
array_index a, i       ; get element address
array_recent a         ; get last element address
array_get a, i, p      ; copy p=a[i]
array_set a, i, p      ; overwrite a[i]=p
array_move a, i, j     ; copy a[i]=a[j]
array_zero a, i        ; zero element at i/ndex
array_erase a          ; zero entire array
array_expand a         ; allocate n+1
array_reduce a         ; remove last, a[n-1]
array_shorten a        ; remove first, a[0]
array_attach a, p      ; attach to end: a[n-1]
array_insert a, i, p   ; insert a[i]=p
array_remove a, i      ; remove a[i]
array_prepend a, p, m  ; insert first a[0]=p, remove last
array_queue a, p, m    ; insert last a[n]=p, remove first
array_assign a, p, n   ; assign all elements
array_exchange...      ; exchange indices
array_randomize a      ; randomize
array_sort a...        ; sort via function p */    

object {
  uint size, n, i;
  void *p;
} ARRAY;

void *array_create(ARRAY *a, uint size);
void *array_size(ARRAY *a, uint n);
void *array_new(ARRAY *a, uint size, uint n);
int array_assign(ARRAY *a, void *p, uint n);
void array_destroy(ARRAY *a);
void *array_index(ARRAY *a, uint i);
void *array_recent(ARRAY *a);
void array_get(ARRAY *a, uint i, void *p);
void array_set(ARRAY *a, uint i, void *p);
void array_move(ARRAY *a, uint i, uint j);
void array_zero(ARRAY *a, uint i);
void array_erase(ARRAY *a);
void *array_expand(ARRAY *a);
void *array_reduce(ARRAY *a);
int array_shorten(ARRAY *a);
void *array_attach(ARRAY *a, void *p);
int array_insert(ARRAY *a, uint i, void *p);
int array_remove(ARRAY *a, uint i);
void array_exchange(ARRAY *a, uint i,
  uint j, void *z);
int array_randomize(ARRAY *a);
void array_sort_s(ARRAY *a);
void array_sort_i(ARRAY *a);

void *array_create(ARRAY *a, uint size) {
  a->size=size, a->n=a->i=0;
  return array_size(a, 0);
}

void *array_new(ARRAY *a, uint size, uint n) {
  if (!array_create(a, size))
    return 0;
  return array_size(a, n);
}

void *array_size(ARRAY *a, uint n) {
  if (!n) {
    array_destroy(a);
    return (void *) 1;
  }
  if (!reallocate(void *, a->p, n*a->size))
    return 0;
  a->n=n;
  return array_recent(a);
}

void array_destroy(ARRAY *a) {
  destroy(a->p);
  a->n=a->i=0;
}

int array_assign(ARRAY *a, void *p, uint n) {
  if (a->n<n and !array_size(a, n))
    return 0;
  for (uint i=0; i<n; i++)
    array_set(a, i, (byte *) p+(i*a->size));
  return 1;
}

void *array_index(ARRAY *a, uint i) {
  return (byte *) a->p+(i*a->size);
}

void *array_recent(ARRAY *a) {
  return array_index(a, a->n-1);
}

// void *p=(byte *) array.p+(5*array.size);
// uint i=array_get_index(&array, p);
//  printf("Index: %d\n", i);

uint array_get_index(ARRAY *array, void *a) {
  void *p=array->p;
  uint i, n=array->n, size=array->size;
  if (a==p)
    return 0;
  if (a<p) // or a>=p+(n*size))
    return -1;
  i=(a-p)/size;
  return i;
}

void array_get(ARRAY *a, uint i, void *p) {
  memory_move(p, array_index(a, i), a->size);
}

void array_set(ARRAY *a, uint i, void *p) {
  memory_move(array_index(a, i), p, a->size);
}

void array_move(ARRAY *a, uint i, uint j) {
  array_set(a, i, array_index(a->p, j));
}

void array_zero(ARRAY *a, uint i) {
  memory_zero(array_index(a, i), a->size);
}

void array_erase(ARRAY *a) {
  memory_zero(a->p, a->size*a->n);
}

void *array_expand(ARRAY *a) {
  void *p;
  if (!array_size(a, a->n+1))
    return 0;
  p=array_recent(a);
  memory_zero(p, a->size);
  return p;
}

void *array_reduce(ARRAY *a) {
  if (!a->n)
    return 0;
  return array_size(a, a->n-1);
}

int array_shorten(ARRAY *a) {
  return array_remove(a, 0);
}

void *array_attach(ARRAY *a, void *p) {
  void *q=array_expand(a);
  if (!q)
    return 0;
  array_set(a, a->n-1, p);
  return q;
}

int array_insert(ARRAY *a, uint i, void *z) {
  uint n=a->n, size=a->size;
  void *p;
  if (!array_expand(a))
    return 0;
  p=(byte *) a->p+(i*size);
  memory_move((byte *) p+size, p, (n-i)*size);
  array_set(a, i, z);
  return 1;
}

// 0000-1111-2222-3333-4444-5555
// aaaa-bbbb-cccc-dddd-eeee-ffff

int array_remove(ARRAY *a, uint i) {
  uint n=a->n, size=a->size;
  if (!n)
    return 0;
  if (i==n-1) {
    array_reduce(a);
    return 1;
  }
  void *p=(byte *) a->p+(i*size);
  if (i)
    n=(n-i)*size;
  else
    n=n*(size-1);
  memory_move(p, (byte *) p+size, n);
  array_reduce(a);
  return 1;
}

int array_prepend(ARRAY *a, void *p, uint maximum) {
  if (!array_insert(a, 0, p))
    return 0;
  if (a->n>maximum)
    array_reduce(a);
  return 1;
}

int array_queue(ARRAY *a, void *p, uint maximum) {
  array_attach(a, p);
  if (a->n>maximum)
    array_remove(a, 0);
  return 1;
}

// exchange indices i/j using z as a temporary buffer

void array_exchange(ARRAY *a, uint i, uint j, void *z) {
  int n=a->size;
  void *p=array_index(a, i), *q=array_index(a, j);
  memory_move(z, p, n);
  memory_move(p, q, n);
  memory_move(q, z, n);
}

// randomize indices. allocates temporary buffer once
// before the loop, then deallocates it after

int array_randomize(ARRAY *a) {
  uint i, n=a->n, max=n-1;
  void *p;
  if (!allocate(void *, p, a->size))
    return 0;
  for (i=0; i<n; i++)
    array_exchange(a, i, random(max), p);
  destroy(p);
  return 1;
}

// sort/arrange indices

typedef int (*compare_f)(const void *, const void *);

void array_sort(ARRAY *a, compare_f f) {
  qsort(a->p, a->n, a->size, f);
}

#define array_sort_i(a) array_sort(a, compare_i)
#define array_sort_id(a) array_sort(a, compare_id)
#define array_sort_s(a) array_sort(a, compare_s)
#define array_sort_sd(a) array_sort(a, compare_sd)

int compare_i(const void *a, const void *b) {
  return ((int) *a)-((int) *b);
}

int compare_id(const void *a, const void *b) {
  return ((int) *b)-((int) *a);
}

int compare_s(const void *a, const void *b) {
  return strcmp((char *) a, (char *) b);
}

int compare_sd(const void *a, const void *b) {
  return strcmp((char *) b, (char *) a);
}

// rename these...

#define compare_t(a) compare_s
#define compare_td(a) compare_sd
#define array_sort_t(a) array_sort_s
#define array_sort_td(a) array_sort_sd