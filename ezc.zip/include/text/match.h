// match(pattern, source)...

int setup_match();
int match(text pattern, text source);

// match structures: 8k

#define MATCH_SIZE 1024
#define N_MATCHES 8
#define NAME_LENGTH 32
#define VALUE_SIZE (MATCH_SIZE-NAME_LENGTH)

object {
  char name[NAME_LENGTH], value[VALUE_SIZE];
} MATCH;

MATCH *matches=0;
int n_matches=0, match_errors=0;
char match_error[32];

int setup_match() {
  if (matches)
    return 1;
  n_matches=0;
  if (!allocate(MATCH *, matches,
    N_MATCHES*sizeof(MATCH))) {
    source_error("Error (setup_match): " \
      "Memory allocation failed");
    return 0;
  }
  return 1;
}

// match(pattern, source)...

// match pattern in source. extract tokens
// from expression, and divide it into sections.
// return 1 if success, and assign matches[n_matches]
// structures for each variable name in pattern.
// uses rarest ` symbol for literal match

int match(text pattern, text source) {
  text p=pattern, s=source, m=0;
  int i, c, exact, type1, type2;
  char t1[256], t2[256];

  // allocate matches if necessary

  if (!setup_match())
    return 0;

  // initialize matches

  MATCH *mp=&matches[0];
  memory_zero(mp, N_MATCHES*sizeof(MATCH));
  m=mp->value, n_matches=0;

  if (!p or !s) {
    source_error("Error (match): Address=0");
    return 0;
  }

  // skip spaces

  p=skip_space(p), s=skip_space(s);

  // "any" keyword? not empty/nothing?
  // true if source contains something

  // match("any", "x") = true
  // match("any", " ") = false

  if (text_equal(p, "any")) {
    if (*s and not is_return(*s))
      return 1;
    return 0;
  }

  // match(pattern, source)

  if (is_end(*p)) { // end pattern?
    if (is_end(*s)) // end source?
      return 1;     // true, finished.
    return 0;       // false, source ends
  }                 // before pattern

  // scroll through pattern and source

  while (1) {
    p=skip_space(p);  // skip spaces
    s=skip_space(s);

    if (is_end(*s)) { // end source?
      if (is_end(*p)) // end pattern?
        return 1;     // true, finished.
      return 0;       // false, source ends
    }                 // before pattern.
    if (is_end(*p))   // end pattern?
      return 1;       // finished

    exact=0;          // literal `match
    if (*p=='`')      // skip `
      exact=1, p++;

    // get next token from pattern and source: t1, t2.
    // note: get_token returns 0 if end/!*p

    p=get_token_from(t1, p), type1=token_type;
    s=get_token_from(t2, s), type2=token_type;

    if (!s)     // end source?
      return 0; // false
    if (!p)     // end pattern?
      return 1; // finished

    p=skip_space(p), s=skip_space(s);

    // literal `match

    if (exact) {
      if (text_equal(t1, t2)) // true
        continue;
      return 0; // false
    }

    // variable in pattern? get next match name/value

    if (type1==T_NAME) {
      if (n_matches>=8) {
        source_error("Error (match): " \
          "Matches exceed maximum (%d)", n_matches);
        return 0;
      }
      mp=&matches[n_matches++];  // get next match
      text_copy(mp->name, t1);   // name and value (m).
      m=mp->value;               // copy initial value
      m=text_copy(m, t2);        // and advance to end

      if (is_end(*s)) { // end source?
        if (is_end(*p)) // end pattern?
          return 1;     // true, both end
        return 0;       // false, source end
      }
    }

    // symbol in pattern? +-* append source token (t2)
    // to current matches[].value (m), and advance

    else if (type1==T_SYMBOL) {
      c=t1[0];
      if (type2==T_SYMBOL and c==t2[0])
        continue;
      if (is_end(*s)) // end source?
        return 0;     // symbol not found

      m=text_attach(m, t2); // attach value

      // copy characters from source to current
      // matches[].value until symbol is encountered.
      // note: may support line continuation with \,
      // or automatic if ends with certain symbols
      // which always continue like =,([{, math
      // operators +-*/ and relational "and/or"

      while (*s!=c and not is_end(*s))
        *m++=*s++;
      *m=0;
      if (is_end(*s)) // end source?
        return 0;     // false, symbol not found
      s++;            // matched, skip
    }

    if (is_end(*s)) { // end source?
      if (is_end(*p)) // end pattern?
        return 1;     // true, both end
      return 0;       // false, source end
    }

    if (is_end(*p)) {     // end pattern?
      s=skip_space(s);    // advance to end
      *m++=' ';
      m+=text_n(m);

      // success; copy remaining characters from
      // source until end *s=0 or return.
      // attach to matches[].value, then return

      while (not is_end(*s))
        *m++=*s++;
      *m=0;

      // remove ending spaces if any

      if (is_space(*(m-1))) {
        m--;
        while (is_space(*m))
          *m--=0;
      }
      return 1; // true
    }
  }
  source_error("Error (match): " \
    "Invalid value");
  return 0;
}