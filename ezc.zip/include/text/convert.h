/////////////////// CONVERSIONS //////////////////

// convert to/from number/text: u=unsigned,
// i/n=int, h=hexadecimal, b=binary, f=double

#define n2t i2t // number to text
#define t2n t2i // text to number

uint t2u(text t) {
  uint n;
  for (n=0; *t; t++)
    n=(n*10)+(*t-'0');
  return n;
}

int t2i(text t) {
  int n=0, sign=0;
  if (*t=='-')
    sign=1, t++;
  n=t2u(t);
  if (sign)
    n=-n;
  return n;
}

uint t2h(text t) {
  uint n, c, x;
  for (n=0; *t; t++) {
    c=*t;
    if (c>='0' and c<='9')
      x=(c-'0');
    else if (c>='a' and c<='f')
      x=(c-'a')+10;
    else if (c>='A' and c<='F')
      x=(c-'A')+10;
    else
      break;
    n=(n*16)+x;
  }
  return n;
}

uint t2b(text t) {
  uint n;
  for (n=0; *t; t++)
    n=(n*2)+(*t-'0');
  return n;
}

double t2f(text t) {
  int sign=1, divisor=1, radix=0;
  double n=0, mantissa=0;
  if (*t=='-') {
    sign=-1;
    t++;
  }
  for (; *t; t++) {
    if (*t=='.')
      radix=1;
    else if (*t>='0' and *t<='9') {
      if (!radix)
        n=(n*10)+(*t-'0');
      else {
        mantissa=(mantissa*10)+(*t-'0');
        divisor*=10;
      }
    }
    else
      break;
  }
  return sign*(n+(mantissa/divisor));
}

// convert number to text

text u2t(uint n, text t) {
  text p=t;
  if (!n) {
    *t++='0', *t=0;
    return t;
  }
  while (n)
    *p++=(n%10)+'0', n/=10;
  *p=0;
  text_reverse(t);
  return p;
}

text i2t(int n, text t) {
  if (n<0)
    *t++='-', n=-n;
  return u2t(n, t);
}

text h2t(uint n, text t) {
  text p=t, h="0123456789ABCDEF";
  if (!n) {
    *t++='0', *t=0;
    return t;
  }
  while (n>0)
    *p++=h[n%16], n/=16;
  *p=0;
  text_reverse(t);
  return p;
}

text b2t(uint n, text t) {
  text p=t;
  if (!n) {
    *t++='0', *t=0;
    return t;
  }
  while (n>0)
    *p++=(n%2)+'0', n/=2;
  *p=0;
  text_reverse(t);
  return p;
}

double fp_rounders[11]={
  0.5, 0.05, 0.005, 0.0005, 0.00005, 0.000005,
  0.0000005, 0.00000005, 0.000000005, 0.0000000005
};

int fp_precision=2; // 0.00

text f2t(double f, text t) {
  text q=t, p=q, s, e;
  uintq i;
  char c;
  int precision=fp_precision;

  if (f<0) { // negative
    f=-f;
    *q++='-';
  }
  if (precision)
    f+=fp_rounders[precision];

  i=f, f-=i; // integer
  if (!i)
    *q++='0';
  else {
    p=q;
    while (i) { // convert
      *p++=(i%10)+'0', i/=10;
    }
    e=p; // reverse
    while (p>q) {
      c=*--p, *p=*q, *q++=c;
    }
    q=e;
  }
  if (precision) {
    *q++='.';
    while (precision--) { // fraction
      f*=10.0, c=f;
      *q++=c+'0', f-=c;
    }
  }
  *q=0;
  return q;
}

// convert number to text with alignment

#define x2ta(name, n, t, by) \
  char s[64]; \
  name(n, s); \
  text_align(s, '0', by); \
  text_copy(t, s);

text u2ta(uint n, text t, int by)
  { x2ta(u2t, n, t, by); }
text i2ta(uint n, text t, int by)
  { x2ta(i2t, n, t, by); }
text h2ta(uint n, text t, int by)
  { x2ta(h2t, n, t, by); }
text b2ta(uint n, text t, int by)
  { x2ta(b2t, n, t, by); }

text f2ta(double n, text t, int by) {
  int p=fp_precision;
  fp_precision=by;
  t=f2t(n, t);
  fp_precision=p;
  return t;
}

// convert numeric size to compact text with suffix:
// b/yte, k/ilobyte, m/egabyte, g/igabyte, t/erabyte

text get_size_text(uint64 n, text t) {
  char s[32], suffix='b';
  uint64 divisor=0;
  double value;
  t[0]=0;
  if (n>=1099511627776)
    divisor=1099511627776, suffix='t';
  else if (n>=1073741824)
    divisor=1073741824, suffix='g';
  else if (n>=1048576)
    divisor=1048576, suffix='m';
  else if (n>=1024)
    divisor=1024, suffix='k';
  value=n;
  if (divisor)
    value/=divisor;
 
  #define is_whole(f) \
    ((f)-(uint64)(f)==0) // (fmod(f, 1)==0.0)

  // (uses sprintf. print(...) is not defined yet)

  if (is_whole(value))
    sprintf(t, "%llu", (uint64) value);
  else
    sprintf(t, "%.1lf", value);
  if (text_ends(t, ".0"))
    t[text_n(t)-2]=0;
  text_attach_c(t, suffix);
  return t;
}

int get_time_text(uint n, text t) {
  if (n>(60*24))
    print(t, "%dd", n/(60*24));
  else if (n>(60*3))
    print(t, "%dh", n/60);
  else // if (n>60)
    print(t, "%dm", n);
}