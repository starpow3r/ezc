/* EZC LIBRARY. BY STARPOWER/MYSTERI/OUS.
    __  ___         __          _
  /  |/  /_ _____ / /____ ____(_)
 / /|_/ / // (_-<  __/ -_) __/ /
/_/  /_/\_, /___/\__/\__/_/ /_/
       /___/ (C) 2016+, KID-7/77 */

text text_end(text t);
uint text_n(text t);
text text_write(text a, text b);
text text_copy(text a, text b);
text text_copy_n(text a, text b, uint n);
int text_compare(text a, text b);
int text_equal(text a, text b);
text text_attach(text a, text b);
text text_attach_c(text t, char c);
void text_reverse(text t);
int text_begins(text a, text b);
int text_ends(text a, text b);
text text_find(text t, char c);
text text_find_r(text t, char c);
text text_search(text a, text b);
text text_go(text t, uint n);
void text_expand(text t, uint n);
void text_prefix(text a, text b);
int text_insert(text a, text b, uint i);
int text_insert_c(text a, uint i, char c);
void text_delete_c(text a, uint i);
void text_delete_n(text a, uint n);
void text_enclose(text t, char b, char e);
void text_align(text t, char c, uint n);
void text_limit(text t, uint n);
uint text_count_c(text t, char c);
uint text_count(text a, text b);
uint text_count_lines(text t);
void text_replace_c(text a, char what, char with);
text text_replace(text a, text what, text with);
void text_upper(text t);
void text_lower(text t);
int text_compare_i(text a, text b);
int text_equal_i(text a, text b);
int text_begins_i(text a, text b);
int text_ends_i(text a, text b);
text text_find_i(text t, char c);
text text_search_i(text a, text b);

uint t2u(text t);
int t2i(text t);
uint t2h(text t);
uint t2b(text t);
uint t2x(text t);
double t2f(text t);
text u2t(uint n, text t);
text i2t(int n, text t);
text h2t(uint n, text t);
text b2t(uint n, text t);

text print(text p, text t, ...);

// get end address

text text_end(text a) {
  while (*a)
    a++;
  return a;
}

// get length

uint text_n(text a) {
  text e=a;
  while (*e)
    e++;
  return e-a;
}

// write; copy with no 0 after

text text_write(text a, text b) {
  for (; *b; *a++=*b++);
  return a;
}

// standard copy with 0 terminator

text text_copy(text a, text b) {
  while (*b)
    *a++=*b++;
  *a=0;
  return a;
}

// copy with maximum size specified

text text_copy_n(text a, text b, uint n) {
  for (uint i=0; *b and i<n; *a++=*b++, i++);
  *a=0;
  return a;
}

// lexical comparison. return <0> (0 if equal or <> if
// less/greater. for sort/arrange alphabetically)

int text_compare(text a, text b) {
  for (; *a and *a==*b; a++, b++);
  return *a-*b;
}

// equal? if yes, return true/!0

int text_equal(text a, text b) {
  for (; *a and *a==*b; a++, b++);
  return !(*a-*b);
}

// attach "t"; concencate

text text_attach(text a, text b) {
  return text_copy(text_end(a), b);
}

// attach 'c'haracter

text text_attach_c(text t, char c) {
  t=text_end(t), *t++=c, *t=0;
  return t;
}

text text_attach_nl(text t) {
  text_attach_c(t, 0x0D);
  return text_attach_c(t, 0x0A);
}

// reverse

void text_reverse(text t) {
  char c;
  text e=text_end(t)-1;
  for (; t<e; c=*t, *t++=*e, *e--=c); 
}

// convert to uppercase/lowercase

void text_upper(text t) {
  for (; *t; t++)
    if (*t>='a' and *t<='z')
      *t-=32;
}

void text_lower(text t) {
  for (; *t; t++)
    if (*t>='A' and *t<='Z')
      *t+=32;
}

// begins with?

int text_begins(text a, text b) {
  for (; *a and *a==*b; a++, b++);
  return !*b;
}

// ends with?

int text_ends(text a, text b) {
  uint i=text_n(a), j=text_n(b);
  if (i<j)
    return 0;
  return text_equal(a+i-j, b);
}

// search for 'c'. return address of index or 0

text text_find(text t, char c) {
  for (; *t; t++)
    if (*t==c)
      return t;
  return 0;
}

// search for 'c' in reverse

text text_find_r(text t, char c) {
  text p=text_end(t);
  for (; p>=t; p--)
    if (*p==c)
      return p;
  return 0;
}

// search for "b". next occurance

text text_search(text a, text b) {
  for (; *a; a++)
    if (*a==*b and text_begins(a, b))
      return a;
  return 0;
}

// search text array for t

uint text_search_a(text ta[], text t, uint n) {
  for (uint i=0; i<n; i++)
    if (text_equal(t, ta[i]))
      return i;
  return -1;
}

// replace appearances of 'c'

void text_replace_c(text t, char what, char with) {
  for (; *t; t++)
    if (*t==what)
      *t=with;
}

// expand; shift all characters right.
// example: 'abc123' becomes 'abcabc123'
// after expand 3. first 'abc' is
// ignored: 'XXXabc123'

void text_expand(text t, uint n) {
  uint i, j=text_n(t);
  text q=t+j-1, p=q+n;
  for (i=0; i<j; i++, *p--=*q--);
}
 
// expand starting at index

void text_expand_x(text t, uint i, uint n) {
  text_expand(t+i, n);
}

// prefix. opposite of attach

void text_prefix(text a, text b) {
  text_expand(a, text_n(b));
  text_write(a, b);
}

// insert "text" at index: &a[i]=b

int text_insert(text a, text b, uint i) {
  int x=text_n(b), n=text_n(a)+x;
  if (i>=n)
    return 0;
  text_expand(a+i, x);
  text_write(a+i, b);
  a[n]=0;
  return 1;
}

// insert character, a[i]=c, increase length

int text_insert_c(text a, uint i, char c) {
  uint n=text_n(a);
  if (i>n)
    return 0;
  if (i==n) {
    text_attach_c(a, c);
    return 1;
  }
  memory_move(a+i+1, a+i, n-i); // shift right
  a[i]=c, a[n+1]=0;
  return 1;
}

// delete character at i/ndex

void text_delete_c(text a, uint i) {
  if (i<text_n(a))
    text_copy(&a[i], &a[i+1]);
}

// delete # characters. if n<length,
// shift all characters to the left.
// else, delete all

void text_delete_n(text a, uint n) {
  if (n<text_n(a))
    text_copy(a, &a[n]);
  else if (n)
    *a=0;
}

// delete # characters starting at index

void text_delete_i(text a, uint i, uint n) {
  text_delete_n(a+i, n);
}

// enclose "t" in 'c'. attach b/egin and
// e/nd. example: text_enclose(t, '<', '>')

void text_enclose(text t, char b, char e) {
  uint n=text_n(t);
  text_expand(t, 1);
  *t=b, t[n+1]=e, t[n+2]=0;
}

// align; prefix with c's ('0', ' ', etc)
// or ensure maximum n. example:
// text t='7FAB'; text_align(t, '0', 8);
// result='00007FAB', aligned to hex32

void text_align(text t, char c, uint n) {
  uint i, j;
  if (!n)
    return;
  j=text_n(t);
  if (j>=n) {
    t[n]=0;
    return;
  }
  n-=j;
  text_expand(t, n);
  for (i=0; i<n; i++, *t++=c);
  t+=j, *t=0;
}

// limit to # characters. reduce and
// attach '..'. example:
// text_limit("abcdefg", 5)
// result: "abc.."

void text_limit(text t, uint n) {
  uint w=text_n(t);
  if (n>=w)
    return;
  text_copy(t+n-2, "..");
}

void text_limit_t(text a, text b, uint n) {
  uint an=text_n(a), bn=text_n(b);
  if (an>n)
    text_copy(a+n-bn, b);
}

// count occurances of 'c'

uint text_count_c(text t, char c) {
  uint n;
  for (n=0; *t; t++)
    if (*t==c)
      n++;
  return n; 
}

// count occurances of "b"

uint text_count(text a, text b) {
  uint n;
  for (n=0; *a; a++, n++)
    if (not (a=text_search(a, b)))
      break;
  return n;
}

// count # of lines

uint text_count_lines(text t) {
  return text_count_c(t, 0xA)+1;
}

// get line address by # or 0=invalid

text text_go(text t, uint y) {
  uint i;
  text p, q=t;
  for (i=0; i<y; i++, q=p+1)
    if (not (p=text_find(q, 0x0A)))
      break;
  if (i==y) // reached y
    return q;
  return 0;
}

// get address at x/y or 0=invalid

text text_at(text t, uint x, uint y) {
  uint n=text_count_lines(t);
  if (y>=n-1)
    y=n-1;
  text p=text_go(t, y)+x;
  if (p>text_end(t))
    return 0;
  return p;
}

// get index at x/y or 0=invalid

uint text_get_i(text t, uint x, uint y) {
  text p=text_at(t, x, y);
  if (!p)
    return 0;
  return p-t;
}

// get x/y of i/ndex in s/ource

uint text_get_x(text s, uint i) {
  text e=s+i;
  uint x;
  for (x=0; *s and s<e; s++)
    if (*s!=0x0D and *s!=0x0A)
      x++;
    else
      x=0, s++;
  return x;
}

uint text_get_y(text s, uint i) {
  text e=s+i;
  uint y;
  for (y=0; *s and s<e; s++)
    if (*s==0x0A)
      y++;
  return y;
}

int text_get_xy(text s, int i, uint *x, uint *y) {
  *x=text_get_x(s, i);
  *y=text_get_y(s, i);
  if (*x==-1)
    *x=0;
  if (*y==-1)
    *y=0;
  return 1;
}

// get x/y of a/ddress in s/ource

void text_xy(text s, text a, uint *x, uint *y) {
  *x=*y=0;
  for (; s<a; s++)
    if (*s==0x0A)
      *y=*y+1, *x=0;
    else
      *x=*x+1;
}

// get line # of address in source

uint text_get_line_n(text s, text a) {
  uint n;
  text p=s;
  for (n=0; *p and p<a; n++, p++)
    if (not (p=text_find(p, 0xD)))
      break;
  return n;
}

// get line width until return or 0,
// current line. no advance

uint text_line_w(text t, uint n) {
  uint i;
  text p=t;
  if (!p or !*p or n==-1)
    return 0;
  p=text_go(t, n);
  if (!p)
    return 0;
  for (i=0; *p and *p!=0x0D; p++, i++);
  return i;
}

/////////////////// INSENSITIVE //////////////////

// insensitive lookup table: A-Z/a-z = same

char ilt[128]={
  0x00,0x01,0x02,0x03,0x04,0x05,0x06,0x07,
  0x08,0x09,0x0A,0x0B,0x0C,0x0D,0x0E,0x0F,
  0x10,0x11,0x12,0x13,0x14,0x15,0x16,0x17,
  0x18,0x19,0x1A,0x1B,0x1C,0x1D,0x1E,0x1F,
  0x20,0x21,0x22,0x23,0x24,0x25,0x26,0x27,
  0x28,0x29,0x2A,0x2B,0x2C,0x2D,0x2E,0x2F,
  0x30,0x31,0x32,0x33,0x34,0x35,0x36,0x37,
  0x38,0x39,0x3A,0x3B,0x3C,0x3D,0x3E,0x3F,
  0x40,0x41,0x42,0x43,0x44,0x45,0x46,0x47,
  0x48,0x49,0x4A,0x4B,0x4C,0x4D,0x4E,0x4F,
  0x50,0x51,0x52,0x53,0x54,0x55,0x56,0x57,
  0x58,0x59,0x5A,0x5B,0x5C,0x5D,0x5E,0x5F,
  0x60,0x41,0x42,0x43,0x44,0x45,0x46,0x47,
  0x48,0x49,0x4A,0x4B,0x4C,0x4D,0x4E,0x4F,
  0x50,0x51,0x52,0x53,0x54,0x55,0x56,0x57,
  0x58,0x59,0x5A,0x7B,0x7C,0x7D,0x7E,0x7F
};

int text_compare_i(text a, text b) {
  for (; *a and ilt[*a]==ilt[*b]; a++, b++);
  return *a-*b;
}

int text_equal_i(text a, text b) {
  for (; *a and ilt[*a]==ilt[*b]; a++, b++);
  return !(*a-*b);
}

int text_begins_i(text a, text b) {
  for (; *a and ilt[*a]==ilt[*b]; a++, b++);
  return !*b;
}

int text_ends_i(text a, text b) {
  uint i=text_n(a), j=text_n(b);
  if (i<j)
    return 0;
  return text_equal_i(a+i-j, b);
}

text text_find_i(text t, char c) {
  for (; *t; t++)
    if (ilt[*t]==c)
      return t;
  return 0;
}

text text_search_i(text a, text b) {
  for (; *a; a++)
    if (text_begins_i(a, b))
      return a;
  return 0;
}

//////////////// SEARCH, REPLACE /////////////////

enum { SEARCH_ANY=1, SEARCH_ALL=2, SEARCH_QUOTE=4,
  SEARCH_CASE=8, SEARCH_NO_CASE=16, SEARCH_WHOLE=32,
  SEARCH_RESET=64, SEARCH_S=128, SEARCH_SUFFIX=256,
  SEARCH_SIMILAR_50=512, SEARCH_SIMILAR_75=1*KB };

uint search_type=SEARCH_CASE;

// replace in a, what, with. no allocation.
// only works if with_n<what_n. return # replacements

uint text_replace_na(text a, text what, text with) {
  uint n=0,
    what_n=text_n(what), with_n=text_n(with);
  text p=a, s=a;
  if (with_n>=what_n) // error
    return 0;
  while (*s) {
    if (text_begins(s, what)) {
      text_write(p, with);
      p+=with_n, s+=what_n, n++;
      continue;
    }
    *p++=*s++;
  }
  *p=0;
  return n;
}

// text_replace(a, what, with). a is unaffected.
// returns allocated text. destroy(p) sometime after

text text_replace(text a, text what, text with) {
  text p=0, q=a, z=0;
  uint r, n=text_count(a, what);
  if (!n)
    return a;
  uint an=text_n(a),
    what_n=text_n(what), with_n=text_n(with),
    size=an-(n*what_n)+(n*with_n);
  if (!allocate(text, z, size+32))
    return 0;
  p=z;
  while (*q) {
    if (search_type&SEARCH_CASE)
      r=text_begins(q, what);
    else
      r=text_begins_i(q, what);
    if (search_type&SEARCH_WHOLE)
      if (not (is_end(q[what_n])
        or is_white(q[what_n])))
        r=0;
    if (r) {
      text_write(p, with);
      p+=with_n, q+=what_n;
      continue;
    }
    *p++=*q++;
  }
  *p=0;
  return z;
}

// remove character. return new length

int text_remove_c(text t, char c) {
  uint n=0;
  text a=t, b=t;
  while (*b) {
    if (*b!=c) {
      *a++=*b++;
      n++;
    }
    else
      b++;
  }
  *a=0;
  return n;
}

///////////////////// SKIP ///////////////////////

// skip spaces and tabs

text skip_space(text t) {
  while (is_space(*t))
    t++;
  return t;
}

// skip whitespace and returns

text skip_white(text t) {
  while (is_white(*t)) {
    if (*t==0x0A) {
      t++;
      // source_line_n++;
    }
  }
  return t;
}

// skip comments: ; ;* *;

text skip_comment(text t) {
  if (*t==';') {
    if (t[1]=='*') { // multi-line
      for (t++; *t; t++) {
        if (*t=='*' and t[1]==';') {
          t+=2;
          break;
        }
        if (*t==0x0D)
          ; // source_line_n++;
      }
    }
    else { // single line
      while (*t and not is_return(*t))
        t++;
      if (*t)
        ; // source_line_n++;
    }
  }
  return t;
}

// skip all whitespace and ; comments

text skip_all(text p) {
  while (is_white(*p) or *p==';') {
    p=skip_white(p);
    if (*p)
      p=skip_comment(p);
  }
  return p;
}

// remove ; comments

void text_uncomment(text t) {
  text a=t, b=t;
  while (*b) {
    if (*b==';') {
      for (b++; *b and
        not is_return(*b); b++);
      if (!*b)
        break;
      // source_line_n++;
      continue;
    }
    *a++=*b++;
  }
  *a=0;
}

// copy to line a from source b. return
// advanced address

text text_line(text a, text b) {
  for (; *b and not is_return(*b);
    *a++=*b++);
  *a=0;
  if (!*b)
    return 0;
  b=skip_white(b);
  return b;
}

// replace tabs with spaces

void text_untabify(text t) {
  text_replace_c(t, '\t', ' ');
}