// unorganized...

////////////////// SOURCE, TOKEN /////////////////

text source, source_p, source_begin,
  last_source, last_source_p,
  destiny, destiny_p, last_destiny, last_destiny_p,
  destiny_start, output, output_p, token, last_token,
  token_name, token_value;
uint source_size, destiny_size, output_size;
uint token_type, token_value_i,
  token_size, token_value_type, token_value_size;

enum { FORMAT_NONE, FORMAT_SOUL, FORMAT_C, FORMAT_HTML,
  FORMAT_JS, FORMAT_PHP, FORMAT_ASM_MIRACLE,
  FORMAT_DASM_MIRACLE, FORMAT_PURE_MIRACLE,
  FORMAT_ASM_INTEL, FORMAT_DASM_INTEL, FORMAT_PURE_INTEL,
  FORMAT_ASM_ARM, FORMAT_DASM_ARM, FORMAT_PURE_ARM,
  FORMAT_ASM_6502, FORMAT_DASM_6502, FORMAT_PURE_6502,
  FORMAT_ASM_Z80, FORMAT_DASM_Z80, FORMAT_PURE_Z80,
  FORMAT_ASM_AVR, FORMAT_DASM_AVR, FORMAT_PURE_AVR,
  FORMAT_X, FORMAT_L, FORMAT_EXE, FORMAT_DOS16,
  FORMAT_DOS32, FORMAT_DLL };

int source_format=FORMAT_SOUL, destiny_format=FORMAT_NONE;
text source_ext="c", destiny_ext=0, output_ext=0, dasm_ext=0;
int source_comment_style=';';

text token_types[]={ "End", "Number", "Symbol",
  "Text", "Name", "Variable" };

enum { T_END, T_NUMBER, T_SYMBOL, T_TEXT,
  T_NAME,  T_VARIABLE };

void set_source(text s) {
  last_source=source, source=s, source_p=s;
}

text get_string(text t, char quote) {
  int i;
  text p=t, tp=token;
  p=skip_space(p);
  if (*p==quote) {       // skip "string"
    for (i=0, p++; *p
      and i<255 and not is_return(*p);
      *tp++=*p++) {
      if (*p=='\\') {    // escape \x
        if (p[1]==quote) // \" or \'
          p+=2;
        else
          p++;
      }
      *tp=0;
      if (i>=255) {
        return 0;
      }
      if (*p==quote) { // end
        text z=skip_all(p+1);
        if (*z==quote) {
          p=z+1;
          continue;
        }
        return p+1;
      }
    }
  }
  return p+1;
}

// copy next token and advance. first,
// skip preceding whitespace and comments.
// return advanced address in source or
// 0 if end/*source=0

int get_token_x(text token) {
  int i=0, c=0, negate=0;
  text p=source;
  if (!token)
    return 0;
  token[0]=0;
  token_type=T_END;
  if (!p or !*p) {
    source=p;
    return 0;
  }
  p=skip_all(p);
  // p=skip_x(p);
  if (!p or !*p) {
    source=p;
    return 0;
  }
  c=*p;
  if (is_number(c)) { // number
    get_token_number1:
    token_type=T_NUMBER;
    if (*p=='0' and (p[1]=='x' // hexadecimal
      or p[1]=='X')) {
      for (i=0, p+=2; is_hex(*p)
        and i<255; token[i++]=*p++);
      token[i]=0;
      token_value_i=t2h(token);
    }
    else if (*p=='0' and (p[1]=='x' // binary
      or p[1]=='b')) {
      for (i=0, p+=2; (*p=='1' or *p=='0')
        and i<255; token[i++]=*p++);
      token[i]=0;
      token_value_i=t2b(token);
    }
    else { // decimal
      for (i=0; is_number(*p) and i<255;
        token[i++]=*p++);
      token[i]=0;
      if (*p=='b')
        p++, token_value_i=t2b(token);
      else if (*p=='h')
        p++, token_value_i=t2h(token);
      else
        token_value_i=t2u(token);
    }
    if (negate) {
      token_value_i=-token_value_i;
    }
    if (token[0]=='0')
      token_value_i=0;
    else
      i2t(token_value_i, token);
    token_value_type=T_NUMBER;
  }
  else if (is_name(c)) {
    token_type=T_NAME;
    for (i=0; is_name_c(*p) and i<255;
      token[i++]=*p++);
    token[i]=0;
  }
  else if (is_symbol(c)) {
    if (c=='-' and is_number(p[1])) {
      p++, c=*p;
      negate=1;
      goto get_token_number1;
    }
    if (c=='"' or c=='\'') {
      token_type=T_TEXT;
      p=get_string(p, c);
      if (!p) {
        source=0;
        return 0;
      }
      token_value_type=T_TEXT;
    }
    else {
      token_type=T_SYMBOL;
      token[0]=*p++, token[1]=0;
    }
  }
  if (i>=255)
    token_type=T_END;
  source=p;
  return token_type;
}

int get_token_f() {
  return get_token_x(token);
}

int (*get_token)()=get_token_f;

#define get_token_z get_token_from

text get_token_from(text tk, text s) {
  text p=source, t;
  set_source(s);
  get_token_x(tk);
  t=source;
  set_source(p);
  return t;
}

#define token_equal(t) text_equal(token, t)