//////////////////// PRINT/X /////////////////////

// a custom "s/printf" that supports binary

// %%      = one %
// %r      = return
// %0      = alignment: %08h, %032b
// %.      = precision: %.7f
// %s/%t   = "text"/"string"
// %c      = 'c'haracter
// %u      = unsigned 32BIT decimal
// %i/%d   = signed 32BIT decimal
// %x/X/%h = hexadecimal. uppercase
// %b      = binary: 1010b = 10/0xA
// %f      = double floating point
// %.2f    = with precision

// written in only a few lines! one of the most
// useful functions for text/string processing

text print(text p, text t, ...) {
  int n, c, align;
  text q;
  va_list va;
  va_start(va, t);
  align=0;
  while (*t) { // while text, until end 0
    c=*t;
    if (c==0xA) { // convert returns \n
      *p++=0xD, // inside "strings\n"
      *p++=0xA,
      t++;
      continue;
    }
    if (c!='%') { // copy next character
      *p++=*t++; // if not %
      continue;
    }
    t++, c=*t;
    if (c=='%') { // use %% for one %
      *p++='%', t++;
      continue;
    }
    if (c=='r') { // %r = return
      *p++=0xD;
      *p++=0xA, t++;
      continue;
    }
    if (c=='0') { // alignment: %08b
      t++;
      if (!is_number(*t)) { // error
        *t++='?';
        break;
      }
      if (!is_number(t[1])) // single digit?
        align=*t++-'0';
      else
        align=(t[1]-'0')+ // 2 decimal digits
          ((t[0]-'0')*10),
          t+=2;
      c=*t;
    }
    if (c=='t' or c=='s') { // "text/string"
      q=va_arg(va, text);
      n=text_n(q);
      while (align-n>0) // align with spaces?
        *p++=' ', align--;
      p=text_copy(p, q);
      t++;
      align=0;
      continue;
    }
    if (c=='.') { // precision: %.4f
      t++;
      if (!is_number(*t)) { // error
        *t++='?';
        break;
      }
      if (!is_number(t[1])) // single digit?
        align=*t++-'0';
      else
        align=(t[1]-'0')+ // 2 decimal digits
          ((t[0]-'0')*10),
          t+=2;
      c=*t;
    }
    if (c=='f') { // double
      double f=va_arg(va, double);
      p=f2ta(f, p, align);
      t++;
      align=0;
      continue;
    }
    n=va_arg(va, int); // get number
    if (c=='c') { // character
      *p++=n, t++;
      align=0;
      continue;
    }
    if (c=='u') // convert integer to text
      p=u2ta(n, p, align);
    else if (c=='i' or c=='d') // signed/int
      p=i2ta(n, p, align);
    else if (c=='x' or // hexadecimal
      c=='X' or c=='h')
      p=h2ta(n, p, align);
    else if (c=='b') // binary
      p=b2ta(n, p, align);
    else
      *p++='?'; // unrecognized suffix
    align=0;
    t++;
    continue;
  }
  *p=0;
  va_end(va);
  return p;
}

/* example: printf alternative. display "text" to console.

char my_console[1024];

#define my_printf(p...) \
  print(my_console, p), printf(my_console)

notice macro with variable arguments. syntax:

#define call_printf(p...) printf(p)
*/