/* EZC LIBRARY. BY STARPOWER/MYSTERI/OUS.
    __  ___         __          _
  /  |/  /_ _____ / /____ ____(_)
 / /|_/ / // (_-<  __/ -_) __/ /
/_/  /_/\_, /___/\__/\__/_/ /_/
       /___/ (C) 2016-2023+, KID-7/77 */

// c type lookup table. fast identification

/*
C_NULL     = 00000000b ; 0
C_NUMBER   = 00000001b ; 0-9
C_UPPER    = 00000010b ; A-Z
C_ALPHA    = 00000100b ; A-Z, a-z
C_NAME     = 00001000b ; A-Z, a-z, _, . (begins)
C_NAME_C   = 00010000b ; A-Z, a-z, 0-9, _, . (contains)
C_SYMBOL   = 00100000b ; all symbols
C_SPACE    = 01000000b ; ' ', '/t'
C_RETURN   = 10000000b ; 0Dh, 0Ah
C_IGNORE   = 11111111b ; everything else
C_KEYWORD  = 1XXXXXXXb ; keyword (set font/color/etc)
*/

char clt[]={
  0x00,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,
  0xFF,0x40,0x80,0xFF,0xFF,0x80,0xFF,0xFF,
  0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,
  0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,
  0x40,0x20,0x20,0x20,0x20,0x20,0x20,0x20,
  0x20,0x20,0x20,0x20,0x20,0x20,0x38,0x20,
  0x15,0x15,0x15,0x15,0x15,0x15,0x15,0x15,
  0x15,0x15,0x20,0x20,0x20,0x20,0x20,0x20,
  0x20,0x1E,0x1E,0x1E,0x1E,0x1E,0x1E,0x1E,
  0x1E,0x1E,0x1E,0x1E,0x1E,0x1E,0x1E,0x1E,
  0x1E,0x1E,0x1E,0x1E,0x1E,0x1E,0x1E,0x1E,
  0x1E,0x1E,0x1E,0x20,0x20,0x20,0x20,0x38,
  0x20,0x1C,0x1C,0x1C,0x1C,0x1C,0x1C,0x1C,
  0x1C,0x1C,0x1C,0x1C,0x1C,0x1C,0x1C,0x1C,
  0x1C,0x1C,0x1C,0x1C,0x1C,0x1C,0x1C,0x1C,
  0x1C,0x1C,0x1C,0x20,0x20,0x20,0x20,0xFF
};

enum {
  C_NULL=0, C_NUMBER=1, C_UPPER=2,
  C_ALPHA=4, C_NAME=8, C_NAME_C=16,
  C_SYMBOL=32, C_SPACE=64,
  C_RETURN=128, C_IGNORE=256
};

enum {
  C_ALPHA_N=C_ALPHA|C_NUMBER,
  C_VISIBLE=C_ALPHA_N|C_SYMBOL,
  C_WHITE=C_SPACE|C_RETURN,
  C_BLANK=C_WHITE|C_IGNORE,
  C_END=C_WHITE|C_SYMBOL
};

// is character of type?

int is(char c, int type) { return clt[c]&type; }

#define is_number(c) is(c, C_NUMBER)
#define is_upper(c) is(c, C_UPPER)
#define is_alpha(c) is(c, C_ALPHA)
#define is_alpha_n(c) is(c, C_ALPHA_N)
#define is_name(c) is_alpha(c) or c=='_'
#define is_name_c(c) (is_alpha_n(c) or c=='_' or c=='.')
#define is_symbol(c) is(c, C_SYMBOL)
#define is_slash(c) (c=='/' or c=='\\')
#define is_space(c) is(c, C_SPACE)
#define is_return(c) is(c, C_RETURN)
#define is_white(c) is(c, C_WHITE)
#define is_visible(c) (c>=33 and c<=126)
#define is_end(c) (!c or is_return(c))

int is_letter(int c) {
  return (c>='a' and c<='z') or
    (c>='A' and c<='Z');
}

extern text text_find_i(text, char);

int is_vowel(int c) {
  return (int) text_find_i("aeiou", c);
}

int is_consonant(int c) {
  return (is_letter(c) and !is_vowel(c));
}

#define is_bin(c) (c=='0' or c=='1')

int is_hex(int c) {
  return (c>='0' and c<='9') or
    (c>='a' and c<='f') or (c>='A' and c<='F');
}

// create clt[] lookup table. output c_table.txt

#ifdef CREATE_C_TABLE

text clt_symbols="_.?;:'\",~!@#$%" \
  "^&*()[]{}=+-<>/\\|`";

int create_c_table() {
  int c;
  char t[32];
  byte type;
  if (!create_file("c_table.txt"))
    return 0;
  write_text("char clt[]={\r\n  ");
  for (c=0; c<128; c++) {
    type=C_NULL, t[0]=0;
    if (c>='0' and c<='9')
      type|=C_NUMBER|C_ALPHA|C_NAME_C;
    else if ((c>='A' and c<='Z') or
      (c>='a' and c<='z')) {
      type|=C_ALPHA|C_NAME|C_NAME_C;
      if (c>='A' and c<='Z')
        type|=C_UPPER;
    }
    else if (text_find(clt_symbols, c)) {
      type|=C_SYMBOL;
      if (c=='_' or c=='.')
        type|=C_NAME|C_NAME_C;
    }
    else if (c==' ' or c=='\t')
      type|=C_SPACE;
    else if (c==0xD or c==0xA)
      type|=C_RETURN;
    else if (c)
      type=0xFF;
    if (type>0xF)
      print(t, "0x%x", type);
    else
      print(t, "0x0%x", type);
    write_text(t);
    if (c!=127)
      write_text(",");
    if ((c+1)%8==0) {
      write_text("\r\n");
      if (c!=127)
        write_text("  ");
    }
  }
  write_text("};");
  close_file();
  return 1;
}

#endif