///////////////////// TOOLBAR ////////////////////

object {
  uint tag, id,
    type, state, focus;
  int w, h, n,
    ix, iy, iw, ih,
    select, click;
  BOX box;
  ARRAY icons; // ICONs[]
  text *names, *notes;
} TOOLBAR;

int create_toolbar(TOOLBAR *tool, BOX *box, int n,
  text *names, text *notes) {
  if (!array_new(&tool->icons, sizeof(ICON), n))
    return 0;
  array_erase(&tool->icons);
  tool->box=*box, tool->n=n, tool->focus=1;
  tool->ix=tool->iy=4; tool->w=n, tool->h=1;
  tool->iw=tool->ih=0, tool->select=-1, tool->click=-1;
  tool->names=names, tool->notes=notes;
  control_memory_n++;
  control_memory+=sizeof(TOOLBAR)+
    (n*sizeof(ICON));
  return 1;
}

int load_toolbar(TOOLBAR *tool) {
  int i;
  char name[256];
  ICON *p;
  for (i=0; i<tool->icons.n; i++) {
    p=array_index(&tool->icons, i);
    p->state=ICON_ACTIVE;
    if (!load_icon(p, tool->names[i])) {
      bug("Error loading icon: %s",
        tool->names[i]);
      return 0;
    }
  }
  tool->iw=p->image.w, tool->ih=p->image.h;
  return 1;
}

void get_toolbar_box(TOOLBAR *tool, BOX *box) {
  box->x=tool->box.x, box->y=tool->box.y,
  box->w=tool->w, box->h=tool->h;
}

ICON *get_toolbar_icon(TOOLBAR *tool, uint i) {
  if (i>=tool->icons.n)
    return 0;
  return array_index(&tool->icons, i);
}

void enable_icon(TOOLBAR *tool, uint i) {
  ICON *p=get_toolbar_icon(tool, i);
  if (p)
    p->state&=~ICON_DISABLED;
}

void disable_icon(TOOLBAR *tool, uint i) {
  ICON *p=get_toolbar_icon(tool, i);
  if (p)
    p->state|=ICON_DISABLED;
}

void draw_toolbar(TOOLBAR *tool) {
  int i, j, k, x, y, enabled,
    tx=tool->box.x, ty=tool->box.y,
    ix=tool->ix, iy=tool->iy,
    iw=tool->iw, ih=tool->ih;
  text t, *notes=tool->notes;
  ICON *p;
  BOX box, box2;
  color c=BLACK, fc=0x202020;
  set_box(&box, tx, ty, tool->n*iw, ih+8);
  tool->select=-1;
  if (tool->h==1) { // horizontal
    for (i=0; i<tool->n; i++) {
      p=get_toolbar_icon(tool, i);
      j=tx+(i*(iw+ix))+(ix*2);
      set_box(&box, j, ty, iw, ih);
      move_icon(p, box.x, box.y);
      t=0;
      if (select_box(&box)) {
        tool->select=i;
        get_image_box(&p->image, &box);
        box.x-=2, box.y-=2, box.w+=4, box.h+=4;
        enabled=!(p->state&ICON_DISABLED);
        if (enabled) {
          box.x-=3, box.y-=3, box.w+=6, box.h+=6;
          draw_shade(&box, BLACK, BLUE, 0xAAAAFF);
          if (notes)
            t=notes[i];
        }
        else {
          draw_outline(&box, 0x202020);
          t=0, tool->select=-1;
        }
        if (t)
          draw_caption_x(t);
      }
      draw_icon(p);
    }
  }
  else { // vertical
    for (y=0, i=0; y<tool->h; y++) {
      for (x=0; x<tool->w and i<tool->n; x++, i++) {
        p=get_toolbar_icon(tool, i);
        set_box(&box,
          tx+(x*(iw+ix))+(ix*2),
          ty+(y*(ih+iy))+(iy*2),
          iw, ih);
        move_icon(p, box.x, box.y);
        t=0;
        if (select_box(&box)) {
          tool->select=i;
          get_image_box(&p->image, &box);
          box.x-=2, box.y-=2, box.w+=4, box.h+=4;
          enabled=!(p->state&ICON_DISABLED);
          if (enabled) {
            draw_shade(&box, GRAY75, WHITE, WHITE);
            if (notes)
              t=notes[i];
          }
          else {
            draw_outline(&box, 0x202020);
            t=0, tool->select=-1;
          }
          if (t)
            draw_caption_x(t);
        }
        draw_icon(p);
      }
    }
  }
}

int input_toolbar(TOOLBAR *tool) {
  int i, x=tool->box.x, y=tool->box.y,
    ix=tool->ix, iy=tool->iy,
    iw=tool->iw, ih=tool->ih;
  BOX box;
  ICON *p;
  tool->select=-1;
  if (tool->h==1) {
    for (i=0; i<tool->n; i++) {
      p=array_index(&tool->icons, i);
      set_box(&box,
        x+(i*(iw+ix))+ix,
        y, iw, ih);
      if (select_box(&box)) {
        tool->select=i;
        if (mouse_1)
          tool->click=i;
        return 1;
      }
    }
  }
  else {
    for (y=0, i=0; y<tool->h; y++) {
      for (x=0; x<tool->w and i<tool->n; x++, i++) {
        p=array_index(&tool->icons, i);
        set_box(&box,
          x+(x*(iw+ix))+ix,
          y+(y*(ih+iy))+iy,
          iw, ih);
        if (select_box(&box)) {
          tool->select=i;
          if (mouse_1)
            tool->click=i;
          return 1;
        }
      }
    }
  }
  return 0;
}