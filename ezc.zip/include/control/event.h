//////////////////// EVENTS //////////////////////

object {
  uint id, icon_id;
  text name, help, keys;
  void *p;
  int (*fp)(void *);
} EVENT;

enum {
  ID_NONE,
  ID_FILE_MENU, ID_FILE_RECENT, ID_FILE_NEW,
  ID_FILE_OPEN, ID_FILE_SAVE, ID_FILE_SAVE_AS,
  ID_FILE_SAVE_ALL, ID_FILE_CLOSE, ID_FILE_CLOSE_ALL,
  ID_FILE_CONVERT, ID_FILE_PRINT, ID_FILE_PUBLISH,
  ID_FILE_EXIT,
  ID_FILE_RECENT1, ID_FILE_RECENT2, ID_FILE_RECENT3,
  ID_FILE_RECENT4, ID_FILE_RECENT5, ID_FILE_RECENT6,
  ID_FILE_RECENT7,
  ID_EDIT_MENU, ID_EDIT_MENU_POP, ID_EDIT_UNDO,
  ID_EDIT_REDO, ID_EDIT_CUT, ID_EDIT_COPY, ID_EDIT_PASTE,
  ID_EDIT_INSERT, ID_EDIT_PASTE_NEW,
  ID_EDIT_SELECT_ALL, ID_EDIT_DELETE, ID_EDIT_SEARCH,
  ID_EDIT_REPLACE, ID_EDIT_DEFINITION, ID_EDIT_CONVERT,
  ID_EDIT_PARSE, ID_EDIT_COMMENT, ID_EDIT_CASE,
  ID_EDIT_COLORS, ID_EDIT_KEYWORDS, ID_EDIT_EDITOR,
  ID_EDIT_SETTINGS,
  ID_EDIT_FONT, ID_EDIT_FONT1, ID_EDIT_FONT2,
  ID_EDIT_FONT3, ID_EDIT_FONT4, ID_EDIT_FONT5,
  ID_EDIT_FONT6, ID_EDIT_FONT7, ID_EDIT_FONT8,
  ID_EDIT_FONT9, ID_EDIT_FONT10, ID_EDIT_FONT11,
  ID_EDIT_FONT12, ID_EDIT_FONT13, ID_EDIT_FONT14,
  ID_EDIT_FONT15, ID_EDIT_THEME, ID_EDIT_THEME1,
  ID_EDIT_THEME2, ID_EDIT_THEME3, ID_EDIT_THEME4,
  ID_EDIT_THEME5, ID_EDIT_THEME6, ID_EDIT_THEME7,
  ID_EDIT_THEME8, ID_EDIT_THEME9, ID_EDIT_THEME10,
  ID_EDIT_THEME11, ID_EDIT_THEME12, ID_EDIT_THEME13,
  ID_PARSE_MENU, ID_PARSE_MENU_POP, ID_PARSE_SCRIPT,
  ID_INDENT_MENU_POP,
  ID_PARSE_INDENT_L, ID_PARSE_INDENT_R, ID_PARSE_INDENT_JUSTIFY,
  ID_PARSE_UPPERCASE, ID_PARSE_LOWERCASE, ID_PARSE_TITLE_CASE,
  ID_PARSE_PREFIX, ID_PARSE_SUFFIX, ID_PARSE_STRINGS,
  ID_PARSE_NAMES, ID_PARSE_SEPARATE, ID_PARSE_ORGANIZE,
  ID_PARSE_COUNT, ID_PARSE_ABAKIS, ID_PARSE_C, ID_PARSE_TABS,
  ID_PARSE_INSERT_ARROWS, ID_PARSE_REMOVE_ARROWS,
  ID_COMMENT, ID_COMMENT_MENU_POP, ID_UNCOMMENT,
  ID_ALIGN_COMMENTS, ID_REMOVE_COMMENTS,
  ID_CODE_MENU, ID_CODE_RUN, ID_CODE_DEBUG, ID_CODE_DASM,
  ID_CODE_PREPROCESS,
  ID_SOUL_MENU, ID_SOUL_OPEN, ID_SOUL_NEW, ID_SOUL_SEARCH,
  ID_SOUL_COPY, ID_SOUL_COPY_POP, ID_SOUL_COPY_TEXT, ID_SOUL_COPY_SCRIPT,
  ID_SOUL_COPY_IMAGE, ID_SOUL_COPY_CODE, ID_SOUL_COPY_ELEMENT,
  ID_SOUL_COPY_LINK, ID_SOUL_COPY_TABLE, ID_SOUL_COPY_ROW,
  ID_SOUL_COPY_COLUMN, ID_SOUL_COPY_SLASH_F, ID_SOUL_COPY_SLASH_B,
  ID_SOUL_COPY_SLASH_B2, ID_SOUL_VIEW_SOURCE, ID_SOUL_SAVE,
  ID_SOUL_HOME, ID_SOUL_SITE, ID_SOUL_BACKWARDS, ID_SOUL_FORWARDS,
  ID_SOUL_RELOAD, ID_SOUL_BOOKMARKS, ID_SOUL_ADD_BOOKMARK,
  ID_SOUL_EDIT_BOOKMARKS, ID_SOUL_BOOKMARK1, ID_SOUL_BOOKMARK2,
  ID_SOUL_BOOKMARK3, ID_SOUL_BOOKMARK4, ID_SOUL_BOOKMARK5,
  ID_SOUL_BOOKMARK6, ID_SOUL_BOOKMARK7,
  ID_SOUL_DOWNLOADS, ID_SOUL_DEBUG,
  ID_HELP_MENU, ID_HELP_HELP, ID_HELP_INDEX,
  ID_HELP_SEARCH, ID_HELP_EDITOR, ID_HELP_LANGUAGE,
  ID_HELP_LIBRARY, ID_HELP_EXAMPLES, ID_HELP_TUTORIALS,
  ID_HELP_KEYS, ID_HELP_ABOUT,
  ID_IMAGE_MENU, ID_IMAGE_ADJUST, ID_IMAGE_SIZE,
  ID_IMAGE_ROTATE_L, ID_IMAGE_ROTATE_R,
  ID_IMAGE_FLIP_H, ID_IMAGE_FLIP_V, ID_IMAGE_CONVERT,
  ID_IMAGE_EFFECT,
  ID_OBJECT_MENU, ID_OBJECT_FORTH, ID_OBJECT_TOP,
  ID_OBJECT_BACK, ID_OBJECT_BOTTOM, ID_OBJECT_UP,
  ID_OBJECT_UP_RIGHT, ID_OBJECT_RIGHT, ID_OBJECT_DOWN_RIGHT,
  ID_OBJECT_DOWN, ID_OBJECT_DOWN_LEFT, ID_OBJECT_LEFT,
  ID_OBJECT_UP_LEFT, ID_OBJECT_IMAGE, ID_OBJECT_FONT,
  ID_OBJECT_CURSOR, ID_OBJECT_BOOK, ID_OBJECT_PAGE,
  ID_OBJECT_SPRITE, ID_OBJECT_TEXTURE, ID_OBJECT_AUDIO,
  ID_OBJECT_VIDEO,
  ID_UTILITY_MENU, ID_UTILITY_CALCULATOR, ID_UTILITY_HEX,
  ID_UTILITY_ASCII, ID_UTILITY_CHARACTERS,
  ID_UTILITY_COLOR, ID_UTILITY_PALETTE, ID_UTILITY_ICON,
  ID_UTILITY_FONT, ID_UTILITY_IMAGE, ID_UTILITY_SPRITE,
  ID_UTILITY_ACTOR, ID_UTILITY_BOOK, ID_UTILITY_CONTROL,
  ID_WIZARD_MENU, ID_WIZARD_VARIABLE, ID_WIZARD_TEXT,
  ID_WIZARD_ARRAY, ID_WIZARD_FUNCTION, ID_WIZARD_LOOP,
  ID_WIZARD_STRUCTURE, ID_WIZARD_LOAD, ID_WIZARD_DRAW,
  ID_WIZARD_IMAGE, ID_WIZARD_FONT, ID_WIZARD_PLAY,
  ID_WIZARD_INPUT, ID_WIZARD_KEY, ID_WIZARD_MOUSE,
  ID_WIZARD_GAMEPAD,
  ID_CONTROL_MENU2, ID_CONTROL_WINDOW, ID_CONTROL_FRAME,
  ID_CONTROL_GROUP, ID_CONTROL_BOX, ID_CONTROL_LABEL,
  ID_CONTROL_EDIT, ID_CONTROL_BUTTON,
  ID_CONTROL_CHECK, ID_CONTROL_CHOICE, ID_CONTROL_SWITCH,
  ID_CONTROL_GAUGE, ID_CONTROL_IMAGE, ID_CONTROL_COLOR,
  ID_CONTROL_CANVAS, ID_CONTROL_TOOLBAR, ID_CONTROL_MENU,
  ID_CONTROL_LISTBOX, ID_CONTROL_DROPBOX, ID_CONTROL_SWITCHBOX,
  ID_CONTROL_SCROLLBAR, ID_CONTROL_EXPLORER, ID_CONTROL_GALLERY
};

EVENT system_events[]={
  { ID_NONE, 0, "None" },
  { ID_FILE_MENU, 0,
    "[File]", "File Menu", "Alt+F" },
  { ID_FILE_RECENT, ICON_CLOCK,
    "Recent >", "Open Recent File" },
  { ID_FILE_NEW, ICON_NEW,
    "New", "Create New File", "Ctrl+N" },
  { ID_FILE_OPEN, ICON_OPEN,
    "Open", "Open File", "Ctrl+O" },
  { ID_FILE_SAVE, ICON_FILE,
    "Save", "Save File", "Ctrl+S" },
  { ID_FILE_SAVE_AS, ICON_FILE,
    "Save As", "Save File As...", "Ctrl+Alt+S" },
  { ID_FILE_SAVE_ALL, ICON_FILE,
    "Save All", "Save All", "Ctrl+Shift+S" },
  { ID_FILE_CLOSE, ICON_CLOSE,
    "Close", "Close File", "Ctrl+W" },
  { ID_FILE_CLOSE_ALL, ICON_CLOSE,
    "Close All", "Close All", "Ctrl+Shift+W" },
  { ID_FILE_CONVERT, ICON_A, "Convert >" },
  { ID_FILE_PRINT, ICON_NEW,
    "Print", 0, "Ctrl+P" },
  { ID_FILE_PUBLISH, ICON_WINDOW1, "Publish" },
  { ID_FILE_EXIT, ICON_EXIT,
    "Exit", "End program", "Alt+F4" },
  { ID_FILE_RECENT1, ICON_CODE,
    "File 1", "X", "X" },
  { ID_FILE_RECENT2, ICON_CODE,
    "File 2", "X", "X" },
  { ID_FILE_RECENT3, ICON_CODE,
    "File 3", "X", "X" },
  { ID_FILE_RECENT4, ICON_CODE,
    "File 4", "X", "X" },
  { ID_FILE_RECENT5, ICON_CODE,
    "File 5", "X", "X" },
  { ID_FILE_RECENT6, ICON_CODE,
    "File 6", "X", "X" },
  { ID_FILE_RECENT7, ICON_CODE,
    "File 7", "X", "X" },
  { ID_EDIT_MENU, 0,
    "[Edit]", "Edit Menu", "Alt+E" },
  { ID_EDIT_MENU_POP, 0,
    "Edit >", "Edit Menu", "Alt+E" },
  { ID_EDIT_UNDO, ICON_UNDO,
    "Undo", "Undo Action", "Ctrl+Z" },
  { ID_EDIT_REDO, ICON_REDO,
    "Redo", "Redo Action", "Ctrl+Y" },
  { ID_EDIT_CUT, ICON_CUT,
    "Cut", "Cut to Clipboard", "Ctrl+X" },
  { ID_EDIT_COPY, ICON_COPY,
    "Copy", "Copy to Clipboard", "Ctrl+C" },
  { ID_EDIT_PASTE, ICON_PASTE,
    "Paste", "Paste from Clipboard", "Ctrl+V" },
  { ID_EDIT_INSERT, ICON_PASTE,
    "Insert", "Paste with Increase" },
  { ID_EDIT_PASTE_NEW, ICON_PASTE,
    "Paste New", "Paste as New" },
  { ID_EDIT_SELECT_ALL, ICON_SELECT,
    "Select All", "Select All", "Ctrl+A" },
  { ID_EDIT_DELETE, ICON_DELETE,
    "Delete", "Delete", "Del" },
  { ID_EDIT_SEARCH, ICON_SEARCH,
    "Search", "Delete", "Ctrl+F" },
  { ID_EDIT_REPLACE, ICON_SEARCH,
    "Replace", "Delete", "Ctrl+H" },
  { ID_EDIT_DEFINITION, ICON_SEARCH,
    "Definition", "Search for Definition" },
  { ID_EDIT_CONVERT, ICON_A, "Convert >" },
  { ID_EDIT_PARSE, ICON_A, "Parse >" },
  { ID_EDIT_COMMENT, ICON_A, "Comment >" },
  { ID_EDIT_CASE, ICON_A, "Case" },
  { ID_EDIT_COLORS, ICON_COLORS, "Colors" },
  { ID_EDIT_KEYWORDS, ICON_A, "Keywords" },
  { ID_EDIT_EDITOR, ICON_A, "Editor" },
  { ID_EDIT_SETTINGS, ICON_GEAR, "Settings" },
  { ID_EDIT_FONT, ICON_A, "Font" },
  { ID_EDIT_FONT1, ICON_A, "Code_1" },
  { ID_EDIT_FONT2, ICON_A, "Code_2" },
  { ID_EDIT_FONT3, ICON_A, "Code_3" },
  { ID_EDIT_FONT4, ICON_A, "Code_4" },
  { ID_EDIT_FONT5, ICON_A, "Code_5" },
  { ID_EDIT_FONT6, ICON_A, "System_1" },
  { ID_EDIT_FONT7, ICON_A, "System_2" },
  { ID_EDIT_FONT8, ICON_A, "System_3" },
  { ID_EDIT_FONT9, ICON_A, "System_4" },
  { ID_EDIT_FONT10, ICON_A, "System_5" },
  { ID_EDIT_FONT11, ICON_A, "Console_1" },
  { ID_EDIT_FONT12, ICON_A, "Console_2" },
  { ID_EDIT_FONT13, ICON_A, "Console_3" },
  { ID_EDIT_FONT14, ICON_A, "Console_4" },
  { ID_EDIT_FONT15, ICON_A, "Console_5" },
  { ID_EDIT_THEME, ICON_COLOR, "Theme" },
  { ID_EDIT_THEME1, ICON_COLOR, "White" },
  { ID_EDIT_THEME2, ICON_COLOR, "White2" },
  { ID_EDIT_THEME3, ICON_COLOR, "Blue" },
  { ID_EDIT_THEME4, ICON_COLOR, "Blue2" },
  { ID_EDIT_THEME5, ICON_COLOR, "Blue3" },
  { ID_EDIT_THEME6, ICON_COLOR, "Night" },
  { ID_EDIT_THEME7, ICON_COLOR, "Night2" },
  { ID_EDIT_THEME8, ICON_COLOR, "Galaxy" },
  { ID_EDIT_THEME9, ICON_COLOR, "Galaxy2" },
  { ID_EDIT_THEME10, ICON_COLOR, "Black" },
  { ID_EDIT_THEME11, ICON_COLOR, "Black2" },
  { ID_EDIT_THEME12, ICON_COLOR, "Black3" },
  { ID_EDIT_THEME13, ICON_COLOR, "Alien" },
  { ID_PARSE_MENU, 0,
    "[Parse]", "Parse Menu" },
  { ID_PARSE_MENU_POP, 0,
    "Parse >", "Parse Menu" },
  { ID_PARSE_SCRIPT, 0,
    "Script...", "Script" },
  { ID_INDENT_MENU_POP, 0,
    "Indent >", "Indent Menu" },
  { ID_PARSE_INDENT_L, ICON_LEFT,
    "Indent--", "Decrease Indent--" },
  { ID_PARSE_INDENT_R, ICON_RIGHT,
    "Indent++", "Increase Indent++" },
  { ID_PARSE_INDENT_JUSTIFY, ICON_LEFT,
    "Justify", "Justify left" },
  { ID_PARSE_UPPERCASE, ICON_A,
    "Uppercase", "Convert to Uppercase" },
  { ID_PARSE_LOWERCASE, ICON_A,
    "Lowercase", "Convert to Lowercase" },
  { ID_PARSE_TITLE_CASE, ICON_A,
    "Title Case", "Convert to Title Case" },
  { ID_PARSE_PREFIX, ICON_A,
    "Prefix X_*", "Prefix X_*" },
  { ID_PARSE_SUFFIX, ICON_A,
    "Suffix *_X", "Suffix *_X" },
  { ID_PARSE_STRINGS, ICON_A,
    "'Strings' 2 Names", "Convert Strings to Names" },
  { ID_PARSE_NAMES, ICON_A,
    "Names 2 'Strings'", "Convert Names to Strings" },
  { ID_PARSE_SEPARATE, ICON_A,
    "Separate", "Separate" },
  { ID_PARSE_ORGANIZE, ICON_A,
    "Organize", "Organize" },
  { ID_PARSE_COUNT, ICON_A,
    "Count Names", "Count Names" },
  { ID_PARSE_ABAKIS, ICON_CODE,
    "Convert 2 Abakis", "Convert C to Abakis" },
  { ID_PARSE_C, ICON_CODE,
    "Convert 2 C", "Convert Abakis to C" },
  { ID_PARSE_TABS, ICON_A,
    "Tabs 2 Spaces", "Convert tabs to spaces" },
  { ID_PARSE_INSERT_ARROWS, ICON_A,
    "Convert <>", "Replace <> with <<>>" },
  { ID_PARSE_REMOVE_ARROWS, ICON_A,
    "Convert <<>>", "Replace <<>> with <>" },
  { ID_COMMENT, ICON_COMMENT,
    "Comment", "Comment" },
  { ID_COMMENT_MENU_POP, 0,
    "Comment >", "Comment Menu" },
  { ID_UNCOMMENT, ICON_COMMENT,
    "Uncomment", "Uncomment" },
  { ID_ALIGN_COMMENTS, ICON_COMMENT,
    "Align", "Align Comments" },
  { ID_REMOVE_COMMENTS, ICON_COMMENT,
    "Remove", "Remove Comments" },
  { ID_CODE_MENU, 0,
    "[Code]", "Code Menu" },
  { ID_CODE_RUN, ICON_RUN,
    "Run F1", "Execute", "F1" },
  { ID_CODE_DEBUG, ICON_DEBUG,
    "Debug F2", "Debug", "F3" },
  { ID_CODE_DASM, ICON_C,
    "DASM F3", "Disassemble", "F2" },
  { ID_CODE_PREPROCESS, ICON_A,
    "Process", "Preprocess" },
  { ID_SOUL_MENU, 0,
    "[Soul]", "Soul Menu" },
  { ID_SOUL_OPEN, ICON_OPEN,
    "Open", "Open" },
  { ID_SOUL_NEW, ICON_OPEN,
    "New", "Open New" },
  { ID_SOUL_SEARCH, ICON_SEARCH,
    "Search", "Search" },
  { ID_SOUL_COPY, ICON_COPY,
    "Copy", "Copy" },
  { ID_SOUL_COPY_POP, ICON_COPY,
    "Copy >", "Copy" },
  { ID_SOUL_COPY_TEXT, ICON_COPY,
    "Text", "Copy Text" },
  { ID_SOUL_COPY_SCRIPT, ICON_COPY,
    "<Script>", "Copy <Script>/<</>>" },
  { ID_SOUL_COPY_IMAGE, ICON_IMAGE,
    "Image", "Copy Image" },
  { ID_SOUL_COPY_CODE, ICON_CODE,
    "Code", "Copy Code" },
  { ID_SOUL_COPY_ELEMENT, ICON_CODE,
    "Element", "Copy <Code>" },
  { ID_SOUL_COPY_LINK, ICON_PLANET,
    "Link", "Copy Link" },
  { ID_SOUL_COPY_TABLE, ICON_TABLE,
    "Table", "Copy Table" },
  { ID_SOUL_COPY_ROW, ICON_ROW,
    "Row", "Copy Row" },
  { ID_SOUL_COPY_COLUMN, ICON_COLUMN,
    "Column", "Copy Column" },
  { ID_SOUL_COPY_SLASH_F, ICON_COPY,
    "As Name:/", "Copy" },
  { ID_SOUL_COPY_SLASH_B, ICON_COPY,
    "As Name:\\", "Copy" },
  { ID_SOUL_COPY_SLASH_B2, ICON_COPY,
    "As Name:\\\\", "Copy" },
  { ID_SOUL_VIEW_SOURCE, ICON_CODE,
    "Source", "View Source" },
  { ID_SOUL_SAVE, ICON_FILE,
    "Save", "Save Page" },
  { ID_SOUL_HOME, ICON_HOME,
    "Home", "INDEX.SOUL" },
  { ID_SOUL_SITE, ICON_PLANET,
    "Site", "Visit Site" },
  { ID_SOUL_BACKWARDS, ICON_LEFT,
    "Backwards", "Backwards" },
  { ID_SOUL_FORWARDS, ICON_RIGHT,
    "Forwards", "Forwards" },
  { ID_SOUL_RELOAD, ICON_REDO,
    "Reload", "Reload Page" },
  { ID_SOUL_BOOKMARKS, ICON_STAR,
    "Bookmarks", "Bookmarks" },
  { ID_SOUL_ADD_BOOKMARK, ICON_ADD,
    "Add", "Add Bookmark" },
  { ID_SOUL_EDIT_BOOKMARKS, ICON_CODE,
    "Edit", "Edit Bookmarks" },
  { ID_SOUL_BOOKMARK1, ICON_PLANET,
    "Bookmark 1", "Bookmark" },
  { ID_SOUL_BOOKMARK2, ICON_PLANET,
    "Bookmark 2", "Bookmark" },
  { ID_SOUL_BOOKMARK3, ICON_PLANET,
    "Bookmark 3", "Bookmark" },
  { ID_SOUL_BOOKMARK4, ICON_PLANET,
    "Bookmark 4", "Bookmark" },
  { ID_SOUL_BOOKMARK5, ICON_PLANET,
    "Bookmark 5", "Bookmark" },
  { ID_SOUL_BOOKMARK6, ICON_PLANET,
    "Bookmark 6", "Bookmark" },
  { ID_SOUL_BOOKMARK7, ICON_PLANET,
    "Bookmark 7", "Bookmark" },
  { ID_SOUL_DOWNLOADS, ICON_DOWN,
    "Downloads", "Downloads" },
  { ID_SOUL_DEBUG, ICON_DEBUG,
    "Debug", "Debug Page" },
  { ID_HELP_MENU, 0,
    "Help", "Help Menu", "Alt+H" },
  { ID_HELP_HELP, ICON_HELP,
    "Help", "Help" },
  { ID_HELP_INDEX, ICON_HELP, "Index", "Index" },
  { ID_HELP_SEARCH, ICON_SEARCH, "Search", "Search" },
  { ID_HELP_EDITOR, ICON_A, "Editor", "Editor" },
  { ID_HELP_LANGUAGE, ICON_A, "Language", "Language" },
  { ID_HELP_LIBRARY, ICON_BOOK, "Library", "Library" },
  { ID_HELP_EXAMPLES, ICON_COLOR, "Examples", "Examples" },
  { ID_HELP_TUTORIALS, ICON_A, "Tutorials", "Tutorials" },
  { ID_HELP_KEYS, ICON_KEYBOARD, "Keys", "Keyboard Shortcuts" },
  { ID_HELP_ABOUT, ICON_HELP, "About", "About" },
  { ID_IMAGE_MENU, 0,
    "[Image]", "Image Menu", "Alt+I" },
  { ID_IMAGE_ADJUST, ICON_ALPHA,
    "Adjust", "Adjust Light/Color", "Ctrl+I" },
  { ID_IMAGE_SIZE, ICON_SIZE, "Size" },
  { ID_IMAGE_ROTATE_L, ICON_ROTATE_L,
    "Rotate L", "Rotate Left" },
  { ID_IMAGE_ROTATE_R, ICON_ROTATE_R,
    "Rotate R", "Rotate Right" },
  { ID_IMAGE_FLIP_H, ICON_FLIP_H,
    "Flip H", "Flip Horizontal" },
  { ID_IMAGE_FLIP_V, ICON_FLIP_V,
    "Flip V", "Flip Vertical" },
  { ID_IMAGE_CONVERT, ICON_LIGHTNESS,
    "Convert" },
  { ID_IMAGE_EFFECT, ICON_STAR,
    "Effect", "Special Effects" },
  { ID_OBJECT_MENU, 0, "[Object]" },
  { ID_OBJECT_FORTH, ICON_BRING_FORTH, "Bring Forth" },
  { ID_OBJECT_TOP, ICON_BRING_TOP, "Bring Top" },
  { ID_OBJECT_BACK, ICON_SEND_BACK, "Send Back" },
  { ID_OBJECT_BOTTOM, ICON_SEND_BOTTOM, "Send Bottom" },
  { ID_OBJECT_UP, ICON_UP, "Up" },
  { ID_OBJECT_UP_RIGHT, ICON_UP_RIGHT, "Up Right" },
  { ID_OBJECT_RIGHT, ICON_RIGHT, "Right" },
  { ID_OBJECT_DOWN_RIGHT, ICON_DOWN_RIGHT, "Down Right" },
  { ID_OBJECT_DOWN, ICON_DOWN, "Down" },
  { ID_OBJECT_DOWN_LEFT, ICON_DOWN_LEFT, "Down Left" },
  { ID_OBJECT_LEFT, ICON_LEFT, "Left" },
  { ID_OBJECT_UP_LEFT, ICON_UP_LEFT, "Up Left" },
  { ID_OBJECT_IMAGE, ICON_IMAGE, "Image" },
  { ID_OBJECT_FONT, ICON_A, "Font" },
  { ID_OBJECT_CURSOR, ICON_CURSOR, "Cursor" },
  { ID_OBJECT_BOOK, ICON_BOOK, "Book" },
  { ID_OBJECT_PAGE, ICON_NEW, "Page" },
  { ID_OBJECT_SPRITE, ICON_KEY, "Sprite" },
  { ID_OBJECT_TEXTURE, ICON_MAP, "Texture" },
  { ID_OBJECT_AUDIO, ICON_DOT, "Audio" },
  { ID_OBJECT_VIDEO, ICON_VIDEO, "Video" },
  { ID_UTILITY_MENU, 0,
    "[Utility]" },
  { ID_UTILITY_CALCULATOR, ICON_CALCULATOR,
    "Calculator", "Calculator" },
  { ID_UTILITY_HEX, ICON_C,
    "Hex Editor", "Hex Viewer/Editor" },
  { ID_UTILITY_ASCII, ICON_A,
    "ASCII Table", "View ASCII Characters" },
  { ID_UTILITY_CHARACTERS, ICON_A,
    "My Characters", "View My Characters" },
  { ID_UTILITY_COLOR, ICON_COLOR,
    "Select Color", "Select Color" },
  { ID_UTILITY_PALETTE, ICON_MAP,
    "Palette Editor", "Palette Editor" },
  { ID_UTILITY_ICON, ICON_IMAGE,
    "Icon Viewer", "Icon Viewer" },
  { ID_UTILITY_FONT, ICON_A,
    "Font Viewer", "Font Viewer" },
  { ID_UTILITY_IMAGE, ICON_IMAGE,
    "Image Editor", "Image Editor" },
  { ID_UTILITY_SPRITE, ICON_KEY,
    "Sprite Viewer", "Animation Viewer" },
  { ID_UTILITY_ACTOR, ICON_KEY,
    "Actor Viewer", "Animation Viewer" },
  { ID_UTILITY_BOOK, ICON_BOOK,
    "Book Viewer", "Book Viewer" },
  { ID_UTILITY_CONTROL, ICON_WINDOW1,
    "Control Creator", "Visual Interface Creator" },
  { ID_WIZARD_MENU, 0, "[Wizard]", "Wizard", "F5" },
  { ID_WIZARD_VARIABLE, ICON_A, "Variable" },
  { ID_WIZARD_TEXT, ICON_A, "Text" },
  { ID_WIZARD_ARRAY, ICON_A, "Array" },
  { ID_WIZARD_FUNCTION, ICON_A, "Function" },
  { ID_WIZARD_LOOP, ICON_A, "Loop" },
  { ID_WIZARD_STRUCTURE, ICON_A, "Object" },
  { ID_WIZARD_LOAD, ICON_FOLDER, "Load" },
  { ID_WIZARD_DRAW, ICON_COLOR, "Draw" },
  { ID_WIZARD_IMAGE, ICON_IMAGE, "Image" },
  { ID_WIZARD_FONT, ICON_A, "Font" },
  { ID_WIZARD_PLAY, ICON_VIDEO, "Play" },
  { ID_WIZARD_INPUT, ICON_GAME, "Input" },
  { ID_WIZARD_KEY, ICON_KEYBOARD, "Key" },
  { ID_WIZARD_MOUSE, ICON_CURSOR, "Mouse" },
  { ID_WIZARD_GAMEPAD, ICON_GAME, "Gamepad" },
  { ID_CONTROL_MENU2, 0, "[Control]", "Controls" },
  { ID_CONTROL_WINDOW, ICON_WINDOW1, "Window" },
  { ID_CONTROL_FRAME, ICON_C1, "Frame" },
  { ID_CONTROL_GROUP, ICON_CGROUP, "Group" },
  { ID_CONTROL_BOX, ICON_BOX, "Box" },
  { ID_CONTROL_LABEL, ICON_CTEXT, "Label" },
  { ID_CONTROL_EDIT, ICON_CEDIT, "Edit" },
  { ID_CONTROL_BUTTON, ICON_CBUTTON, "Button" },
  { ID_CONTROL_CHECK, ICON_CHECK, "Check" },
  { ID_CONTROL_CHOICE, ICON_CHOICE, "Choice" },
  { ID_CONTROL_SWITCH, ICON_CSWITCH, "Switch" },
  { ID_CONTROL_GAUGE, ICON_CGAUGE, "Gauge" },
  { ID_CONTROL_IMAGE, ICON_IMAGE, "Image" },
  { ID_CONTROL_COLOR, ICON_COLOR, "Color" },
  { ID_CONTROL_CANVAS, ICON_C2, "Canvas" },
  { ID_CONTROL_TOOLBAR, ICON_CTOOL, "Toolbar" },
  { ID_CONTROL_MENU, ICON_CMENU, "Menu" },
  { ID_CONTROL_LISTBOX, ICON_CLIST, "Listbox" },
  { ID_CONTROL_DROPBOX, ICON_CDROP, "Dropbox" },
  { ID_CONTROL_SWITCHBOX, ICON_CSWITCH, "Switchbox" },
  { ID_CONTROL_SCROLLBAR, ICON_CSCROLL, "Scrollbar" },
  { ID_CONTROL_EXPLORER, ICON_WINDOW2, "Explorer" },
  { ID_CONTROL_GALLERY, ICON_MAP, "Gallery" }
};


int n_system_events=number_of(system_events);

EVENT *get_event(uint id) {
  int i, n=n_system_events;
  EVENT *p;
  for (i=0; i<n; i++) {
    p=&system_events[i];
    if (p->id==id)
      return p;
  }
  return 0;
}

#endif

///////////////// SYSTEM MEDIA ///////////////////

// predefined media arrays that are managed
// internally. easily reusable and accessible
// by index, id, or name. programs that use
// this only need to specify the id or name
// of a standard icon, font, cursor, etc, or
// the id or name of a predefined event
// that uses an icon. this allows many different
// controls to share the same icons

// ARRAY system_fonts, system_icons,
//   system_cursors, system_images, system_sounds;

// system icons...

#define N_SYSTEM_ICONS number_of(icon_names_24)

ARRAY system_icons; // ICONs[] (IMAGE.H)
int n_system_icons_used=0;

ICON *get_system_icon(int id);
ICON *get_system_icon_i(int i);
int create_system_icons();
int set_icon_used(int id, int used);
int use_these_icons(int ids[], int n);
int load_system_icons();

// create system icons array, and set all icons
// as not "used". do this first in event_create

int create_system_icons() {
  int i, n=N_SYSTEM_ICONS;
  ICON *icon;
  ARRAY *icons=&system_icons;
  if (!array_new(icons, sizeof(ICON), n))
    return 0;
  array_erase(icons);
  for (i=0; i<n; i++) {
    icon=get_system_icon_i(i);
    icon->used=NO;
  }
  return 1;
}

// set icon as "used" from event id

int set_icon_used(int id, int used) {
  ICON *icon=(ICON *) array_index(&system_icons,
    system_events[id].icon_id);
  icon->used=used;
  return 1;
}

// set "used" icons from event ids.
// do this after create_system_icons()

int use_these_icons(int ids[], int n) {
  for (int i=0; i<n; i++)
    set_icon_used(ids[i], 1);
  return 1;
}

// load system icons that have been "used".
// do this last

int load_system_icons() {
  int i, n=N_SYSTEM_ICONS;
  ICON *icon;
  for (i=0; i<n; i++) {
    icon=get_system_icon_i(i);
    if (!icon)
      return 0;
    if (!icon->used)
      continue;
    text name=icon_names_24[i];
    if (!load_icon(icon, name)) {
      bug("Error loading icon: %s", name);
      return 0;
    }
  }
  return 1;
}

// get system icon by icon_id or index
// or event_id

ICON *get_system_icon(int id) {
  int i, n=N_SYSTEM_ICONS;
  ICON *icon;
  for (i=0; i<n; i++) {
    icon=get_system_icon_i(i);
    if (icon->id==id)
      return icon;
  }
  return 0;
}

ICON *get_system_icon_i(int i) {
  return (ICON *) array_index(&system_icons, i);
}

ICON *get_event_icon(int id) {
  ICON *icon=(ICON *) array_index(&system_icons,
    system_events[id].icon_id);
  return icon;
}

/* usage: in event_create...

  set_icon_folder("media/icon/24");
  create_system_icons();
  use_these_icons(file_menu_ids, number_of(file_menu_ids));
  load_system_icons();

// menus and toolbars can just specify an
// array of names to use from each section.
// icons will be loaded once, and never again,
// then reused in all controls. "Name" must
// be a predefined EVENT_NAME with optional
// ICON_NAME, description and key shortcut

// easy menu script

create_my_menu(&menu1, 1000, "File: New, Open, Save, Exit");
create_my_toolbar(&tools1, 2000, "File: New, Open, Save, " \
  "Edit: Undo, Redo, Cut, Copy, Paste");

// then define event_name() prototypes

int event_file_new(), event_file_open(),
  event_file_save(), event_file_exit();

// then respond to input. event_ids will be
// the same for all controls that use them

event_input
  int e=event_id;
  if (event_mouse_down) {
    if (e==EVENT_FILE_NEW)
      event_file_new();
    else if (e==EVENT_FILE_OPEN)
      event_file_open();
    else if (e==EVENT_FILE_SAVE)
      event_file_save();
    else if (e==EVENT_FILE_EXIT)
      event_file_exit();
  }
ende
*/

/* OLD CUSTOM RESOURCE SCRIPT...

; VIEW

EVENT
 ID.VIEW, ICON.EYE, 0, 'View', 0,
 ID.ZOOM.IN, ICON.ZOOM.IN, K.CTRL+K.UP,
  'Zoom In', 0,
 ID.ZOOM.OUT, ICON.ZOOM.OUT, K.CTRL+K.DOWN,
  'Zoom Out', 0,
 ID.VIEW.ACTUAL, ICON.W, 0, 'Actual, 100%', 0,
 ID.VIEW.FIT, ICON.W, 0, 'All, Entire', 0,
 ID.VIEW.FULL, ICON.W, 0, 'Full Screen', 0,
 ID.VIEW.TILE, ICON.W4, 0, 'Arrange', 0,
 ID.VIEW.CASCADE, ICON.W3, 0, 'Cascade', 0

; ARRANGE

EVENT
 ID.ARRANGE, ICON.W2, 0, 'Arrange', 0,
 ID.ARRANGE.TYPE, ICON.A, 0, 'Type', 0,
 ID.ARRANGE.NAME, ICON.A, 0, 'Name', 0,
 ID.ARRANGE.SIZE, ICON.A, 0, 'Size', 0,
 ID.ARRANGE.DATE, ICON.CLOCK, 0, 'Date', 0,
 ID.ARRANGE.PRICE, ICON.MONEY, 0, 'Price', 0,
 ID.ARRANGE.MATCH, ICON.CODE, 0, 'Match', 0,
 ID.ARRANGE.RECENT, ICON.CLOCK, 0, 'Recent', 0,
 ID.ARRANGE.POP, ICON.USER, 0, 'Popular', 0

; ART

EVENT
 ID.ART.PEN, ICON.DOT, 0, 'Pen', 0,
 ID.ART.BRUSH, ICON.DOT, 0, 'Brush', 0,
 ID.ART.AIRBRUSH, ICON.DOT, 0, 'Airbrush', 0,
 ID.ART.SMEAR, ICON.DOT, 0, 'Smear', 0,
 ID.ART.BUCKET, ICON.DOT, 0, 'Bucket', 0,
 ID.ART.DROP, ICON.DOT, 0, 'Drop', 0,
 ID.ART.MASK, ICON.SELECT, 0, 'Mask', 0

; IMAGE

EVENT
 ID.IMAGE, ICON.IMAGE, 0, 'Image', 0,
 ID.IMAGE.EFFECT, ICON.MOVIE, 0,
  'Effect', 0,
 ID.IMAGE.LIGHT, ICON.LIGHT, 0,
  'Lightness', 0,
 ID.IMAGE.COLOR, ICON.COLOR, 0,
  'Color R/G/B', 0,
 ID.IMAGE.HUE, ICON.ALPHA, 0,
  'Color Shift', 0,
 ID.IMAGE.MAP, ICON.COLORIZE, 0,
  'Color Map', 0,
 ID.IMAGE.CONVERT, ICON.COLOR, 0,
  'Convert BPP', 0,
 ID.IMAGE.GRAY, ICON.GRAY, 0,
  'Saturation', 0,
 ID.IMAGE.GRAYS, ICON.GRAYS, 0,
  'Grayscale', 0,
 ID.IMAGE.INVERT.C, ICON.INVERT.C, 0,
  'Invert Color', 0,
 ID.IMAGE.ENHANCE, ICON.IMAGE, 0,
  'Enhance', 0,
 ID.IMAGE.BLUR, ICON.BLUR, 0,
  'Blur', 0

; OBJECT

EVENT
 ID.CREATE, ICON.NEW, 0, 'Create', 0,
 ID.INSERT, ICON.NEW, 0, 'Insert', 0,
 ID.REMOVE, ICON.X, 0, 'Remove', 0,
 ID.COLOR, ICON.COLOR, 0, 'Color', 0,
 ID.FONT, ICON.A, 0, 'Font', 0,
 ID.SIZE, ICON.SIZE, 0, 'Size', 0,
 ID.ROTATE, ICON.ROTATE, 0, 'Rotate >', 0,
 ID.ROTATE.L, ICON.ROTATE.L, 0, 'Rotate Left', 0,
 ID.ROTATE.R, ICON.ROTATE.R, 0, 'Rotate Right', 0,
 ID.INVERT, ICON.INVERT, 0, 'Invert >', 0,
 ID.INVERT.H, ICON.INVERT.H, 0, 'Invert H/LR', 0,
 ID.INVERT.V, ICON.INVERT.V, 0, 'Invert V/UD', 0,
 ID.INVERT.X, ICON.INVERT, 0, 'Invert X/D', 0

; ORDER

EVENT
 ID.ORDER, ICON.W2, 0, 'Order', 0,
 ID.GROUP, ICON.GROUP, 0, 'Group', 0,
 ID.UNGROUP, ICON.UNGROUP, 0, 'Ungroup', 0,
 ID.FORWARD, ICON.FORWARD, 0, 'Bring Forward', 0,
 ID.BACKWARD, ICON.BACKWARD, 0, 'Send Backward', 0,
 ID.FORTH, ICON.FORTH, 0, 'Forward', 0,
 ID.BACK, ICON.BACK, 0, 'Backward', 0

; ALIGN

EVENT
 ID.OBJECT.GRID, ICON.W4, 0,
  'Grid', 'Grid Size, Inset',
 ID.OBJECT.ALIGN, ICON.A, 0,
  'Align', 0,
 ID.OBJECT.ALIGN.C, ICON.CIRCLE, 0,
  'Center', 0,
 ID.OBJECT.ALIGN.H, ICON.CIRCLE, 0,
  'Center L/R', 'Center Horizontal',
 ID.OBJECT.ALIGN.V, ICON.CIRCLE, 0,
  'Center U/D', 'Center Vertical',
 ID.OBJECT.JUSTIFY.L, ICON.L, 0,
  'Justify L', 0,
 ID.OBJECT.JUSTIFY.R, ICON.R, 0,
  'Justify R', 0,
 ID.OBJECT.ALIGN.N, ICON.UP, 0,
  'North, Up', 'Up',
 ID.OBJECT.ALIGN.NE, ICON.UP.RIGHT, 0,
  'North East', 'Up Right',
 ID.OBJECT.ALIGN.E, ICON.RIGHT, 0,
  'East, Right', 'Right',
 ID.OBJECT.ALIGN.SE, ICON.DOWN.RIGHT, 0,
  'South East', 'Down Right',
 ID.OBJECT.ALIGN.S, ICON.DOWN, 0,
  'South, Down', 'Down',
 ID.OBJECT.ALIGN.SW, ICON.DOWN.LEFT, 0,
  'South West', 'Down Left',
 ID.OBJECT.ALIGN.W, ICON.LEFT, 0,
  'West, Left', 'Left',
 ID.OBJECT.ALIGN.NW, ICON.UP.LEFT, 0,
  'North West', 'Up Left'

; TABLE

EVENT
 ID.TABLE.SIZE, ICON.W4, 0,
  'Size', 'Table Size',
 ID.TABLE.INSERT.L, ICON.LEFT, 0,
  'Columns Left', 'Insert Columns Left',
 ID.TABLE.INSERT.R, ICON.RIGHT, 0,
  'Columns Right', 'Insert Columns Right',
 ID.TABLE.INSERT.A, ICON.UP, 0,
  'Rows Above', 'Insert Rows Above',
 ID.TABLE.INSERT.B, ICON.DOWN, 0,
  'Rows Below', 'Insert Rows Below',
 ID.TABLE.DELETE.C, ICON.X, 0,
  'Delete Columns', 0,
 ID.TABLE.DELETE.R, ICON.X, 0,
  'Delete Rows', 0

; INSERT

EVENT
 ID.INSERT.TEXT, ICON.TEXT, 0, 'Text', 0,
 ID.INSERT.IMAGE, ICON.IMAGE, 0, 'Image', 0,
 ID.INSERT.OBJECT, ICON.CODE, 0, 'Object', 0,
 ID.INSERT.HUMAN, ICON.USER, 0, 'Human', 0,
 ID.INSERT.ANIMAL, ICON.DOT, 0, 'Animal', 0,
 ID.INSERT.SKY, ICON.DOT, 0, 'Sky', 0,
 ID.INSERT.GRASS, ICON.DOT, 0, 'Ground', 0,
 ID.INSERT.TREE, ICON.DOT, 0, 'Tree', 0,
 ID.INSERT.MOUNTAIN, ICON.DOT, 0, 'Mountain', 0,
 ID.INSERT.WATER, ICON.DOT, 0, 'Water', 0,
 ID.INSERT.CAR, ICON.DOT, 0, 'Car', 0,
 ID.INSERT.BUILDING, ICON.DOT, 0, 'Building', 0,
 ID.INSERT.PLANET, ICON.DOT, 0, 'Planet', 0,
 ID.INSERT.GALAXY, ICON.DOT, 0, 'Galaxy', 0,
 ID.INSERT.STAR, ICON.DOT, 0, 'Star', 0

; INTERNET

EVENT
 ID.I.SEARCH, ICON.SEARCH, 0, 'Search', 0,
 ID.I.BROWSER, ICON.PLANET, 0, 'Browser', 0,
 ID.I.MAIL, ICON.MAIL, 0, 'E-Mail', 0,
 ID.I.CHAT, ICON.SMILE, 0, 'Chat', 0,
 ID.I.PROFILE, ICON.USER, 0, 'Profile', 0,
 ID.I.PERSONAL, ICON.HEART, 0, 'Personal', 0,
 ID.I.SETTINGS, ICON.SETTINGS, 0, 'Settings', 0

; CONFIGURE

EVENT
 ID.C.KEY, ICON.A, 0, 'Keyboard', 0,
 ID.C.MOUSE, ICON.A, 0, 'Mouse', 0,
 ID.C.GAME, ICON.GAME, 0, 'Gamepad', 0

*/

/* 2-DO: replace all CONTROLS with
CONTROL.TYPE=BUTTON/MENU/ETC...

int create_control(CONTROL *control);
void destroy_control(CONTROL *control);
void move_control(CONTROL *control, int x, int y);
void size_control(CONTROL *control, int w, int h);
int align_control(CONTROL *control, BOX *box, int a);
text get_control_text(CONTROL *control, text t);
int set_control_text(CONTROL *control, text t);
int get_control_number(CONTROL *control);
int set_control_number(CONTROL *control, int n);

*/