////////////////////// MENU //////////////////////

object {
  uint tag, id, type,
    state, show, focus;
  text t, note;
  BOX box;
  ARRAY items; // ITEMs[]
  int *ids;
  int select, click, selected;
} MENU;

void enable_menu_item(MENU *menu, int i) {
  ITEM *item=array_index(&menu->items, i);
  item->type&=~ICON_DISABLED;
}

void disable_menu_item(MENU *menu, int i) {
  ITEM *item=array_index(&menu->items, i);
  item->type|=ICON_DISABLED;
}

// create menu from system event IDs. see INTERFACE.H
// create array of items, assign "item icons" (item.icon_p),
// use_these_icons sets "event icons" (event.icon_id) to 
// be "used" by load_system_icons(). then set default styles

int create_menu(MENU *menu, text name, int ids[], int n) {
  int i, h=32;
  ARRAY *items=&menu->items;
  ITEM *item;
  ICON *icon;
  STYLE *style;
  menu->t=name, menu->ids=ids;
  menu->show=YES, menu->focus=YES;
  menu->box.h=(n*h)+8;

  if (!array_new(items, sizeof(ITEM), n))
    return 0;
  array_erase(items);
  for (i=0; i<n; i++) {
    item=(ITEM *) array_index(items, i);
    item->icon_p=get_event_icon(ids[i]);
  }
  use_these_icons(ids, n);
  set_style_name(&menu->style, "black");
  set_style_name(&menu->style2, "blue");
  control_memory_n++;
  control_memory+=sizeof(MENU)+
    (n*sizeof(ITEM));
  return 1;
}

text *menu_help_p=0;

int draw_menu(MENU *menu) {
  if (!menu->show)
    return 0;
  int i, id, x, y, h=32, n=menu->items.n;
  BOX box=menu->box, box2;
  char t[128];
  EVENT *event;
  ITEM *item;
  ICON *icon;
  color c;
  x=box.x, y=box.y;
  draw_shade(&box, BLACK, 0x202020, WHITE);
  box.x+=4, box.y+=10, box.w-=8, box.h=h;
  menu->select=menu->selected=menu->click=-1;

  for (i=0; i<n; i++) {
    t[0]=0, id=menu->ids[i];
    icon=get_event_icon(id);
    item=(ITEM *)
      array_index(&menu->items, i);
    c=WHITE;
    box2=box, box2.y-=6;
    if (menu->focus) {
      if (select_box(&box2)) {
        menu->select=id;
        menu->selected=i;
        if (not (item->type&ICON_DISABLED)) {
          if (mouse_1)
            menu->click=id;
          draw_shade(&box2, BLACK, BLUE, BLUE);
        }
        else
          draw_shade(&box2, BLACK, 0x222222, 0x444444);
        c=WHITE;
        if (menu_help_p) {
        //  if (menu->select!=-1)
        // EVENT *ep=get_event(menu->select);
          text_copy(t, menu_help_p[i]);
          draw_caption(t, screen_w-text_w(t)-48, 87);
        }
      }
    }

    if (not (item->type&ICON_DISABLED))
      icon->state&=~ICON_DISABLED;
    else {
      icon->state|=ICON_DISABLED;      
      c=0x707070;
    }
    draw_icon_at(icon, box.x+4, box.y-3);
    set_font_color(c);
    event=get_event(id);

    if (event) {
      text_copy(t, event->name);
      draw_text(t, x+48, box.y-1);
    }
    box.y+=h;
  }
  return 1;
}