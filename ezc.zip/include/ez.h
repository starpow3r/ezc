/* EZC LIBRARY. BY STARPOWER/MYSTERI/OUS.
    __  ___         __          _
  /  |/  /_ _____ / /____ ____(_)
 / /|_/ / // (_-<  __/ -_) __/ /
/_/  /_/\_, /___/\__/\__/_/ /_/
       /___/ (C) 2016-2024+, KID-7/77 */

//////////////// CPU, OS, COMPILER ///////////////

#define CPU_INTEL      // CPU: _ARM, _AVR, _STM32
#define DATA_32        // 8, 16, 32, 64 (ARITHMETIC)
#define ADDRESS_32     // 8, 16, 32, 64 (ADDRESS)
#define LOW_ENDIAN     // or HIGH_
#define SYSTEM_WINDOWS // _ANDROID, _LINUX, _ARDUINO, _PICO
#define COMPILER_TINY  // _TURBO, _C4DROID, _ARDUINO

/////////////////// ESSENTIALS ///////////////////

typedef signed char int8, ibyte;
typedef signed short int16, intw;
typedef signed int int32, bool;
typedef signed long long int64, intq;

typedef unsigned char uint8, byte;
typedef unsigned short uint16, uintw, word;
typedef unsigned uint, uint32, dword, color;
typedef unsigned long long uint64, qword, uintq;

typedef char *text;
typedef int *intp;
typedef unsigned *uintp;
typedef void *voidp;

#define and &&
#define or ||
#define not !

#define object typedef struct
#define number_of(a) (sizeof(a)/sizeof(void *))

enum { INVALID=-1, NO, YES };

enum { KB=1024, MB=KB*1024, GB=MB*1024 };

char main_path[80]="..";

extern void log(text t, ...);
extern void exit();

text main_font_name="romana/16b",
  main_icon_name="eye", code_icon_name="code";

char program_file[256], program_name[32],
  program_directory[256];
text command_line_p=0;

char image_folder[256], default_image_type[8]="bmp";
char font_folder[256], icon_folder[256];

#define set_font_folder(f) text_copy(font_folder, f)
#define set_image_folder(f) text_copy(image_folder, f)
#define set_icon_folder(f) text_copy(icon_folder, f)

// screen: "vga, double buffer, primary surface".
// see include/draw

void *screen_p=0;
int screen_x=0, screen_y=0,
  screen_w, screen_h, screen_color=0;
int os_w, os_h;

object { int x, y, w, h; } BOX;

BOX clip={ 0, 0, 0, 0 };

// versatile align n/umber by power of 2.
// return n aligned to p/ower, or return
// alignment value that makes n divisible
// by p/ower: align_n = n+align_v(n, p)

uint align_n(uint n, uint p) {
  return n+(((p-1)-(n+p-1))&(p-1));
}

uint align_v(uint n, uint p) {
  return (((p-1)-(n+p-1))&(p-1));
}

#define ABS(n) ((n<0)?-(n):n)

#define is_whole(f) \
  ((f)-(uint64)(f)==0) // (fmod(f, 1)==0.0)

#define normalize(n, min, max) ((n-min)/(max-min))

#define bug(t...) log(t), show_log(), exit()
#define source_error(t...) bug(t)

///////////////////// INCLUDE ////////////////////

// C standard library and minimal OS

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <conio.h>
#include <time.h>

#ifdef SYSTEM_WINDOWS
  #include <windows.h>
  #define get_ms GetTickCount
#endif

// essentials

#include "system/memory.h"   // allocate, memory_copy, binary, random
#include "language/array.h"  // array_create, array_index, array_sort
#include "text/character.h"  // character table, is_c/haracter
#include "text/text.h"       // text_copy, text_attach, text_compare
#include "text/convert.h"    // convert text/numbers
#include "text/print.h"      // s/print/f alternative
#include "system/time.h"     // time functions
#include "file/file.h"       // load_file, read_file, save_text
#include "file/log.h"

// for drawing and graphics interfaces

#ifdef ON_DRAW
  #include "draw/color.h"    // color_names, rgb(), conversions, effects
  #include "draw/box.h"      // box, set_box, align_box, collide_box
  #include "draw/draw.h"     // drawing: pixel, line, box, scanline, image

  #include "image/image.h"   // draw_image, move, rotate
  #include "image/file.h"    // load_image, save_image
  #include "image/icon.h"

  #include "font/font.h"     // font structure
  #include "font/draw.h"     // draw_c, draw_text, draw_caption
  #include "font/caption.h"  // draw caption
  #include "font/item.h"
  #include "font/load.h"     // load_font

  // #include "undo.h"      // undo_action, redo_action

// /system/ contains all system-specific code, and it's the only
// non-portable file that must be edited for other systems

  #include "system/system.h" // #include "system/system/windows.h"

  #include "system/interface.h"

  #include "control/toolbar.h"
  // #include "control/menu.h"
#endif

// main types/objects/structures

enum {
  TAG_NONE, TAG_NUMBER, TAG_TEXT, TAG_STRING,
  TAG_VARIABLE, TAG_ARRAY, TAG_FILE, TAG_COLOR,
  TAG_BOX, TAG_ART, TAG_IMAGE, TAG_CANVAS, TAG_FONT,
  TAG_STYLE, TAG_CAPTION, TAG_ICON, TAG_CURSOR, TAG_SPRITE,
  TAG_ACTOR, TAG_TABLE, TAG_CELL, TAG_ELEMENT, TAG_PAGE,
  TAG_BOOK, TAG_CONTROL, TAG_DIALOG, TAG_FRAME, TAG_NOTE,
  TAG_PICTURE, TAG_BUTTON, TAG_SWITCH, TAG_SLIDER,
  TAG_SCROLLBAR, TAG_TOOLBAR, TAG_LISTBOX, TAG_MENU,
  TAG_EDIT, TAG_UNDO, TAG_GRAPH, TAG_GALLERY,
  TAG_MESSAGE_BOX, TAG_PICTURE_BOX, TAG_SELECT_COLOR,
  TAG_SELECT_FONT, TAG_SELECT_STYLE, TAG_SELECT_IMAGE,
  TAG_SELECT_FILE
};

/*
DEPENDENCIES: DRAWING

* screen > box > color
* draw_pixel > screen
* draw_line > draw_pixel
* draw_box > draw_line
* draw_fade/shade/chrome > draw_line
* draw_scanline > draw_pixel
* draw_bitmap > draw_scanline
* draw_c/haracter > draw_scanline
* draw_text > draw_c/haracter
* draw_caption > draw_text
*/

////////////////////// MAIN //////////////////////

#ifdef ON_DRAW

IMAGE arrow_cursor;

int WINAPI WinMain(HINSTANCE hi, HINSTANCE na,
  PSTR c, int na2) {
  char t[256];
  text p, q;
  startup_time=get_ms();
  h_instance=hi;
  command_line_p=GetCommandLine();
  extract_name(program_name, program_file);
  extract_directory(program_directory, program_file);

  os_w=screen_w=GetSystemMetrics(0);
  os_h=screen_h=GetSystemMetrics(1);

  if (!load_image_t(&arrow_cursor, "media/cursor/arrow")) {
    bug("Error loading main cursor (EZ.H)");
    return 0;
  }
  set_font_folder("media/font");
  if (!load_font(&main_font, main_font_name)) {
    bug("Error loading main font (EZ.H): %s", main_font_name);
    return 0;
  }
  set_icon_folder("../../media/icon/24");
  if (!load_icon(&main_icon, main_icon_name)) {
    bug("Error loading main icon (EZ.H): %s", main_icon_name);
    return 0;
  }
  if (!load_icon(&code_icon, code_icon_name)) {
    bug("Error loading main icon (EZ.H): %s", code_icon_name);
    return 0;
  }

  set_font(&main_font);
  set_font_color(WHITE); //BLACK);
  // os_show_cursor(0);

  #ifdef USE_TOKEN
    if (!allocate(text, token, 4096))
      return 0;
  #endif

  if (!on_create())
    exit();
  initialized=1;
  if (do_clear_screen)
    clear_screen(screen_color);
  redraw();
  startup_time=get_ms()-startup_time;

  while (1) {
    // (real custom timer here)

    if (!GetMessage(&msg, 0, 0, 0))
      break;
    TranslateMessage(&msg);
    DispatchMessage(&msg);
  }
  return msg.wParam;
}

#endif

/* KEYWORDS: types, operators, conversions,
constants, screen, input, objects

and or not cant
byte word dword qword uint
ibyte int8 int16 int32 int64 intw intq
uint8 uint16 uint32 uint64 uintq uintw
intp uintp voidp ushort color
text string object number_of
allocate relocate destroy print
u2t i2t h2t b2t f2t d2t
t2u t2i t2h t2b t2f t2d
screen_p screen_x screen_y screen_w screen_h
screen_color os_w os_h
key mouse_1 mouse_2 mouse_x mouse_y mouse_drag
mouse_drop ende event_create event_draw
event_input event_key event_key_c event_key_release
event_mouse event_mouse_move event_mouse_down
event_mouse_click event_mouse_release
event_mouse_right_down event_mouse_right_click
event_mouse_right_release event_mouse_drag
event_mouse_wheel event_timer event_exit
KB MB GB YES NO TRUE FALSE INVALID
NUMBER TEXT STRING VARIABLE OBJECT ARRAY NODE LIST LABEL
TIME FILE COLOR POINT BOX ART GRAPHICS IMAGE CANVAS
FONT FONTX STYLE CAPTION ICON CURSOR ITEM SPRITE
ACTION ACTOR TABLE CELL ELEMENT PAGE BOOK DOCUMENT
EVENT CONTROL DIALOG FRAME NOTE PICTURE BUTTON SWITCH
SLIDER SCROLLBAR TOOLBAR LISTBOX MENU TEXTBOX EDIT
GRAPH GALLERY MESSAGE_BOX PICTURE_BOX SELECT_COLOR
SELECT_FONT SELECT_STYLE SELECT_IMAGE SELECT_FILE
MEMORY APPLICATION INTERFACE LIBRARY UNDO UNDOS
*/