/*
 * TODO: Nothing here yet. Should provide UNIX compatibility constants
 * comparible to those in limits.h and float.h.
 */
